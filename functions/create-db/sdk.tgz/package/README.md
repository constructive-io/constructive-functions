# @constructive-db/constructive-sdk

<p align="center" width="100%">
  <img height="250" src="https://raw.githubusercontent.com/constructive-io/constructive/refs/heads/main/assets/outline-logo.svg" />
</p>

Auto-generated GraphQL types and ORM client for Constructive applications.

## Overview

This package provides type-safe GraphQL operations generated from your PostGraphile endpoint using `@constructive-io/graphql-codegen`. It generates:

- **TypeScript types** for all GraphQL entities
- **ORM client** with Prisma-like API (`db.user.findMany()`, `db.mutation.login()`)
- **Standalone fetch functions** for queries (no React dependency)
- **React Query hooks** (optional, disabled by default)

## Installation

```bash
pnpm install
```

## Configuration

Edit `graphql-sdk.config.ts` to configure:

- `endpoint`: Your PostGraphile GraphQL endpoint URL
- `output`: Output directory for generated code
- `headers`: Authentication headers (optional)
- `tables`: Filter which tables to generate code for
- `queries`/`mutations`: Filter which operations to include
- `reactQuery.enabled`: Set to `true` to generate React Query hooks

## Generating Code

### Generate ORM Client (default)

```bash
pnpm run generate
```

This generates a Prisma-like ORM client without React dependencies.

### Generate React Query Hooks (optional)

First, update `graphql-sdk.config.ts`:

```typescript
reactQuery: {
  enabled: true,
}
```

Then run:

```bash
pnpm run generate:hooks
```

## Usage

### ORM Client

```typescript
import { createClient } from './generated/orm';

const db = createClient({
  endpoint: 'https://api.example.com/graphql',
  headers: { Authorization: 'Bearer <token>' },
});

// Find many users
const users = await db.user.findMany({
  select: { id: true, email: true, name: true },
  first: 10,
  filter: { isActive: { equalTo: true } },
}).execute();

// Find one user by ID
const user = await db.user.findOne({
  id: userId,
  select: { id: true, email: true },
}).execute();

// Custom mutations
const result = await db.mutation.login({
  email: 'user@example.com',
  password: 'secret',
}).execute();
```

### Standalone Fetch Functions

```typescript
import { fetchUsersQuery, fetchUserQuery } from './generated/queries';

// Fetch users list
const users = await fetchUsersQuery({ first: 10 });

// Fetch single user
const user = await fetchUserQuery({ id: userId });
```

## Building

```bash
pnpm run build
```

## Development

```bash
# Build with source maps
pnpm run build:dev

# Run tests
pnpm test

# Lint
pnpm run lint
```
