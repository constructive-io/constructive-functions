"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModuleDefinitionModel = void 0;
const query_builder_1 = require("../query-builder");
// ============================================================================
// Model Class
// ============================================================================
class ModuleDefinitionModel {
    constructor(client) {
        this.client = client;
    }
    findMany(args) {
        const { document, variables } = (0, query_builder_1.buildFindManyDocument)('ModuleDefinition', 'moduleDefinitions', args?.select, {
            where: args?.where,
            orderBy: args?.orderBy,
            first: args?.first,
            last: args?.last,
            after: args?.after,
            before: args?.before,
            offset: args?.offset,
        }, 'ModuleDefinitionFilter', 'ModuleDefinitionsOrderBy');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'query',
            operationName: 'ModuleDefinition',
            fieldName: 'moduleDefinitions',
            document,
            variables,
        });
    }
    findFirst(args) {
        const { document, variables } = (0, query_builder_1.buildFindFirstDocument)('ModuleDefinition', 'moduleDefinitions', args?.select, { where: args?.where }, 'ModuleDefinitionFilter');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'query',
            operationName: 'ModuleDefinition',
            fieldName: 'moduleDefinitions',
            document,
            variables,
        });
    }
    create(args) {
        const { document, variables } = (0, query_builder_1.buildCreateDocument)('ModuleDefinition', 'createModuleDefinition', 'moduleDefinition', args.select, args.data, 'CreateModuleDefinitionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ModuleDefinition',
            fieldName: 'createModuleDefinition',
            document,
            variables,
        });
    }
    update(args) {
        const { document, variables } = (0, query_builder_1.buildUpdateDocument)('ModuleDefinition', 'updateModuleDefinition', 'moduleDefinition', args.select, args.where, args.data, 'UpdateModuleDefinitionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ModuleDefinition',
            fieldName: 'updateModuleDefinition',
            document,
            variables,
        });
    }
    delete(args) {
        const { document, variables } = (0, query_builder_1.buildDeleteDocument)('ModuleDefinition', 'deleteModuleDefinition', 'moduleDefinition', args.where, 'DeleteModuleDefinitionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ModuleDefinition',
            fieldName: 'deleteModuleDefinition',
            document,
            variables,
        });
    }
}
exports.ModuleDefinitionModel = ModuleDefinitionModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlRGVmaW5pdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9nZW5lcmF0ZWQvbW9kZWxzL21vZHVsZURlZmluaXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBTUEsb0RBTzBCO0FBcUIxQiwrRUFBK0U7QUFDL0UsY0FBYztBQUNkLCtFQUErRTtBQUMvRSxNQUFhLHFCQUFxQjtJQUNoQyxZQUFvQixNQUFpQjtRQUFqQixXQUFNLEdBQU4sTUFBTSxDQUFXO0lBQUcsQ0FBQztJQUV6QyxRQUFRLENBQ04sSUFBd0U7UUFNeEUsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFBLHFDQUFxQixFQUNuRCxrQkFBa0IsRUFDbEIsbUJBQW1CLEVBQ25CLElBQUksRUFBRSxNQUFNLEVBQ1o7WUFDRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUs7WUFDbEIsT0FBTyxFQUFFLElBQUksRUFBRSxPQUErQjtZQUM5QyxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUs7WUFDbEIsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJO1lBQ2hCLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSztZQUNsQixNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU07WUFDcEIsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNO1NBQ3JCLEVBQ0Qsd0JBQXdCLEVBQ3hCLDBCQUEwQixDQUMzQixDQUFDO1FBQ0YsT0FBTyxJQUFJLDRCQUFZLENBQUM7WUFDdEIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFNBQVMsRUFBRSxPQUFPO1lBQ2xCLGFBQWEsRUFBRSxrQkFBa0I7WUFDakMsU0FBUyxFQUFFLG1CQUFtQjtZQUM5QixRQUFRO1lBQ1IsU0FBUztTQUNWLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxTQUFTLENBQ1AsSUFBK0M7UUFNL0MsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFBLHNDQUFzQixFQUNwRCxrQkFBa0IsRUFDbEIsbUJBQW1CLEVBQ25CLElBQUksRUFBRSxNQUFNLEVBQ1osRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUN0Qix3QkFBd0IsQ0FDekIsQ0FBQztRQUNGLE9BQU8sSUFBSSw0QkFBWSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixTQUFTLEVBQUUsT0FBTztZQUNsQixhQUFhLEVBQUUsa0JBQWtCO1lBQ2pDLFNBQVMsRUFBRSxtQkFBbUI7WUFDOUIsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsTUFBTSxDQUNKLElBQW9FO1FBTXBFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLEdBQUcsSUFBQSxtQ0FBbUIsRUFDakQsa0JBQWtCLEVBQ2xCLHdCQUF3QixFQUN4QixrQkFBa0IsRUFDbEIsSUFBSSxDQUFDLE1BQU0sRUFDWCxJQUFJLENBQUMsSUFBSSxFQUNULDZCQUE2QixDQUM5QixDQUFDO1FBQ0YsT0FBTyxJQUFJLDRCQUFZLENBQUM7WUFDdEIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxrQkFBa0I7WUFDakMsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxRQUFRO1lBQ1IsU0FBUztTQUNWLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxNQUFNLENBQ0osSUFBMEQ7UUFNMUQsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFBLG1DQUFtQixFQUNqRCxrQkFBa0IsRUFDbEIsd0JBQXdCLEVBQ3hCLGtCQUFrQixFQUNsQixJQUFJLENBQUMsTUFBTSxFQUNYLElBQUksQ0FBQyxLQUFLLEVBQ1YsSUFBSSxDQUFDLElBQUksRUFDVCw2QkFBNkIsQ0FDOUIsQ0FBQztRQUNGLE9BQU8sSUFBSSw0QkFBWSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0JBQWtCO1lBQ2pDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsTUFBTSxDQUFDLElBQWdDO1FBR3JDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLEdBQUcsSUFBQSxtQ0FBbUIsRUFDakQsa0JBQWtCLEVBQ2xCLHdCQUF3QixFQUN4QixrQkFBa0IsRUFDbEIsSUFBSSxDQUFDLEtBQUssRUFDViw2QkFBNkIsQ0FDOUIsQ0FBQztRQUNGLE9BQU8sSUFBSSw0QkFBWSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0JBQWtCO1lBQ2pDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFsSUQsc0RBa0lDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBNb2R1bGVEZWZpbml0aW9uIG1vZGVsIGZvciBPUk0gY2xpZW50XG4gKiBAZ2VuZXJhdGVkIGJ5IEBjb25zdHJ1Y3RpdmUtaW8vZ3JhcGhxbC1jb2RlZ2VuXG4gKiBETyBOT1QgRURJVCAtIGNoYW5nZXMgd2lsbCBiZSBvdmVyd3JpdHRlblxuICovXG5pbXBvcnQgeyBPcm1DbGllbnQgfSBmcm9tICcuLi9jbGllbnQnO1xuaW1wb3J0IHtcbiAgUXVlcnlCdWlsZGVyLFxuICBidWlsZEZpbmRNYW55RG9jdW1lbnQsXG4gIGJ1aWxkRmluZEZpcnN0RG9jdW1lbnQsXG4gIGJ1aWxkQ3JlYXRlRG9jdW1lbnQsXG4gIGJ1aWxkVXBkYXRlRG9jdW1lbnQsXG4gIGJ1aWxkRGVsZXRlRG9jdW1lbnQsXG59IGZyb20gJy4uL3F1ZXJ5LWJ1aWxkZXInO1xuaW1wb3J0IHtcbiAgdHlwZSBDb25uZWN0aW9uUmVzdWx0LFxuICB0eXBlIEZpbmRNYW55QXJncyxcbiAgdHlwZSBGaW5kRmlyc3RBcmdzLFxuICB0eXBlIENyZWF0ZUFyZ3MsXG4gIHR5cGUgVXBkYXRlQXJncyxcbiAgdHlwZSBEZWxldGVBcmdzLFxuICB0eXBlIEluZmVyU2VsZWN0UmVzdWx0LFxufSBmcm9tICcuLi9zZWxlY3QtdHlwZXMnO1xuaW1wb3J0IHtcbiAgdHlwZSBNb2R1bGVEZWZpbml0aW9uLFxuICB0eXBlIE1vZHVsZURlZmluaXRpb25XaXRoUmVsYXRpb25zLFxuICB0eXBlIE1vZHVsZURlZmluaXRpb25TZWxlY3QsXG4gIHR5cGUgTW9kdWxlRGVmaW5pdGlvbkZpbHRlcixcbiAgdHlwZSBNb2R1bGVEZWZpbml0aW9uc09yZGVyQnksXG4gIHR5cGUgQ3JlYXRlTW9kdWxlRGVmaW5pdGlvbklucHV0LFxuICB0eXBlIFVwZGF0ZU1vZHVsZURlZmluaXRpb25JbnB1dCxcbiAgdHlwZSBNb2R1bGVEZWZpbml0aW9uUGF0Y2gsXG59IGZyb20gJy4uL2lucHV0LXR5cGVzJztcblxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuLy8gTW9kZWwgQ2xhc3Ncbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbmV4cG9ydCBjbGFzcyBNb2R1bGVEZWZpbml0aW9uTW9kZWwge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNsaWVudDogT3JtQ2xpZW50KSB7fVxuXG4gIGZpbmRNYW55PGNvbnN0IFMgZXh0ZW5kcyBNb2R1bGVEZWZpbml0aW9uU2VsZWN0PihcbiAgICBhcmdzPzogRmluZE1hbnlBcmdzPFMsIE1vZHVsZURlZmluaXRpb25GaWx0ZXIsIE1vZHVsZURlZmluaXRpb25zT3JkZXJCeT4sXG4gICk6IFF1ZXJ5QnVpbGRlcjx7XG4gICAgbW9kdWxlRGVmaW5pdGlvbnM6IENvbm5lY3Rpb25SZXN1bHQ8XG4gICAgICBJbmZlclNlbGVjdFJlc3VsdDxNb2R1bGVEZWZpbml0aW9uV2l0aFJlbGF0aW9ucywgUz5cbiAgICA+O1xuICB9PiB7XG4gICAgY29uc3QgeyBkb2N1bWVudCwgdmFyaWFibGVzIH0gPSBidWlsZEZpbmRNYW55RG9jdW1lbnQoXG4gICAgICAnTW9kdWxlRGVmaW5pdGlvbicsXG4gICAgICAnbW9kdWxlRGVmaW5pdGlvbnMnLFxuICAgICAgYXJncz8uc2VsZWN0LFxuICAgICAge1xuICAgICAgICB3aGVyZTogYXJncz8ud2hlcmUsXG4gICAgICAgIG9yZGVyQnk6IGFyZ3M/Lm9yZGVyQnkgYXMgc3RyaW5nW10gfCB1bmRlZmluZWQsXG4gICAgICAgIGZpcnN0OiBhcmdzPy5maXJzdCxcbiAgICAgICAgbGFzdDogYXJncz8ubGFzdCxcbiAgICAgICAgYWZ0ZXI6IGFyZ3M/LmFmdGVyLFxuICAgICAgICBiZWZvcmU6IGFyZ3M/LmJlZm9yZSxcbiAgICAgICAgb2Zmc2V0OiBhcmdzPy5vZmZzZXQsXG4gICAgICB9LFxuICAgICAgJ01vZHVsZURlZmluaXRpb25GaWx0ZXInLFxuICAgICAgJ01vZHVsZURlZmluaXRpb25zT3JkZXJCeScsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5QnVpbGRlcih7XG4gICAgICBjbGllbnQ6IHRoaXMuY2xpZW50LFxuICAgICAgb3BlcmF0aW9uOiAncXVlcnknLFxuICAgICAgb3BlcmF0aW9uTmFtZTogJ01vZHVsZURlZmluaXRpb24nLFxuICAgICAgZmllbGROYW1lOiAnbW9kdWxlRGVmaW5pdGlvbnMnLFxuICAgICAgZG9jdW1lbnQsXG4gICAgICB2YXJpYWJsZXMsXG4gICAgfSk7XG4gIH1cblxuICBmaW5kRmlyc3Q8Y29uc3QgUyBleHRlbmRzIE1vZHVsZURlZmluaXRpb25TZWxlY3Q+KFxuICAgIGFyZ3M/OiBGaW5kRmlyc3RBcmdzPFMsIE1vZHVsZURlZmluaXRpb25GaWx0ZXI+LFxuICApOiBRdWVyeUJ1aWxkZXI8e1xuICAgIG1vZHVsZURlZmluaXRpb25zOiB7XG4gICAgICBub2RlczogSW5mZXJTZWxlY3RSZXN1bHQ8TW9kdWxlRGVmaW5pdGlvbldpdGhSZWxhdGlvbnMsIFM+W107XG4gICAgfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGRGaW5kRmlyc3REb2N1bWVudChcbiAgICAgICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdtb2R1bGVEZWZpbml0aW9ucycsXG4gICAgICBhcmdzPy5zZWxlY3QsXG4gICAgICB7IHdoZXJlOiBhcmdzPy53aGVyZSB9LFxuICAgICAgJ01vZHVsZURlZmluaXRpb25GaWx0ZXInLFxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBRdWVyeUJ1aWxkZXIoe1xuICAgICAgY2xpZW50OiB0aGlzLmNsaWVudCxcbiAgICAgIG9wZXJhdGlvbjogJ3F1ZXJ5JyxcbiAgICAgIG9wZXJhdGlvbk5hbWU6ICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGZpZWxkTmFtZTogJ21vZHVsZURlZmluaXRpb25zJyxcbiAgICAgIGRvY3VtZW50LFxuICAgICAgdmFyaWFibGVzLFxuICAgIH0pO1xuICB9XG5cbiAgY3JlYXRlPGNvbnN0IFMgZXh0ZW5kcyBNb2R1bGVEZWZpbml0aW9uU2VsZWN0PihcbiAgICBhcmdzOiBDcmVhdGVBcmdzPFMsIENyZWF0ZU1vZHVsZURlZmluaXRpb25JbnB1dFsnbW9kdWxlRGVmaW5pdGlvbiddPixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICBjcmVhdGVNb2R1bGVEZWZpbml0aW9uOiB7XG4gICAgICBtb2R1bGVEZWZpbml0aW9uOiBJbmZlclNlbGVjdFJlc3VsdDxNb2R1bGVEZWZpbml0aW9uV2l0aFJlbGF0aW9ucywgUz47XG4gICAgfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGRDcmVhdGVEb2N1bWVudChcbiAgICAgICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdjcmVhdGVNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdtb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGFyZ3Muc2VsZWN0LFxuICAgICAgYXJncy5kYXRhLFxuICAgICAgJ0NyZWF0ZU1vZHVsZURlZmluaXRpb25JbnB1dCcsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5QnVpbGRlcih7XG4gICAgICBjbGllbnQ6IHRoaXMuY2xpZW50LFxuICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgb3BlcmF0aW9uTmFtZTogJ01vZHVsZURlZmluaXRpb24nLFxuICAgICAgZmllbGROYW1lOiAnY3JlYXRlTW9kdWxlRGVmaW5pdGlvbicsXG4gICAgICBkb2N1bWVudCxcbiAgICAgIHZhcmlhYmxlcyxcbiAgICB9KTtcbiAgfVxuXG4gIHVwZGF0ZTxjb25zdCBTIGV4dGVuZHMgTW9kdWxlRGVmaW5pdGlvblNlbGVjdD4oXG4gICAgYXJnczogVXBkYXRlQXJnczxTLCB7IGlkOiBzdHJpbmcgfSwgTW9kdWxlRGVmaW5pdGlvblBhdGNoPixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICB1cGRhdGVNb2R1bGVEZWZpbml0aW9uOiB7XG4gICAgICBtb2R1bGVEZWZpbml0aW9uOiBJbmZlclNlbGVjdFJlc3VsdDxNb2R1bGVEZWZpbml0aW9uV2l0aFJlbGF0aW9ucywgUz47XG4gICAgfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGRVcGRhdGVEb2N1bWVudChcbiAgICAgICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICd1cGRhdGVNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdtb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGFyZ3Muc2VsZWN0LFxuICAgICAgYXJncy53aGVyZSxcbiAgICAgIGFyZ3MuZGF0YSxcbiAgICAgICdVcGRhdGVNb2R1bGVEZWZpbml0aW9uSW5wdXQnLFxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBRdWVyeUJ1aWxkZXIoe1xuICAgICAgY2xpZW50OiB0aGlzLmNsaWVudCxcbiAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgIG9wZXJhdGlvbk5hbWU6ICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZU1vZHVsZURlZmluaXRpb24nLFxuICAgICAgZG9jdW1lbnQsXG4gICAgICB2YXJpYWJsZXMsXG4gICAgfSk7XG4gIH1cblxuICBkZWxldGUoYXJnczogRGVsZXRlQXJnczx7IGlkOiBzdHJpbmcgfT4pOiBRdWVyeUJ1aWxkZXI8e1xuICAgIGRlbGV0ZU1vZHVsZURlZmluaXRpb246IHsgbW9kdWxlRGVmaW5pdGlvbjogeyBpZDogc3RyaW5nIH0gfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGREZWxldGVEb2N1bWVudChcbiAgICAgICdNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdkZWxldGVNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgICdtb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGFyZ3Mud2hlcmUsXG4gICAgICAnRGVsZXRlTW9kdWxlRGVmaW5pdGlvbklucHV0JyxcbiAgICApO1xuICAgIHJldHVybiBuZXcgUXVlcnlCdWlsZGVyKHtcbiAgICAgIGNsaWVudDogdGhpcy5jbGllbnQsXG4gICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICBvcGVyYXRpb25OYW1lOiAnTW9kdWxlRGVmaW5pdGlvbicsXG4gICAgICBmaWVsZE5hbWU6ICdkZWxldGVNb2R1bGVEZWZpbml0aW9uJyxcbiAgICAgIGRvY3VtZW50LFxuICAgICAgdmFyaWFibGVzLFxuICAgIH0pO1xuICB9XG59XG4iXX0=