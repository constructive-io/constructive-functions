"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiExtensionModel = void 0;
const query_builder_1 = require("../query-builder");
class ApiExtensionModel {
    constructor(client) {
        this.client = client;
    }
    findMany(args) {
        const { document, variables } = (0, query_builder_1.buildFindManyDocument)('ApiExtension', 'apiExtensions', args?.select, {
            where: args?.where,
            orderBy: args?.orderBy,
            first: args?.first,
            last: args?.last,
            after: args?.after,
            before: args?.before,
            offset: args?.offset,
        }, 'ApiExtensionFilter', 'ApiExtensionsOrderBy');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'query',
            operationName: 'ApiExtension',
            fieldName: 'apiExtensions',
            document,
            variables,
        });
    }
    findFirst(args) {
        const { document, variables } = (0, query_builder_1.buildFindFirstDocument)('ApiExtension', 'apiExtensions', args?.select, {
            where: args?.where,
        }, 'ApiExtensionFilter');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'query',
            operationName: 'ApiExtension',
            fieldName: 'apiExtensions',
            document,
            variables,
        });
    }
    create(args) {
        const { document, variables } = (0, query_builder_1.buildCreateDocument)('ApiExtension', 'createApiExtension', 'apiExtension', args.select, args.data, 'CreateApiExtensionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ApiExtension',
            fieldName: 'createApiExtension',
            document,
            variables,
        });
    }
    update(args) {
        const { document, variables } = (0, query_builder_1.buildUpdateDocument)('ApiExtension', 'updateApiExtension', 'apiExtension', args.select, args.where, args.data, 'UpdateApiExtensionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ApiExtension',
            fieldName: 'updateApiExtension',
            document,
            variables,
        });
    }
    delete(args) {
        const { document, variables } = (0, query_builder_1.buildDeleteDocument)('ApiExtension', 'deleteApiExtension', 'apiExtension', args.where, 'DeleteApiExtensionInput');
        return new query_builder_1.QueryBuilder({
            client: this.client,
            operation: 'mutation',
            operationName: 'ApiExtension',
            fieldName: 'deleteApiExtension',
            document,
            variables,
        });
    }
}
exports.ApiExtensionModel = ApiExtensionModel;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpRXh0ZW5zaW9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2dlbmVyYXRlZC9tb2RlbHMvYXBpRXh0ZW5zaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQU1BLG9EQU8wQjtBQXFCMUIsTUFBYSxpQkFBaUI7SUFDNUIsWUFBb0IsTUFBaUI7UUFBakIsV0FBTSxHQUFOLE1BQU0sQ0FBVztJQUFHLENBQUM7SUFDekMsUUFBUSxDQUNOLElBSUM7UUFNRCxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxHQUFHLElBQUEscUNBQXFCLEVBQ25ELGNBQWMsRUFDZCxlQUFlLEVBQ2YsSUFBSSxFQUFFLE1BQU0sRUFDWjtZQUNFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSztZQUNsQixPQUFPLEVBQUUsSUFBSSxFQUFFLE9BQStCO1lBQzlDLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSztZQUNsQixJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLO1lBQ2xCLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTTtZQUNwQixNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU07U0FDckIsRUFDRCxvQkFBb0IsRUFDcEIsc0JBQXNCLENBQ3ZCLENBQUM7UUFDRixPQUFPLElBQUksNEJBQVksQ0FBQztZQUN0QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsU0FBUyxFQUFFLE9BQU87WUFDbEIsYUFBYSxFQUFFLGNBQWM7WUFDN0IsU0FBUyxFQUFFLGVBQWU7WUFDMUIsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0QsU0FBUyxDQUNQLElBQTBFO1FBTTFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLEdBQUcsSUFBQSxzQ0FBc0IsRUFDcEQsY0FBYyxFQUNkLGVBQWUsRUFDZixJQUFJLEVBQUUsTUFBTSxFQUNaO1lBQ0UsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLO1NBQ25CLEVBQ0Qsb0JBQW9CLENBQ3JCLENBQUM7UUFDRixPQUFPLElBQUksNEJBQVksQ0FBQztZQUN0QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsU0FBUyxFQUFFLE9BQU87WUFDbEIsYUFBYSxFQUFFLGNBQWM7WUFDN0IsU0FBUyxFQUFFLGVBQWU7WUFDMUIsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0QsTUFBTSxDQUNKLElBR0M7UUFNRCxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxHQUFHLElBQUEsbUNBQW1CLEVBQ2pELGNBQWMsRUFDZCxvQkFBb0IsRUFDcEIsY0FBYyxFQUNkLElBQUksQ0FBQyxNQUFNLEVBQ1gsSUFBSSxDQUFDLElBQUksRUFDVCx5QkFBeUIsQ0FDMUIsQ0FBQztRQUNGLE9BQU8sSUFBSSw0QkFBWSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsY0FBYztZQUM3QixTQUFTLEVBQUUsb0JBQW9CO1lBQy9CLFFBQVE7WUFDUixTQUFTO1NBQ1YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUNELE1BQU0sQ0FDSixJQU1DO1FBTUQsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFBLG1DQUFtQixFQUNqRCxjQUFjLEVBQ2Qsb0JBQW9CLEVBQ3BCLGNBQWMsRUFDZCxJQUFJLENBQUMsTUFBTSxFQUNYLElBQUksQ0FBQyxLQUFLLEVBQ1YsSUFBSSxDQUFDLElBQUksRUFDVCx5QkFBeUIsQ0FDMUIsQ0FBQztRQUNGLE9BQU8sSUFBSSw0QkFBWSxDQUFDO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsY0FBYztZQUM3QixTQUFTLEVBQUUsb0JBQW9CO1lBQy9CLFFBQVE7WUFDUixTQUFTO1NBQ1YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUNELE1BQU0sQ0FDSixJQUVFO1FBUUYsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsR0FBRyxJQUFBLG1DQUFtQixFQUNqRCxjQUFjLEVBQ2Qsb0JBQW9CLEVBQ3BCLGNBQWMsRUFDZCxJQUFJLENBQUMsS0FBSyxFQUNWLHlCQUF5QixDQUMxQixDQUFDO1FBQ0YsT0FBTyxJQUFJLDRCQUFZLENBQUM7WUFDdEIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxjQUFjO1lBQzdCLFNBQVMsRUFBRSxvQkFBb0I7WUFDL0IsUUFBUTtZQUNSLFNBQVM7U0FDVixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFwSkQsOENBb0pDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBcGlFeHRlbnNpb24gbW9kZWwgZm9yIE9STSBjbGllbnRcbiAqIEBnZW5lcmF0ZWQgYnkgQGNvbnN0cnVjdGl2ZS1pby9ncmFwaHFsLWNvZGVnZW5cbiAqIERPIE5PVCBFRElUIC0gY2hhbmdlcyB3aWxsIGJlIG92ZXJ3cml0dGVuXG4gKi9cbmltcG9ydCB7IE9ybUNsaWVudCB9IGZyb20gJy4uL2NsaWVudCc7XG5pbXBvcnQge1xuICBRdWVyeUJ1aWxkZXIsXG4gIGJ1aWxkRmluZE1hbnlEb2N1bWVudCxcbiAgYnVpbGRGaW5kRmlyc3REb2N1bWVudCxcbiAgYnVpbGRDcmVhdGVEb2N1bWVudCxcbiAgYnVpbGRVcGRhdGVEb2N1bWVudCxcbiAgYnVpbGREZWxldGVEb2N1bWVudCxcbn0gZnJvbSAnLi4vcXVlcnktYnVpbGRlcic7XG5pbXBvcnQgdHlwZSB7XG4gIENvbm5lY3Rpb25SZXN1bHQsXG4gIEZpbmRNYW55QXJncyxcbiAgRmluZEZpcnN0QXJncyxcbiAgQ3JlYXRlQXJncyxcbiAgVXBkYXRlQXJncyxcbiAgRGVsZXRlQXJncyxcbiAgSW5mZXJTZWxlY3RSZXN1bHQsXG4gIERlZXBFeGFjdCxcbn0gZnJvbSAnLi4vc2VsZWN0LXR5cGVzJztcbmltcG9ydCB0eXBlIHtcbiAgQXBpRXh0ZW5zaW9uLFxuICBBcGlFeHRlbnNpb25XaXRoUmVsYXRpb25zLFxuICBBcGlFeHRlbnNpb25TZWxlY3QsXG4gIEFwaUV4dGVuc2lvbkZpbHRlcixcbiAgQXBpRXh0ZW5zaW9uc09yZGVyQnksXG4gIENyZWF0ZUFwaUV4dGVuc2lvbklucHV0LFxuICBVcGRhdGVBcGlFeHRlbnNpb25JbnB1dCxcbiAgQXBpRXh0ZW5zaW9uUGF0Y2gsXG59IGZyb20gJy4uL2lucHV0LXR5cGVzJztcbmV4cG9ydCBjbGFzcyBBcGlFeHRlbnNpb25Nb2RlbCB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2xpZW50OiBPcm1DbGllbnQpIHt9XG4gIGZpbmRNYW55PGNvbnN0IFMgZXh0ZW5kcyBBcGlFeHRlbnNpb25TZWxlY3Q+KFxuICAgIGFyZ3M/OiBGaW5kTWFueUFyZ3M8XG4gICAgICBEZWVwRXhhY3Q8UywgQXBpRXh0ZW5zaW9uU2VsZWN0PixcbiAgICAgIEFwaUV4dGVuc2lvbkZpbHRlcixcbiAgICAgIEFwaUV4dGVuc2lvbnNPcmRlckJ5XG4gICAgPixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICBhcGlFeHRlbnNpb25zOiBDb25uZWN0aW9uUmVzdWx0PFxuICAgICAgSW5mZXJTZWxlY3RSZXN1bHQ8QXBpRXh0ZW5zaW9uV2l0aFJlbGF0aW9ucywgUz5cbiAgICA+O1xuICB9PiB7XG4gICAgY29uc3QgeyBkb2N1bWVudCwgdmFyaWFibGVzIH0gPSBidWlsZEZpbmRNYW55RG9jdW1lbnQoXG4gICAgICAnQXBpRXh0ZW5zaW9uJyxcbiAgICAgICdhcGlFeHRlbnNpb25zJyxcbiAgICAgIGFyZ3M/LnNlbGVjdCxcbiAgICAgIHtcbiAgICAgICAgd2hlcmU6IGFyZ3M/LndoZXJlLFxuICAgICAgICBvcmRlckJ5OiBhcmdzPy5vcmRlckJ5IGFzIHN0cmluZ1tdIHwgdW5kZWZpbmVkLFxuICAgICAgICBmaXJzdDogYXJncz8uZmlyc3QsXG4gICAgICAgIGxhc3Q6IGFyZ3M/Lmxhc3QsXG4gICAgICAgIGFmdGVyOiBhcmdzPy5hZnRlcixcbiAgICAgICAgYmVmb3JlOiBhcmdzPy5iZWZvcmUsXG4gICAgICAgIG9mZnNldDogYXJncz8ub2Zmc2V0LFxuICAgICAgfSxcbiAgICAgICdBcGlFeHRlbnNpb25GaWx0ZXInLFxuICAgICAgJ0FwaUV4dGVuc2lvbnNPcmRlckJ5JyxcbiAgICApO1xuICAgIHJldHVybiBuZXcgUXVlcnlCdWlsZGVyKHtcbiAgICAgIGNsaWVudDogdGhpcy5jbGllbnQsXG4gICAgICBvcGVyYXRpb246ICdxdWVyeScsXG4gICAgICBvcGVyYXRpb25OYW1lOiAnQXBpRXh0ZW5zaW9uJyxcbiAgICAgIGZpZWxkTmFtZTogJ2FwaUV4dGVuc2lvbnMnLFxuICAgICAgZG9jdW1lbnQsXG4gICAgICB2YXJpYWJsZXMsXG4gICAgfSk7XG4gIH1cbiAgZmluZEZpcnN0PGNvbnN0IFMgZXh0ZW5kcyBBcGlFeHRlbnNpb25TZWxlY3Q+KFxuICAgIGFyZ3M/OiBGaW5kRmlyc3RBcmdzPERlZXBFeGFjdDxTLCBBcGlFeHRlbnNpb25TZWxlY3Q+LCBBcGlFeHRlbnNpb25GaWx0ZXI+LFxuICApOiBRdWVyeUJ1aWxkZXI8e1xuICAgIGFwaUV4dGVuc2lvbnM6IHtcbiAgICAgIG5vZGVzOiBJbmZlclNlbGVjdFJlc3VsdDxBcGlFeHRlbnNpb25XaXRoUmVsYXRpb25zLCBTPltdO1xuICAgIH07XG4gIH0+IHtcbiAgICBjb25zdCB7IGRvY3VtZW50LCB2YXJpYWJsZXMgfSA9IGJ1aWxkRmluZEZpcnN0RG9jdW1lbnQoXG4gICAgICAnQXBpRXh0ZW5zaW9uJyxcbiAgICAgICdhcGlFeHRlbnNpb25zJyxcbiAgICAgIGFyZ3M/LnNlbGVjdCxcbiAgICAgIHtcbiAgICAgICAgd2hlcmU6IGFyZ3M/LndoZXJlLFxuICAgICAgfSxcbiAgICAgICdBcGlFeHRlbnNpb25GaWx0ZXInLFxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBRdWVyeUJ1aWxkZXIoe1xuICAgICAgY2xpZW50OiB0aGlzLmNsaWVudCxcbiAgICAgIG9wZXJhdGlvbjogJ3F1ZXJ5JyxcbiAgICAgIG9wZXJhdGlvbk5hbWU6ICdBcGlFeHRlbnNpb24nLFxuICAgICAgZmllbGROYW1lOiAnYXBpRXh0ZW5zaW9ucycsXG4gICAgICBkb2N1bWVudCxcbiAgICAgIHZhcmlhYmxlcyxcbiAgICB9KTtcbiAgfVxuICBjcmVhdGU8Y29uc3QgUyBleHRlbmRzIEFwaUV4dGVuc2lvblNlbGVjdD4oXG4gICAgYXJnczogQ3JlYXRlQXJnczxcbiAgICAgIERlZXBFeGFjdDxTLCBBcGlFeHRlbnNpb25TZWxlY3Q+LFxuICAgICAgQ3JlYXRlQXBpRXh0ZW5zaW9uSW5wdXRbJ2FwaUV4dGVuc2lvbiddXG4gICAgPixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICBjcmVhdGVBcGlFeHRlbnNpb246IHtcbiAgICAgIGFwaUV4dGVuc2lvbjogSW5mZXJTZWxlY3RSZXN1bHQ8QXBpRXh0ZW5zaW9uV2l0aFJlbGF0aW9ucywgUz47XG4gICAgfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGRDcmVhdGVEb2N1bWVudChcbiAgICAgICdBcGlFeHRlbnNpb24nLFxuICAgICAgJ2NyZWF0ZUFwaUV4dGVuc2lvbicsXG4gICAgICAnYXBpRXh0ZW5zaW9uJyxcbiAgICAgIGFyZ3Muc2VsZWN0LFxuICAgICAgYXJncy5kYXRhLFxuICAgICAgJ0NyZWF0ZUFwaUV4dGVuc2lvbklucHV0JyxcbiAgICApO1xuICAgIHJldHVybiBuZXcgUXVlcnlCdWlsZGVyKHtcbiAgICAgIGNsaWVudDogdGhpcy5jbGllbnQsXG4gICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICBvcGVyYXRpb25OYW1lOiAnQXBpRXh0ZW5zaW9uJyxcbiAgICAgIGZpZWxkTmFtZTogJ2NyZWF0ZUFwaUV4dGVuc2lvbicsXG4gICAgICBkb2N1bWVudCxcbiAgICAgIHZhcmlhYmxlcyxcbiAgICB9KTtcbiAgfVxuICB1cGRhdGU8Y29uc3QgUyBleHRlbmRzIEFwaUV4dGVuc2lvblNlbGVjdD4oXG4gICAgYXJnczogVXBkYXRlQXJnczxcbiAgICAgIERlZXBFeGFjdDxTLCBBcGlFeHRlbnNpb25TZWxlY3Q+LFxuICAgICAge1xuICAgICAgICBpZDogc3RyaW5nO1xuICAgICAgfSxcbiAgICAgIEFwaUV4dGVuc2lvblBhdGNoXG4gICAgPixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICB1cGRhdGVBcGlFeHRlbnNpb246IHtcbiAgICAgIGFwaUV4dGVuc2lvbjogSW5mZXJTZWxlY3RSZXN1bHQ8QXBpRXh0ZW5zaW9uV2l0aFJlbGF0aW9ucywgUz47XG4gICAgfTtcbiAgfT4ge1xuICAgIGNvbnN0IHsgZG9jdW1lbnQsIHZhcmlhYmxlcyB9ID0gYnVpbGRVcGRhdGVEb2N1bWVudChcbiAgICAgICdBcGlFeHRlbnNpb24nLFxuICAgICAgJ3VwZGF0ZUFwaUV4dGVuc2lvbicsXG4gICAgICAnYXBpRXh0ZW5zaW9uJyxcbiAgICAgIGFyZ3Muc2VsZWN0LFxuICAgICAgYXJncy53aGVyZSxcbiAgICAgIGFyZ3MuZGF0YSxcbiAgICAgICdVcGRhdGVBcGlFeHRlbnNpb25JbnB1dCcsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5QnVpbGRlcih7XG4gICAgICBjbGllbnQ6IHRoaXMuY2xpZW50LFxuICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgb3BlcmF0aW9uTmFtZTogJ0FwaUV4dGVuc2lvbicsXG4gICAgICBmaWVsZE5hbWU6ICd1cGRhdGVBcGlFeHRlbnNpb24nLFxuICAgICAgZG9jdW1lbnQsXG4gICAgICB2YXJpYWJsZXMsXG4gICAgfSk7XG4gIH1cbiAgZGVsZXRlKFxuICAgIGFyZ3M6IERlbGV0ZUFyZ3M8e1xuICAgICAgaWQ6IHN0cmluZztcbiAgICB9PixcbiAgKTogUXVlcnlCdWlsZGVyPHtcbiAgICBkZWxldGVBcGlFeHRlbnNpb246IHtcbiAgICAgIGFwaUV4dGVuc2lvbjoge1xuICAgICAgICBpZDogc3RyaW5nO1xuICAgICAgfTtcbiAgICB9O1xuICB9PiB7XG4gICAgY29uc3QgeyBkb2N1bWVudCwgdmFyaWFibGVzIH0gPSBidWlsZERlbGV0ZURvY3VtZW50KFxuICAgICAgJ0FwaUV4dGVuc2lvbicsXG4gICAgICAnZGVsZXRlQXBpRXh0ZW5zaW9uJyxcbiAgICAgICdhcGlFeHRlbnNpb24nLFxuICAgICAgYXJncy53aGVyZSxcbiAgICAgICdEZWxldGVBcGlFeHRlbnNpb25JbnB1dCcsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5QnVpbGRlcih7XG4gICAgICBjbGllbnQ6IHRoaXMuY2xpZW50LFxuICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgb3BlcmF0aW9uTmFtZTogJ0FwaUV4dGVuc2lvbicsXG4gICAgICBmaWVsZE5hbWU6ICdkZWxldGVBcGlFeHRlbnNpb24nLFxuICAgICAgZG9jdW1lbnQsXG4gICAgICB2YXJpYWJsZXMsXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==