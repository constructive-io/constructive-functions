"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMutationOperations = createMutationOperations;
const query_builder_1 = require("../query-builder");
function createMutationOperations(client) {
    return {
        updateCheckConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateCheckConstraintByTableIdAndName',
            fieldName: 'updateCheckConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateCheckConstraintByTableIdAndName', 'updateCheckConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateCheckConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        updateDatabaseBySchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateDatabaseBySchemaName',
            fieldName: 'updateDatabaseBySchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateDatabaseBySchemaName', 'updateDatabaseBySchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateDatabaseBySchemaNameInput!',
                },
            ]),
        }),
        updateDatabaseByPrivateSchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateDatabaseByPrivateSchemaName',
            fieldName: 'updateDatabaseByPrivateSchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateDatabaseByPrivateSchemaName', 'updateDatabaseByPrivateSchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateDatabaseByPrivateSchemaNameInput!',
                },
            ]),
        }),
        updateDatabaseExtensionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateDatabaseExtensionByDatabaseIdAndName',
            fieldName: 'updateDatabaseExtensionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateDatabaseExtensionByDatabaseIdAndName', 'updateDatabaseExtensionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateDatabaseExtensionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateFieldByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateFieldByTableIdAndName',
            fieldName: 'updateFieldByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateFieldByTableIdAndName', 'updateFieldByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateFieldByTableIdAndNameInput!',
                },
            ]),
        }),
        updateForeignKeyConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateForeignKeyConstraintByTableIdAndName',
            fieldName: 'updateForeignKeyConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateForeignKeyConstraintByTableIdAndName', 'updateForeignKeyConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateForeignKeyConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        updateIndexByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateIndexByDatabaseIdAndName',
            fieldName: 'updateIndexByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateIndexByDatabaseIdAndName', 'updateIndexByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateIndexByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateLimitFunctionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateLimitFunctionByDatabaseIdAndName',
            fieldName: 'updateLimitFunctionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateLimitFunctionByDatabaseIdAndName', 'updateLimitFunctionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateLimitFunctionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateNodeTypeRegistryBySlug: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateNodeTypeRegistryBySlug',
            fieldName: 'updateNodeTypeRegistryBySlug',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateNodeTypeRegistryBySlug', 'updateNodeTypeRegistryBySlug', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateNodeTypeRegistryBySlugInput!',
                },
            ]),
        }),
        updatePolicyByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdatePolicyByTableIdAndName',
            fieldName: 'updatePolicyByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdatePolicyByTableIdAndName', 'updatePolicyByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdatePolicyByTableIdAndNameInput!',
                },
            ]),
        }),
        updatePrimaryKeyConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdatePrimaryKeyConstraintByTableIdAndName',
            fieldName: 'updatePrimaryKeyConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdatePrimaryKeyConstraintByTableIdAndName', 'updatePrimaryKeyConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdatePrimaryKeyConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        updateProcedureByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateProcedureByDatabaseIdAndName',
            fieldName: 'updateProcedureByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateProcedureByDatabaseIdAndName', 'updateProcedureByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateProcedureByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateSchemaByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateSchemaByDatabaseIdAndName',
            fieldName: 'updateSchemaByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateSchemaByDatabaseIdAndName', 'updateSchemaByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateSchemaByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateSchemaBySchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateSchemaBySchemaName',
            fieldName: 'updateSchemaBySchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateSchemaBySchemaName', 'updateSchemaBySchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateSchemaBySchemaNameInput!',
                },
            ]),
        }),
        updateTableByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateTableByDatabaseIdAndName',
            fieldName: 'updateTableByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateTableByDatabaseIdAndName', 'updateTableByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateTableByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateTriggerByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateTriggerByTableIdAndName',
            fieldName: 'updateTriggerByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateTriggerByTableIdAndName', 'updateTriggerByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateTriggerByTableIdAndNameInput!',
                },
            ]),
        }),
        updateTriggerFunctionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateTriggerFunctionByDatabaseIdAndName',
            fieldName: 'updateTriggerFunctionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateTriggerFunctionByDatabaseIdAndName', 'updateTriggerFunctionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateTriggerFunctionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateUniqueConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateUniqueConstraintByTableIdAndName',
            fieldName: 'updateUniqueConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateUniqueConstraintByTableIdAndName', 'updateUniqueConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateUniqueConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        updateAstActionByDatabaseIdAndDeploys: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateAstActionByDatabaseIdAndDeploys',
            fieldName: 'updateAstActionByDatabaseIdAndDeploys',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateAstActionByDatabaseIdAndDeploys', 'updateAstActionByDatabaseIdAndDeploys', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateAstActionByDatabaseIdAndDeploysInput!',
                },
            ]),
        }),
        updateApiExtensionBySchemaNameAndApiId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateApiExtensionBySchemaNameAndApiId',
            fieldName: 'updateApiExtensionBySchemaNameAndApiId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateApiExtensionBySchemaNameAndApiId', 'updateApiExtensionBySchemaNameAndApiId', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateApiExtensionBySchemaNameAndApiIdInput!',
                },
            ]),
        }),
        updateApiSchemaByApiIdAndSchemaId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateApiSchemaByApiIdAndSchemaId',
            fieldName: 'updateApiSchemaByApiIdAndSchemaId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateApiSchemaByApiIdAndSchemaId', 'updateApiSchemaByApiIdAndSchemaId', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateApiSchemaByApiIdAndSchemaIdInput!',
                },
            ]),
        }),
        updateApiByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateApiByDatabaseIdAndName',
            fieldName: 'updateApiByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateApiByDatabaseIdAndName', 'updateApiByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateApiByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        updateAppBySiteId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateAppBySiteId',
            fieldName: 'updateAppBySiteId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateAppBySiteId', 'updateAppBySiteId', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateAppBySiteIdInput!',
                },
            ]),
        }),
        updateDomainBySubdomainAndDomain: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateDomainBySubdomainAndDomain',
            fieldName: 'updateDomainBySubdomainAndDomain',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateDomainBySubdomainAndDomain', 'updateDomainBySubdomainAndDomain', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateDomainBySubdomainAndDomainInput!',
                },
            ]),
        }),
        updateHierarchyModuleByDatabaseId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateHierarchyModuleByDatabaseId',
            fieldName: 'updateHierarchyModuleByDatabaseId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateHierarchyModuleByDatabaseId', 'updateHierarchyModuleByDatabaseId', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateHierarchyModuleByDatabaseIdInput!',
                },
            ]),
        }),
        updateProfilesModuleByDatabaseIdAndMembershipType: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateProfilesModuleByDatabaseIdAndMembershipType',
            fieldName: 'updateProfilesModuleByDatabaseIdAndMembershipType',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateProfilesModuleByDatabaseIdAndMembershipType', 'updateProfilesModuleByDatabaseIdAndMembershipType', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateProfilesModuleByDatabaseIdAndMembershipTypeInput!',
                },
            ]),
        }),
        updateRlsModuleByApiId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateRlsModuleByApiId',
            fieldName: 'updateRlsModuleByApiId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateRlsModuleByApiId', 'updateRlsModuleByApiId', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateRlsModuleByApiIdInput!',
                },
            ]),
        }),
        updateRoleTypeByName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateRoleTypeByName',
            fieldName: 'updateRoleTypeByName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateRoleTypeByName', 'updateRoleTypeByName', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateRoleTypeByNameInput!',
                },
            ]),
        }),
        updateUserByUsername: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateUserByUsername',
            fieldName: 'updateUserByUsername',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateUserByUsername', 'updateUserByUsername', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateUserByUsernameInput!',
                },
            ]),
        }),
        updateConnectedAccountByServiceAndIdentifier: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateConnectedAccountByServiceAndIdentifier',
            fieldName: 'updateConnectedAccountByServiceAndIdentifier',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateConnectedAccountByServiceAndIdentifier', 'updateConnectedAccountByServiceAndIdentifier', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateConnectedAccountByServiceAndIdentifierInput!',
                },
            ]),
        }),
        updateCryptoAddressByAddress: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateCryptoAddressByAddress',
            fieldName: 'updateCryptoAddressByAddress',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateCryptoAddressByAddress', 'updateCryptoAddressByAddress', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateCryptoAddressByAddressInput!',
                },
            ]),
        }),
        updateEmailByEmail: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateEmailByEmail',
            fieldName: 'updateEmailByEmail',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateEmailByEmail', 'updateEmailByEmail', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateEmailByEmailInput!',
                },
            ]),
        }),
        updatePhoneNumberByNumber: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdatePhoneNumberByNumber',
            fieldName: 'updatePhoneNumberByNumber',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdatePhoneNumberByNumber', 'updatePhoneNumberByNumber', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdatePhoneNumberByNumberInput!',
                },
            ]),
        }),
        deleteCheckConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteCheckConstraintByTableIdAndName',
            fieldName: 'deleteCheckConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteCheckConstraintByTableIdAndName', 'deleteCheckConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteCheckConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteDatabaseBySchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteDatabaseBySchemaName',
            fieldName: 'deleteDatabaseBySchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteDatabaseBySchemaName', 'deleteDatabaseBySchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteDatabaseBySchemaNameInput!',
                },
            ]),
        }),
        deleteDatabaseByPrivateSchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteDatabaseByPrivateSchemaName',
            fieldName: 'deleteDatabaseByPrivateSchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteDatabaseByPrivateSchemaName', 'deleteDatabaseByPrivateSchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteDatabaseByPrivateSchemaNameInput!',
                },
            ]),
        }),
        deleteDatabaseExtensionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteDatabaseExtensionByDatabaseIdAndName',
            fieldName: 'deleteDatabaseExtensionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteDatabaseExtensionByDatabaseIdAndName', 'deleteDatabaseExtensionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteDatabaseExtensionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteFieldByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteFieldByTableIdAndName',
            fieldName: 'deleteFieldByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteFieldByTableIdAndName', 'deleteFieldByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteFieldByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteForeignKeyConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteForeignKeyConstraintByTableIdAndName',
            fieldName: 'deleteForeignKeyConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteForeignKeyConstraintByTableIdAndName', 'deleteForeignKeyConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteForeignKeyConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteIndexByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteIndexByDatabaseIdAndName',
            fieldName: 'deleteIndexByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteIndexByDatabaseIdAndName', 'deleteIndexByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteIndexByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteLimitFunctionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteLimitFunctionByDatabaseIdAndName',
            fieldName: 'deleteLimitFunctionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteLimitFunctionByDatabaseIdAndName', 'deleteLimitFunctionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteLimitFunctionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteNodeTypeRegistryBySlug: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteNodeTypeRegistryBySlug',
            fieldName: 'deleteNodeTypeRegistryBySlug',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteNodeTypeRegistryBySlug', 'deleteNodeTypeRegistryBySlug', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteNodeTypeRegistryBySlugInput!',
                },
            ]),
        }),
        deletePolicyByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeletePolicyByTableIdAndName',
            fieldName: 'deletePolicyByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeletePolicyByTableIdAndName', 'deletePolicyByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeletePolicyByTableIdAndNameInput!',
                },
            ]),
        }),
        deletePrimaryKeyConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeletePrimaryKeyConstraintByTableIdAndName',
            fieldName: 'deletePrimaryKeyConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeletePrimaryKeyConstraintByTableIdAndName', 'deletePrimaryKeyConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeletePrimaryKeyConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteProcedureByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteProcedureByDatabaseIdAndName',
            fieldName: 'deleteProcedureByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteProcedureByDatabaseIdAndName', 'deleteProcedureByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteProcedureByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteSchemaByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteSchemaByDatabaseIdAndName',
            fieldName: 'deleteSchemaByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteSchemaByDatabaseIdAndName', 'deleteSchemaByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteSchemaByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteSchemaBySchemaName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteSchemaBySchemaName',
            fieldName: 'deleteSchemaBySchemaName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteSchemaBySchemaName', 'deleteSchemaBySchemaName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteSchemaBySchemaNameInput!',
                },
            ]),
        }),
        deleteTableByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteTableByDatabaseIdAndName',
            fieldName: 'deleteTableByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteTableByDatabaseIdAndName', 'deleteTableByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteTableByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteTriggerByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteTriggerByTableIdAndName',
            fieldName: 'deleteTriggerByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteTriggerByTableIdAndName', 'deleteTriggerByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteTriggerByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteTriggerFunctionByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteTriggerFunctionByDatabaseIdAndName',
            fieldName: 'deleteTriggerFunctionByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteTriggerFunctionByDatabaseIdAndName', 'deleteTriggerFunctionByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteTriggerFunctionByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteUniqueConstraintByTableIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteUniqueConstraintByTableIdAndName',
            fieldName: 'deleteUniqueConstraintByTableIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteUniqueConstraintByTableIdAndName', 'deleteUniqueConstraintByTableIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteUniqueConstraintByTableIdAndNameInput!',
                },
            ]),
        }),
        deleteAstActionByDatabaseIdAndDeploys: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteAstActionByDatabaseIdAndDeploys',
            fieldName: 'deleteAstActionByDatabaseIdAndDeploys',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteAstActionByDatabaseIdAndDeploys', 'deleteAstActionByDatabaseIdAndDeploys', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteAstActionByDatabaseIdAndDeploysInput!',
                },
            ]),
        }),
        deleteApiExtensionBySchemaNameAndApiId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteApiExtensionBySchemaNameAndApiId',
            fieldName: 'deleteApiExtensionBySchemaNameAndApiId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteApiExtensionBySchemaNameAndApiId', 'deleteApiExtensionBySchemaNameAndApiId', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteApiExtensionBySchemaNameAndApiIdInput!',
                },
            ]),
        }),
        deleteApiSchemaByApiIdAndSchemaId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteApiSchemaByApiIdAndSchemaId',
            fieldName: 'deleteApiSchemaByApiIdAndSchemaId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteApiSchemaByApiIdAndSchemaId', 'deleteApiSchemaByApiIdAndSchemaId', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteApiSchemaByApiIdAndSchemaIdInput!',
                },
            ]),
        }),
        deleteApiByDatabaseIdAndName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteApiByDatabaseIdAndName',
            fieldName: 'deleteApiByDatabaseIdAndName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteApiByDatabaseIdAndName', 'deleteApiByDatabaseIdAndName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteApiByDatabaseIdAndNameInput!',
                },
            ]),
        }),
        deleteAppBySiteId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteAppBySiteId',
            fieldName: 'deleteAppBySiteId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteAppBySiteId', 'deleteAppBySiteId', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteAppBySiteIdInput!',
                },
            ]),
        }),
        deleteDomainBySubdomainAndDomain: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteDomainBySubdomainAndDomain',
            fieldName: 'deleteDomainBySubdomainAndDomain',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteDomainBySubdomainAndDomain', 'deleteDomainBySubdomainAndDomain', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteDomainBySubdomainAndDomainInput!',
                },
            ]),
        }),
        deleteHierarchyModuleByDatabaseId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteHierarchyModuleByDatabaseId',
            fieldName: 'deleteHierarchyModuleByDatabaseId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteHierarchyModuleByDatabaseId', 'deleteHierarchyModuleByDatabaseId', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteHierarchyModuleByDatabaseIdInput!',
                },
            ]),
        }),
        deleteProfilesModuleByDatabaseIdAndMembershipType: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteProfilesModuleByDatabaseIdAndMembershipType',
            fieldName: 'deleteProfilesModuleByDatabaseIdAndMembershipType',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteProfilesModuleByDatabaseIdAndMembershipType', 'deleteProfilesModuleByDatabaseIdAndMembershipType', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteProfilesModuleByDatabaseIdAndMembershipTypeInput!',
                },
            ]),
        }),
        deleteRlsModuleByApiId: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteRlsModuleByApiId',
            fieldName: 'deleteRlsModuleByApiId',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteRlsModuleByApiId', 'deleteRlsModuleByApiId', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteRlsModuleByApiIdInput!',
                },
            ]),
        }),
        deleteRoleTypeByName: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteRoleTypeByName',
            fieldName: 'deleteRoleTypeByName',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteRoleTypeByName', 'deleteRoleTypeByName', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteRoleTypeByNameInput!',
                },
            ]),
        }),
        deleteUserByUsername: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteUserByUsername',
            fieldName: 'deleteUserByUsername',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteUserByUsername', 'deleteUserByUsername', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteUserByUsernameInput!',
                },
            ]),
        }),
        deleteConnectedAccountByServiceAndIdentifier: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteConnectedAccountByServiceAndIdentifier',
            fieldName: 'deleteConnectedAccountByServiceAndIdentifier',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteConnectedAccountByServiceAndIdentifier', 'deleteConnectedAccountByServiceAndIdentifier', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteConnectedAccountByServiceAndIdentifierInput!',
                },
            ]),
        }),
        deleteCryptoAddressByAddress: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteCryptoAddressByAddress',
            fieldName: 'deleteCryptoAddressByAddress',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteCryptoAddressByAddress', 'deleteCryptoAddressByAddress', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteCryptoAddressByAddressInput!',
                },
            ]),
        }),
        deleteEmailByEmail: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeleteEmailByEmail',
            fieldName: 'deleteEmailByEmail',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeleteEmailByEmail', 'deleteEmailByEmail', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeleteEmailByEmailInput!',
                },
            ]),
        }),
        deletePhoneNumberByNumber: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DeletePhoneNumberByNumber',
            fieldName: 'deletePhoneNumberByNumber',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DeletePhoneNumberByNumber', 'deletePhoneNumberByNumber', options?.select, args, [
                {
                    name: 'input',
                    type: 'DeletePhoneNumberByNumberInput!',
                },
            ]),
        }),
        applyRls: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ApplyRls',
            fieldName: 'applyRls',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ApplyRls', 'applyRls', options?.select, args, [
                {
                    name: 'input',
                    type: 'ApplyRlsInput!',
                },
            ]),
        }),
        bootstrapUser: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'BootstrapUser',
            fieldName: 'bootstrapUser',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'BootstrapUser', 'bootstrapUser', options?.select, args, [
                {
                    name: 'input',
                    type: 'BootstrapUserInput!',
                },
            ]),
        }),
        createUserDatabase: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateUserDatabase',
            fieldName: 'createUserDatabase',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateUserDatabase', 'createUserDatabase', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateUserDatabaseInput!',
                },
            ]),
        }),
        provisionDatabaseWithUser: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ProvisionDatabaseWithUser',
            fieldName: 'provisionDatabaseWithUser',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ProvisionDatabaseWithUser', 'provisionDatabaseWithUser', options?.select, args, [
                {
                    name: 'input',
                    type: 'ProvisionDatabaseWithUserInput!',
                },
            ]),
        }),
        setFieldOrder: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetFieldOrder',
            fieldName: 'setFieldOrder',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetFieldOrder', 'setFieldOrder', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetFieldOrderInput!',
                },
            ]),
        }),
        freezeObjects: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'FreezeObjects',
            fieldName: 'freezeObjects',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'FreezeObjects', 'freezeObjects', options?.select, args, [
                {
                    name: 'input',
                    type: 'FreezeObjectsInput!',
                },
            ]),
        }),
        insertNodeAtPath: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'InsertNodeAtPath',
            fieldName: 'insertNodeAtPath',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'InsertNodeAtPath', 'insertNodeAtPath', options?.select, args, [
                {
                    name: 'input',
                    type: 'InsertNodeAtPathInput!',
                },
            ]),
        }),
        removeNodeAtPath: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RemoveNodeAtPath',
            fieldName: 'removeNodeAtPath',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RemoveNodeAtPath', 'removeNodeAtPath', options?.select, args, [
                {
                    name: 'input',
                    type: 'RemoveNodeAtPathInput!',
                },
            ]),
        }),
        setDataAtPath: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetDataAtPath',
            fieldName: 'setDataAtPath',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetDataAtPath', 'setDataAtPath', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetDataAtPathInput!',
                },
            ]),
        }),
        updateNodeAtPath: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'UpdateNodeAtPath',
            fieldName: 'updateNodeAtPath',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'UpdateNodeAtPath', 'updateNodeAtPath', options?.select, args, [
                {
                    name: 'input',
                    type: 'UpdateNodeAtPathInput!',
                },
            ]),
        }),
        initEmptyRepo: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'InitEmptyRepo',
            fieldName: 'initEmptyRepo',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'InitEmptyRepo', 'initEmptyRepo', options?.select, args, [
                {
                    name: 'input',
                    type: 'InitEmptyRepoInput!',
                },
            ]),
        }),
        setAndCommit: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetAndCommit',
            fieldName: 'setAndCommit',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetAndCommit', 'setAndCommit', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetAndCommitInput!',
                },
            ]),
        }),
        setPropsAndCommit: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetPropsAndCommit',
            fieldName: 'setPropsAndCommit',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetPropsAndCommit', 'setPropsAndCommit', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetPropsAndCommitInput!',
                },
            ]),
        }),
        addConstraintNoopImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddConstraintNoopImport',
            fieldName: 'addConstraintNoopImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddConstraintNoopImport', 'addConstraintNoopImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddConstraintNoopImportInput!',
                },
            ]),
        }),
        addImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddImport',
            fieldName: 'addImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddImport', 'addImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddImportInput!',
                },
            ]),
        }),
        addSchemaImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddSchemaImport',
            fieldName: 'addSchemaImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddSchemaImport', 'addSchemaImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddSchemaImportInput!',
                },
            ]),
        }),
        addSchemaNoopImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddSchemaNoopImport',
            fieldName: 'addSchemaNoopImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddSchemaNoopImport', 'addSchemaNoopImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddSchemaNoopImportInput!',
                },
            ]),
        }),
        addTableImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddTableImport',
            fieldName: 'addTableImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddTableImport', 'addTableImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddTableImportInput!',
                },
            ]),
        }),
        addTableNoopImport: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AddTableNoopImport',
            fieldName: 'addTableNoopImport',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AddTableNoopImport', 'addTableNoopImport', options?.select, args, [
                {
                    name: 'input',
                    type: 'AddTableNoopImportInput!',
                },
            ]),
        }),
        alterDefaultPrivilegesGrantOnFunctions: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterDefaultPrivilegesGrantOnFunctions',
            fieldName: 'alterDefaultPrivilegesGrantOnFunctions',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterDefaultPrivilegesGrantOnFunctions', 'alterDefaultPrivilegesGrantOnFunctions', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterDefaultPrivilegesGrantOnFunctionsInput!',
                },
            ]),
        }),
        alterDefaultPrivilegesGrantOnSequences: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterDefaultPrivilegesGrantOnSequences',
            fieldName: 'alterDefaultPrivilegesGrantOnSequences',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterDefaultPrivilegesGrantOnSequences', 'alterDefaultPrivilegesGrantOnSequences', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterDefaultPrivilegesGrantOnSequencesInput!',
                },
            ]),
        }),
        alterDefaultPrivilegesGrantOnTables: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterDefaultPrivilegesGrantOnTables',
            fieldName: 'alterDefaultPrivilegesGrantOnTables',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterDefaultPrivilegesGrantOnTables', 'alterDefaultPrivilegesGrantOnTables', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterDefaultPrivilegesGrantOnTablesInput!',
                },
            ]),
        }),
        alterDefaultPrivilegesRevokeOnSequences: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterDefaultPrivilegesRevokeOnSequences',
            fieldName: 'alterDefaultPrivilegesRevokeOnSequences',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterDefaultPrivilegesRevokeOnSequences', 'alterDefaultPrivilegesRevokeOnSequences', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterDefaultPrivilegesRevokeOnSequencesInput!',
                },
            ]),
        }),
        alterPolicy: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterPolicy',
            fieldName: 'alterPolicy',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterPolicy', 'alterPolicy', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterPolicyInput!',
                },
            ]),
        }),
        alterTableAddCheckConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddCheckConstraint',
            fieldName: 'alterTableAddCheckConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddCheckConstraint', 'alterTableAddCheckConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddCheckConstraintInput!',
                },
            ]),
        }),
        alterTableAddColumn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddColumn',
            fieldName: 'alterTableAddColumn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddColumn', 'alterTableAddColumn', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddColumnInput!',
                },
            ]),
        }),
        alterTableAddForeignKey: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddForeignKey',
            fieldName: 'alterTableAddForeignKey',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddForeignKey', 'alterTableAddForeignKey', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddForeignKeyInput!',
                },
            ]),
        }),
        alterTableAddInherits: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddInherits',
            fieldName: 'alterTableAddInherits',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddInherits', 'alterTableAddInherits', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddInheritsInput!',
                },
            ]),
        }),
        alterTableAddPrimaryKey: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddPrimaryKey',
            fieldName: 'alterTableAddPrimaryKey',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddPrimaryKey', 'alterTableAddPrimaryKey', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddPrimaryKeyInput!',
                },
            ]),
        }),
        alterTableAddUniqueConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableAddUniqueConstraint',
            fieldName: 'alterTableAddUniqueConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableAddUniqueConstraint', 'alterTableAddUniqueConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableAddUniqueConstraintInput!',
                },
            ]),
        }),
        alterTableDropColumn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableDropColumn',
            fieldName: 'alterTableDropColumn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableDropColumn', 'alterTableDropColumn', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableDropColumnInput!',
                },
            ]),
        }),
        alterTableDropColumnDefault: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableDropColumnDefault',
            fieldName: 'alterTableDropColumnDefault',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableDropColumnDefault', 'alterTableDropColumnDefault', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableDropColumnDefaultInput!',
                },
            ]),
        }),
        alterTableDropColumnNotNull: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableDropColumnNotNull',
            fieldName: 'alterTableDropColumnNotNull',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableDropColumnNotNull', 'alterTableDropColumnNotNull', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableDropColumnNotNullInput!',
                },
            ]),
        }),
        alterTableDropConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableDropConstraint',
            fieldName: 'alterTableDropConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableDropConstraint', 'alterTableDropConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableDropConstraintInput!',
                },
            ]),
        }),
        alterTableDropInherits: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableDropInherits',
            fieldName: 'alterTableDropInherits',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableDropInherits', 'alterTableDropInherits', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableDropInheritsInput!',
                },
            ]),
        }),
        alterTableModifyCheckConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableModifyCheckConstraint',
            fieldName: 'alterTableModifyCheckConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableModifyCheckConstraint', 'alterTableModifyCheckConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableModifyCheckConstraintInput!',
                },
            ]),
        }),
        alterTablePermBitlen: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTablePermBitlen',
            fieldName: 'alterTablePermBitlen',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTablePermBitlen', 'alterTablePermBitlen', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTablePermBitlenInput!',
                },
            ]),
        }),
        alterTablePermBitlenDefault: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTablePermBitlenDefault',
            fieldName: 'alterTablePermBitlenDefault',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTablePermBitlenDefault', 'alterTablePermBitlenDefault', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTablePermBitlenDefaultInput!',
                },
            ]),
        }),
        alterTableRenameColumn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableRenameColumn',
            fieldName: 'alterTableRenameColumn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableRenameColumn', 'alterTableRenameColumn', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableRenameColumnInput!',
                },
            ]),
        }),
        alterTableSetColumnDataType: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableSetColumnDataType',
            fieldName: 'alterTableSetColumnDataType',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableSetColumnDataType', 'alterTableSetColumnDataType', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableSetColumnDataTypeInput!',
                },
            ]),
        }),
        alterTableSetColumnDefault: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableSetColumnDefault',
            fieldName: 'alterTableSetColumnDefault',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableSetColumnDefault', 'alterTableSetColumnDefault', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableSetColumnDefaultInput!',
                },
            ]),
        }),
        alterTableSetColumnNotNull: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableSetColumnNotNull',
            fieldName: 'alterTableSetColumnNotNull',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableSetColumnNotNull', 'alterTableSetColumnNotNull', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableSetColumnNotNullInput!',
                },
            ]),
        }),
        alterTableSetSchema: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'AlterTableSetSchema',
            fieldName: 'alterTableSetSchema',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'AlterTableSetSchema', 'alterTableSetSchema', options?.select, args, [
                {
                    name: 'input',
                    type: 'AlterTableSetSchemaInput!',
                },
            ]),
        }),
        createColumn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateColumn',
            fieldName: 'createColumn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateColumn', 'createColumn', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateColumnInput!',
                },
            ]),
        }),
        createFixture: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateFixture',
            fieldName: 'createFixture',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateFixture', 'createFixture', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateFixtureInput!',
                },
            ]),
        }),
        createFunction: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateFunction',
            fieldName: 'createFunction',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateFunction', 'createFunction', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateFunctionInput!',
                },
            ]),
        }),
        createIndexUnsafe: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateIndexUnsafe',
            fieldName: 'createIndexUnsafe',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateIndexUnsafe', 'createIndexUnsafe', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateIndexUnsafeInput!',
                },
            ]),
        }),
        createInsert: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateInsert',
            fieldName: 'createInsert',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateInsert', 'createInsert', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateInsertInput!',
                },
            ]),
        }),
        createTriggerDistinctFields: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CreateTriggerDistinctFields',
            fieldName: 'createTriggerDistinctFields',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CreateTriggerDistinctFields', 'createTriggerDistinctFields', options?.select, args, [
                {
                    name: 'input',
                    type: 'CreateTriggerDistinctFieldsInput!',
                },
            ]),
        }),
        denormalizedFields: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DenormalizedFields',
            fieldName: 'denormalizedFields',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DenormalizedFields', 'denormalizedFields', options?.select, args, [
                {
                    name: 'input',
                    type: 'DenormalizedFieldsInput!',
                },
            ]),
        }),
        disableRowLevelSecurity: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DisableRowLevelSecurity',
            fieldName: 'disableRowLevelSecurity',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DisableRowLevelSecurity', 'disableRowLevelSecurity', options?.select, args, [
                {
                    name: 'input',
                    type: 'DisableRowLevelSecurityInput!',
                },
            ]),
        }),
        dropConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropConstraint',
            fieldName: 'dropConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropConstraint', 'dropConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropConstraintInput!',
                },
            ]),
        }),
        dropFunction: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropFunction',
            fieldName: 'dropFunction',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropFunction', 'dropFunction', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropFunctionInput!',
                },
            ]),
        }),
        dropIndex: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropIndex',
            fieldName: 'dropIndex',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropIndex', 'dropIndex', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropIndexInput!',
                },
            ]),
        }),
        dropPolicy: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropPolicy',
            fieldName: 'dropPolicy',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropPolicy', 'dropPolicy', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropPolicyInput!',
                },
            ]),
        }),
        dropSchema: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropSchema',
            fieldName: 'dropSchema',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropSchema', 'dropSchema', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropSchemaInput!',
                },
            ]),
        }),
        dropTable: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropTable',
            fieldName: 'dropTable',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropTable', 'dropTable', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropTableInput!',
                },
            ]),
        }),
        dropTrigger: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropTrigger',
            fieldName: 'dropTrigger',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropTrigger', 'dropTrigger', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropTriggerInput!',
                },
            ]),
        }),
        dropTriggerFunction: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'DropTriggerFunction',
            fieldName: 'dropTriggerFunction',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'DropTriggerFunction', 'dropTriggerFunction', options?.select, args, [
                {
                    name: 'input',
                    type: 'DropTriggerFunctionInput!',
                },
            ]),
        }),
        enableRowLevelSecurity: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'EnableRowLevelSecurity',
            fieldName: 'enableRowLevelSecurity',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'EnableRowLevelSecurity', 'enableRowLevelSecurity', options?.select, args, [
                {
                    name: 'input',
                    type: 'EnableRowLevelSecurityInput!',
                },
            ]),
        }),
        ensureDefaultValuesInsert: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'EnsureDefaultValuesInsert',
            fieldName: 'ensureDefaultValuesInsert',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'EnsureDefaultValuesInsert', 'ensureDefaultValuesInsert', options?.select, args, [
                {
                    name: 'input',
                    type: 'EnsureDefaultValuesInsertInput!',
                },
            ]),
        }),
        grantUsageOnSchema: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'GrantUsageOnSchema',
            fieldName: 'grantUsageOnSchema',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'GrantUsageOnSchema', 'grantUsageOnSchema', options?.select, args, [
                {
                    name: 'input',
                    type: 'GrantUsageOnSchemaInput!',
                },
            ]),
        }),
        immutableFieldTrigger: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ImmutableFieldTrigger',
            fieldName: 'immutableFieldTrigger',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ImmutableFieldTrigger', 'immutableFieldTrigger', options?.select, args, [
                {
                    name: 'input',
                    type: 'ImmutableFieldTriggerInput!',
                },
            ]),
        }),
        inflectionFieldTrigger: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'InflectionFieldTrigger',
            fieldName: 'inflectionFieldTrigger',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'InflectionFieldTrigger', 'inflectionFieldTrigger', options?.select, args, [
                {
                    name: 'input',
                    type: 'InflectionFieldTriggerInput!',
                },
            ]),
        }),
        insertAction: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'InsertAction',
            fieldName: 'insertAction',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'InsertAction', 'insertAction', options?.select, args, [
                {
                    name: 'input',
                    type: 'InsertActionInput!',
                },
            ]),
        }),
        modifyCheckConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ModifyCheckConstraint',
            fieldName: 'modifyCheckConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ModifyCheckConstraint', 'modifyCheckConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'ModifyCheckConstraintInput!',
                },
            ]),
        }),
        ownedFieldsTrigger: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'OwnedFieldsTrigger',
            fieldName: 'ownedFieldsTrigger',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'OwnedFieldsTrigger', 'ownedFieldsTrigger', options?.select, args, [
                {
                    name: 'input',
                    type: 'OwnedFieldsTriggerInput!',
                },
            ]),
        }),
        peoplestamps: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'Peoplestamps',
            fieldName: 'peoplestamps',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'Peoplestamps', 'peoplestamps', options?.select, args, [
                {
                    name: 'input',
                    type: 'PeoplestampsInput!',
                },
            ]),
        }),
        renameConstraint: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RenameConstraint',
            fieldName: 'renameConstraint',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RenameConstraint', 'renameConstraint', options?.select, args, [
                {
                    name: 'input',
                    type: 'RenameConstraintInput!',
                },
            ]),
        }),
        renameIndex: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RenameIndex',
            fieldName: 'renameIndex',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RenameIndex', 'renameIndex', options?.select, args, [
                {
                    name: 'input',
                    type: 'RenameIndexInput!',
                },
            ]),
        }),
        renameSchema: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RenameSchema',
            fieldName: 'renameSchema',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RenameSchema', 'renameSchema', options?.select, args, [
                {
                    name: 'input',
                    type: 'RenameSchemaInput!',
                },
            ]),
        }),
        renameTable: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RenameTable',
            fieldName: 'renameTable',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RenameTable', 'renameTable', options?.select, args, [
                {
                    name: 'input',
                    type: 'RenameTableInput!',
                },
            ]),
        }),
        revokeUsageOnSchema: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'RevokeUsageOnSchema',
            fieldName: 'revokeUsageOnSchema',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'RevokeUsageOnSchema', 'revokeUsageOnSchema', options?.select, args, [
                {
                    name: 'input',
                    type: 'RevokeUsageOnSchemaInput!',
                },
            ]),
        }),
        setCommentOnColumn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetCommentOnColumn',
            fieldName: 'setCommentOnColumn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetCommentOnColumn', 'setCommentOnColumn', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetCommentOnColumnInput!',
                },
            ]),
        }),
        setCommentOnFunction: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetCommentOnFunction',
            fieldName: 'setCommentOnFunction',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetCommentOnFunction', 'setCommentOnFunction', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetCommentOnFunctionInput!',
                },
            ]),
        }),
        setCommentOnTable: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetCommentOnTable',
            fieldName: 'setCommentOnTable',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetCommentOnTable', 'setCommentOnTable', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetCommentOnTableInput!',
                },
            ]),
        }),
        slugFieldTrigger: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SlugFieldTrigger',
            fieldName: 'slugFieldTrigger',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SlugFieldTrigger', 'slugFieldTrigger', options?.select, args, [
                {
                    name: 'input',
                    type: 'SlugFieldTriggerInput!',
                },
            ]),
        }),
        timestamps: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'Timestamps',
            fieldName: 'timestamps',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'Timestamps', 'timestamps', options?.select, args, [
                {
                    name: 'input',
                    type: 'TimestampsInput!',
                },
            ]),
        }),
        checkPassword: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'CheckPassword',
            fieldName: 'checkPassword',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'CheckPassword', 'checkPassword', options?.select, args, [
                {
                    name: 'input',
                    type: 'CheckPasswordInput!',
                },
            ]),
        }),
        confirmDeleteAccount: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ConfirmDeleteAccount',
            fieldName: 'confirmDeleteAccount',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ConfirmDeleteAccount', 'confirmDeleteAccount', options?.select, args, [
                {
                    name: 'input',
                    type: 'ConfirmDeleteAccountInput!',
                },
            ]),
        }),
        extendTokenExpires: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ExtendTokenExpires',
            fieldName: 'extendTokenExpires',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ExtendTokenExpires', 'extendTokenExpires', options?.select, args, [
                {
                    name: 'input',
                    type: 'ExtendTokenExpiresInput!',
                },
            ]),
        }),
        forgotPassword: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ForgotPassword',
            fieldName: 'forgotPassword',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ForgotPassword', 'forgotPassword', options?.select, args, [
                {
                    name: 'input',
                    type: 'ForgotPasswordInput!',
                },
            ]),
        }),
        oneTimeToken: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'OneTimeToken',
            fieldName: 'oneTimeToken',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'OneTimeToken', 'oneTimeToken', options?.select, args, [
                {
                    name: 'input',
                    type: 'OneTimeTokenInput!',
                },
            ]),
        }),
        resetPassword: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'ResetPassword',
            fieldName: 'resetPassword',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'ResetPassword', 'resetPassword', options?.select, args, [
                {
                    name: 'input',
                    type: 'ResetPasswordInput!',
                },
            ]),
        }),
        sendAccountDeletionEmail: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SendAccountDeletionEmail',
            fieldName: 'sendAccountDeletionEmail',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SendAccountDeletionEmail', 'sendAccountDeletionEmail', options?.select, args, [
                {
                    name: 'input',
                    type: 'SendAccountDeletionEmailInput!',
                },
            ]),
        }),
        sendVerificationEmail: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SendVerificationEmail',
            fieldName: 'sendVerificationEmail',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SendVerificationEmail', 'sendVerificationEmail', options?.select, args, [
                {
                    name: 'input',
                    type: 'SendVerificationEmailInput!',
                },
            ]),
        }),
        setPassword: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SetPassword',
            fieldName: 'setPassword',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SetPassword', 'setPassword', options?.select, args, [
                {
                    name: 'input',
                    type: 'SetPasswordInput!',
                },
            ]),
        }),
        signIn: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SignIn',
            fieldName: 'signIn',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SignIn', 'signIn', options?.select, args, [
                {
                    name: 'input',
                    type: 'SignInInput!',
                },
            ]),
        }),
        signInOneTimeToken: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SignInOneTimeToken',
            fieldName: 'signInOneTimeToken',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SignInOneTimeToken', 'signInOneTimeToken', options?.select, args, [
                {
                    name: 'input',
                    type: 'SignInOneTimeTokenInput!',
                },
            ]),
        }),
        signOut: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SignOut',
            fieldName: 'signOut',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SignOut', 'signOut', options?.select, args, [
                {
                    name: 'input',
                    type: 'SignOutInput!',
                },
            ]),
        }),
        signUp: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'SignUp',
            fieldName: 'signUp',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'SignUp', 'signUp', options?.select, args, [
                {
                    name: 'input',
                    type: 'SignUpInput!',
                },
            ]),
        }),
        verifyEmail: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'VerifyEmail',
            fieldName: 'verifyEmail',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'VerifyEmail', 'verifyEmail', options?.select, args, [
                {
                    name: 'input',
                    type: 'VerifyEmailInput!',
                },
            ]),
        }),
        verifyPassword: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'VerifyPassword',
            fieldName: 'verifyPassword',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'VerifyPassword', 'verifyPassword', options?.select, args, [
                {
                    name: 'input',
                    type: 'VerifyPasswordInput!',
                },
            ]),
        }),
        verifyTotp: (args, options) => new query_builder_1.QueryBuilder({
            client,
            operation: 'mutation',
            operationName: 'VerifyTotp',
            fieldName: 'verifyTotp',
            ...(0, query_builder_1.buildCustomDocument)('mutation', 'VerifyTotp', 'verifyTotp', options?.select, args, [
                {
                    name: 'input',
                    type: 'VerifyTotpInput!',
                },
            ]),
        }),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvZ2VuZXJhdGVkL211dGF0aW9uL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBazhCQSw0REFnbEpDO0FBNWdMRCxvREFBcUU7QUE0N0JyRSxTQUFnQix3QkFBd0IsQ0FBQyxNQUFpQjtJQUN4RCxPQUFPO1FBQ0wscUNBQXFDLEVBQUUsQ0FHckMsSUFBb0QsRUFDcEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHVDQUF1QztZQUN0RCxTQUFTLEVBQUUsdUNBQXVDO1lBQ2xELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHVDQUF1QyxFQUN2Qyx1Q0FBdUMsRUFDdkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDZDQUE2QztpQkFDcEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDBCQUEwQixFQUFFLENBQzFCLElBQXlDLEVBQ3pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw0QkFBNEI7WUFDM0MsU0FBUyxFQUFFLDRCQUE0QjtZQUN2QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw0QkFBNEIsRUFDNUIsNEJBQTRCLEVBQzVCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxrQ0FBa0M7aUJBQ3pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQ0FBaUMsRUFBRSxDQUdqQyxJQUFnRCxFQUNoRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUNBQW1DO1lBQ2xELFNBQVMsRUFBRSxtQ0FBbUM7WUFDOUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUNBQW1DLEVBQ25DLG1DQUFtQyxFQUNuQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUNBQXlDO2lCQUNoRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osMENBQTBDLEVBQUUsQ0FHMUMsSUFBeUQsRUFDekQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDRDQUE0QztZQUMzRCxTQUFTLEVBQUUsNENBQTRDO1lBQ3ZELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDRDQUE0QyxFQUM1Qyw0Q0FBNEMsRUFDNUMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGtEQUFrRDtpQkFDekQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDJCQUEyQixFQUFFLENBQzNCLElBQTBDLEVBQzFDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw2QkFBNkI7WUFDNUMsU0FBUyxFQUFFLDZCQUE2QjtZQUN4QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw2QkFBNkIsRUFDN0IsNkJBQTZCLEVBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxtQ0FBbUM7aUJBQzFDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiwwQ0FBMEMsRUFBRSxDQUcxQyxJQUF5RCxFQUN6RCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsNENBQTRDO1lBQzNELFNBQVMsRUFBRSw0Q0FBNEM7WUFDdkQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsNENBQTRDLEVBQzVDLDRDQUE0QyxFQUM1QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsa0RBQWtEO2lCQUN6RDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osOEJBQThCLEVBQUUsQ0FDOUIsSUFBNkMsRUFDN0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGdDQUFnQztZQUMvQyxTQUFTLEVBQUUsZ0NBQWdDO1lBQzNDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGdDQUFnQyxFQUNoQyxnQ0FBZ0MsRUFDaEMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHNDQUFzQztpQkFDN0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHNDQUFzQyxFQUFFLENBR3RDLElBQXFELEVBQ3JELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx3Q0FBd0M7WUFDdkQsU0FBUyxFQUFFLHdDQUF3QztZQUNuRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix3Q0FBd0MsRUFDeEMsd0NBQXdDLEVBQ3hDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw4Q0FBOEM7aUJBQ3JEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw0QkFBNEIsRUFBRSxDQUc1QixJQUEyQyxFQUMzQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsOEJBQThCO1lBQzdDLFNBQVMsRUFBRSw4QkFBOEI7WUFDekMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsOEJBQThCLEVBQzlCLDhCQUE4QixFQUM5QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0NBQW9DO2lCQUMzQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FDNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDBDQUEwQyxFQUFFLENBRzFDLElBQXlELEVBQ3pELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw0Q0FBNEM7WUFDM0QsU0FBUyxFQUFFLDRDQUE0QztZQUN2RCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw0Q0FBNEMsRUFDNUMsNENBQTRDLEVBQzVDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxrREFBa0Q7aUJBQ3pEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixrQ0FBa0MsRUFBRSxDQUdsQyxJQUFpRCxFQUNqRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsb0NBQW9DO1lBQ25ELFNBQVMsRUFBRSxvQ0FBb0M7WUFDL0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysb0NBQW9DLEVBQ3BDLG9DQUFvQyxFQUNwQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsMENBQTBDO2lCQUNqRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osK0JBQStCLEVBQUUsQ0FHL0IsSUFBOEMsRUFDOUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGlDQUFpQztZQUNoRCxTQUFTLEVBQUUsaUNBQWlDO1lBQzVDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGlDQUFpQyxFQUNqQyxpQ0FBaUMsRUFDakMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHVDQUF1QztpQkFDOUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHdCQUF3QixFQUFFLENBQ3hCLElBQXVDLEVBQ3ZDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSwwQkFBMEI7WUFDekMsU0FBUyxFQUFFLDBCQUEwQjtZQUNyQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViwwQkFBMEIsRUFDMUIsMEJBQTBCLEVBQzFCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxnQ0FBZ0M7aUJBQ3ZDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw4QkFBOEIsRUFBRSxDQUM5QixJQUE2QyxFQUM3QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZ0NBQWdDO1lBQy9DLFNBQVMsRUFBRSxnQ0FBZ0M7WUFDM0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZ0NBQWdDLEVBQ2hDLGdDQUFnQyxFQUNoQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsc0NBQXNDO2lCQUM3QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNkJBQTZCLEVBQUUsQ0FDN0IsSUFBNEMsRUFDNUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLCtCQUErQjtZQUM5QyxTQUFTLEVBQUUsK0JBQStCO1lBQzFDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLCtCQUErQixFQUMvQiwrQkFBK0IsRUFDL0IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHFDQUFxQztpQkFDNUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHdDQUF3QyxFQUFFLENBR3hDLElBQXVELEVBQ3ZELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSwwQ0FBMEM7WUFDekQsU0FBUyxFQUFFLDBDQUEwQztZQUNyRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViwwQ0FBMEMsRUFDMUMsMENBQTBDLEVBQzFDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxnREFBZ0Q7aUJBQ3ZEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQ0FBc0MsRUFBRSxDQUd0QyxJQUFxRCxFQUNyRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0NBQXdDO1lBQ3ZELFNBQVMsRUFBRSx3Q0FBd0M7WUFDbkQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0NBQXdDLEVBQ3hDLHdDQUF3QyxFQUN4QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOENBQThDO2lCQUNyRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0oscUNBQXFDLEVBQUUsQ0FHckMsSUFBb0QsRUFDcEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHVDQUF1QztZQUN0RCxTQUFTLEVBQUUsdUNBQXVDO1lBQ2xELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHVDQUF1QyxFQUN2Qyx1Q0FBdUMsRUFDdkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDZDQUE2QztpQkFDcEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHNDQUFzQyxFQUFFLENBR3RDLElBQXFELEVBQ3JELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx3Q0FBd0M7WUFDdkQsU0FBUyxFQUFFLHdDQUF3QztZQUNuRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix3Q0FBd0MsRUFDeEMsd0NBQXdDLEVBQ3hDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw4Q0FBOEM7aUJBQ3JEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQ0FBaUMsRUFBRSxDQUdqQyxJQUFnRCxFQUNoRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUNBQW1DO1lBQ2xELFNBQVMsRUFBRSxtQ0FBbUM7WUFDOUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUNBQW1DLEVBQ25DLG1DQUFtQyxFQUNuQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUNBQXlDO2lCQUNoRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FDNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGlCQUFpQixFQUFFLENBQ2pCLElBQWdDLEVBQ2hDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxtQkFBbUI7WUFDbEMsU0FBUyxFQUFFLG1CQUFtQjtZQUM5QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixtQkFBbUIsRUFDbkIsbUJBQW1CLEVBQ25CLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx5QkFBeUI7aUJBQ2hDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixnQ0FBZ0MsRUFBRSxDQUdoQyxJQUErQyxFQUMvQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0NBQWtDO1lBQ2pELFNBQVMsRUFBRSxrQ0FBa0M7WUFDN0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysa0NBQWtDLEVBQ2xDLGtDQUFrQyxFQUNsQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsd0NBQXdDO2lCQUMvQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osaUNBQWlDLEVBQUUsQ0FHakMsSUFBZ0QsRUFDaEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLG1DQUFtQztZQUNsRCxTQUFTLEVBQUUsbUNBQW1DO1lBQzlDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLG1DQUFtQyxFQUNuQyxtQ0FBbUMsRUFDbkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHlDQUF5QztpQkFDaEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGlEQUFpRCxFQUFFLENBR2pELElBQWdFLEVBQ2hFLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxtREFBbUQ7WUFDbEUsU0FBUyxFQUFFLG1EQUFtRDtZQUM5RCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixtREFBbUQsRUFDbkQsbURBQW1ELEVBQ25ELE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx5REFBeUQ7aUJBQ2hFO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQkFBc0IsRUFBRSxDQUN0QixJQUFxQyxFQUNyQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0JBQXdCO1lBQ3ZDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0JBQXdCLEVBQ3hCLHdCQUF3QixFQUN4QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOEJBQThCO2lCQUNyQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG9CQUFvQixFQUFFLENBQ3BCLElBQW1DLEVBQ25DLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxzQkFBc0I7WUFDckMsU0FBUyxFQUFFLHNCQUFzQjtZQUNqQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixzQkFBc0IsRUFDdEIsc0JBQXNCLEVBQ3RCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw0QkFBNEI7aUJBQ25DO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw0Q0FBNEMsRUFBRSxDQUc1QyxJQUEyRCxFQUMzRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsOENBQThDO1lBQzdELFNBQVMsRUFBRSw4Q0FBOEM7WUFDekQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsOENBQThDLEVBQzlDLDhDQUE4QyxFQUM5QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0RBQW9EO2lCQUMzRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FHNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSix5QkFBeUIsRUFBRSxDQUN6QixJQUF3QyxFQUN4QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsMkJBQTJCO1lBQzFDLFNBQVMsRUFBRSwyQkFBMkI7WUFDdEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsMkJBQTJCLEVBQzNCLDJCQUEyQixFQUMzQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsaUNBQWlDO2lCQUN4QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0oscUNBQXFDLEVBQUUsQ0FHckMsSUFBb0QsRUFDcEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHVDQUF1QztZQUN0RCxTQUFTLEVBQUUsdUNBQXVDO1lBQ2xELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHVDQUF1QyxFQUN2Qyx1Q0FBdUMsRUFDdkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDZDQUE2QztpQkFDcEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDBCQUEwQixFQUFFLENBQzFCLElBQXlDLEVBQ3pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw0QkFBNEI7WUFDM0MsU0FBUyxFQUFFLDRCQUE0QjtZQUN2QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw0QkFBNEIsRUFDNUIsNEJBQTRCLEVBQzVCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxrQ0FBa0M7aUJBQ3pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQ0FBaUMsRUFBRSxDQUdqQyxJQUFnRCxFQUNoRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUNBQW1DO1lBQ2xELFNBQVMsRUFBRSxtQ0FBbUM7WUFDOUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUNBQW1DLEVBQ25DLG1DQUFtQyxFQUNuQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUNBQXlDO2lCQUNoRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osMENBQTBDLEVBQUUsQ0FHMUMsSUFBeUQsRUFDekQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDRDQUE0QztZQUMzRCxTQUFTLEVBQUUsNENBQTRDO1lBQ3ZELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDRDQUE0QyxFQUM1Qyw0Q0FBNEMsRUFDNUMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGtEQUFrRDtpQkFDekQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDJCQUEyQixFQUFFLENBQzNCLElBQTBDLEVBQzFDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw2QkFBNkI7WUFDNUMsU0FBUyxFQUFFLDZCQUE2QjtZQUN4QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw2QkFBNkIsRUFDN0IsNkJBQTZCLEVBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxtQ0FBbUM7aUJBQzFDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiwwQ0FBMEMsRUFBRSxDQUcxQyxJQUF5RCxFQUN6RCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsNENBQTRDO1lBQzNELFNBQVMsRUFBRSw0Q0FBNEM7WUFDdkQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsNENBQTRDLEVBQzVDLDRDQUE0QyxFQUM1QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsa0RBQWtEO2lCQUN6RDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osOEJBQThCLEVBQUUsQ0FDOUIsSUFBNkMsRUFDN0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGdDQUFnQztZQUMvQyxTQUFTLEVBQUUsZ0NBQWdDO1lBQzNDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGdDQUFnQyxFQUNoQyxnQ0FBZ0MsRUFDaEMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHNDQUFzQztpQkFDN0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHNDQUFzQyxFQUFFLENBR3RDLElBQXFELEVBQ3JELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx3Q0FBd0M7WUFDdkQsU0FBUyxFQUFFLHdDQUF3QztZQUNuRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix3Q0FBd0MsRUFDeEMsd0NBQXdDLEVBQ3hDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw4Q0FBOEM7aUJBQ3JEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw0QkFBNEIsRUFBRSxDQUc1QixJQUEyQyxFQUMzQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsOEJBQThCO1lBQzdDLFNBQVMsRUFBRSw4QkFBOEI7WUFDekMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsOEJBQThCLEVBQzlCLDhCQUE4QixFQUM5QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0NBQW9DO2lCQUMzQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FDNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDBDQUEwQyxFQUFFLENBRzFDLElBQXlELEVBQ3pELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw0Q0FBNEM7WUFDM0QsU0FBUyxFQUFFLDRDQUE0QztZQUN2RCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw0Q0FBNEMsRUFDNUMsNENBQTRDLEVBQzVDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxrREFBa0Q7aUJBQ3pEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixrQ0FBa0MsRUFBRSxDQUdsQyxJQUFpRCxFQUNqRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsb0NBQW9DO1lBQ25ELFNBQVMsRUFBRSxvQ0FBb0M7WUFDL0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysb0NBQW9DLEVBQ3BDLG9DQUFvQyxFQUNwQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsMENBQTBDO2lCQUNqRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osK0JBQStCLEVBQUUsQ0FHL0IsSUFBOEMsRUFDOUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGlDQUFpQztZQUNoRCxTQUFTLEVBQUUsaUNBQWlDO1lBQzVDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGlDQUFpQyxFQUNqQyxpQ0FBaUMsRUFDakMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHVDQUF1QztpQkFDOUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHdCQUF3QixFQUFFLENBQ3hCLElBQXVDLEVBQ3ZDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSwwQkFBMEI7WUFDekMsU0FBUyxFQUFFLDBCQUEwQjtZQUNyQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViwwQkFBMEIsRUFDMUIsMEJBQTBCLEVBQzFCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxnQ0FBZ0M7aUJBQ3ZDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw4QkFBOEIsRUFBRSxDQUM5QixJQUE2QyxFQUM3QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZ0NBQWdDO1lBQy9DLFNBQVMsRUFBRSxnQ0FBZ0M7WUFDM0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZ0NBQWdDLEVBQ2hDLGdDQUFnQyxFQUNoQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsc0NBQXNDO2lCQUM3QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNkJBQTZCLEVBQUUsQ0FDN0IsSUFBNEMsRUFDNUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLCtCQUErQjtZQUM5QyxTQUFTLEVBQUUsK0JBQStCO1lBQzFDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLCtCQUErQixFQUMvQiwrQkFBK0IsRUFDL0IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHFDQUFxQztpQkFDNUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHdDQUF3QyxFQUFFLENBR3hDLElBQXVELEVBQ3ZELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSwwQ0FBMEM7WUFDekQsU0FBUyxFQUFFLDBDQUEwQztZQUNyRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViwwQ0FBMEMsRUFDMUMsMENBQTBDLEVBQzFDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxnREFBZ0Q7aUJBQ3ZEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQ0FBc0MsRUFBRSxDQUd0QyxJQUFxRCxFQUNyRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0NBQXdDO1lBQ3ZELFNBQVMsRUFBRSx3Q0FBd0M7WUFDbkQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0NBQXdDLEVBQ3hDLHdDQUF3QyxFQUN4QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOENBQThDO2lCQUNyRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0oscUNBQXFDLEVBQUUsQ0FHckMsSUFBb0QsRUFDcEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHVDQUF1QztZQUN0RCxTQUFTLEVBQUUsdUNBQXVDO1lBQ2xELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHVDQUF1QyxFQUN2Qyx1Q0FBdUMsRUFDdkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDZDQUE2QztpQkFDcEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHNDQUFzQyxFQUFFLENBR3RDLElBQXFELEVBQ3JELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx3Q0FBd0M7WUFDdkQsU0FBUyxFQUFFLHdDQUF3QztZQUNuRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix3Q0FBd0MsRUFDeEMsd0NBQXdDLEVBQ3hDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw4Q0FBOEM7aUJBQ3JEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQ0FBaUMsRUFBRSxDQUdqQyxJQUFnRCxFQUNoRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUNBQW1DO1lBQ2xELFNBQVMsRUFBRSxtQ0FBbUM7WUFDOUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUNBQW1DLEVBQ25DLG1DQUFtQyxFQUNuQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUNBQXlDO2lCQUNoRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FDNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGlCQUFpQixFQUFFLENBQ2pCLElBQWdDLEVBQ2hDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxtQkFBbUI7WUFDbEMsU0FBUyxFQUFFLG1CQUFtQjtZQUM5QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixtQkFBbUIsRUFDbkIsbUJBQW1CLEVBQ25CLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx5QkFBeUI7aUJBQ2hDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixnQ0FBZ0MsRUFBRSxDQUdoQyxJQUErQyxFQUMvQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0NBQWtDO1lBQ2pELFNBQVMsRUFBRSxrQ0FBa0M7WUFDN0MsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysa0NBQWtDLEVBQ2xDLGtDQUFrQyxFQUNsQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsd0NBQXdDO2lCQUMvQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osaUNBQWlDLEVBQUUsQ0FHakMsSUFBZ0QsRUFDaEQsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLG1DQUFtQztZQUNsRCxTQUFTLEVBQUUsbUNBQW1DO1lBQzlDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLG1DQUFtQyxFQUNuQyxtQ0FBbUMsRUFDbkMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHlDQUF5QztpQkFDaEQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGlEQUFpRCxFQUFFLENBR2pELElBQWdFLEVBQ2hFLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxtREFBbUQ7WUFDbEUsU0FBUyxFQUFFLG1EQUFtRDtZQUM5RCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixtREFBbUQsRUFDbkQsbURBQW1ELEVBQ25ELE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx5REFBeUQ7aUJBQ2hFO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQkFBc0IsRUFBRSxDQUN0QixJQUFxQyxFQUNyQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0JBQXdCO1lBQ3ZDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0JBQXdCLEVBQ3hCLHdCQUF3QixFQUN4QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOEJBQThCO2lCQUNyQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG9CQUFvQixFQUFFLENBQ3BCLElBQW1DLEVBQ25DLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxzQkFBc0I7WUFDckMsU0FBUyxFQUFFLHNCQUFzQjtZQUNqQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixzQkFBc0IsRUFDdEIsc0JBQXNCLEVBQ3RCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw0QkFBNEI7aUJBQ25DO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw0Q0FBNEMsRUFBRSxDQUc1QyxJQUEyRCxFQUMzRCxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsOENBQThDO1lBQzdELFNBQVMsRUFBRSw4Q0FBOEM7WUFDekQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsOENBQThDLEVBQzlDLDhDQUE4QyxFQUM5QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0RBQW9EO2lCQUMzRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FHNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSix5QkFBeUIsRUFBRSxDQUN6QixJQUF3QyxFQUN4QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsMkJBQTJCO1lBQzFDLFNBQVMsRUFBRSwyQkFBMkI7WUFDdEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsMkJBQTJCLEVBQzNCLDJCQUEyQixFQUMzQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsaUNBQWlDO2lCQUN4QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osUUFBUSxFQUFFLENBQ1IsSUFBdUIsRUFDdkIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLFVBQVU7WUFDekIsU0FBUyxFQUFFLFVBQVU7WUFDckIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsVUFBVSxFQUNWLFVBQVUsRUFDVixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsZ0JBQWdCO2lCQUN2QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osYUFBYSxFQUFFLENBQ2IsSUFBNEIsRUFDNUIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGVBQWU7WUFDOUIsU0FBUyxFQUFFLGVBQWU7WUFDMUIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZUFBZSxFQUNmLGVBQWUsRUFDZixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUscUJBQXFCO2lCQUM1QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osa0JBQWtCLEVBQUUsQ0FDbEIsSUFBaUMsRUFDakMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLG9CQUFvQjtZQUNuQyxTQUFTLEVBQUUsb0JBQW9CO1lBQy9CLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLG9CQUFvQixFQUNwQixvQkFBb0IsRUFDcEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDBCQUEwQjtpQkFDakM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHlCQUF5QixFQUFFLENBR3pCLElBQXdDLEVBQ3hDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSwyQkFBMkI7WUFDMUMsU0FBUyxFQUFFLDJCQUEyQjtZQUN0QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViwyQkFBMkIsRUFDM0IsMkJBQTJCLEVBQzNCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxpQ0FBaUM7aUJBQ3hDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixhQUFhLEVBQUUsQ0FDYixJQUE0QixFQUM1QixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZUFBZTtZQUM5QixTQUFTLEVBQUUsZUFBZTtZQUMxQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixlQUFlLEVBQ2YsZUFBZSxFQUNmLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxxQkFBcUI7aUJBQzVCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixhQUFhLEVBQUUsQ0FDYixJQUE0QixFQUM1QixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZUFBZTtZQUM5QixTQUFTLEVBQUUsZUFBZTtZQUMxQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixlQUFlLEVBQ2YsZUFBZSxFQUNmLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxxQkFBcUI7aUJBQzVCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixnQkFBZ0IsRUFBRSxDQUNoQixJQUErQixFQUMvQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0JBQWtCO1lBQ2pDLFNBQVMsRUFBRSxrQkFBa0I7WUFDN0IsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysa0JBQWtCLEVBQ2xCLGtCQUFrQixFQUNsQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsd0JBQXdCO2lCQUMvQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osZ0JBQWdCLEVBQUUsQ0FDaEIsSUFBK0IsRUFDL0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGtCQUFrQjtZQUNqQyxTQUFTLEVBQUUsa0JBQWtCO1lBQzdCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGtCQUFrQixFQUNsQixrQkFBa0IsRUFDbEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHdCQUF3QjtpQkFDL0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGFBQWEsRUFBRSxDQUNiLElBQTRCLEVBQzVCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxlQUFlO1lBQzlCLFNBQVMsRUFBRSxlQUFlO1lBQzFCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGVBQWUsRUFDZixlQUFlLEVBQ2YsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHFCQUFxQjtpQkFDNUI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGdCQUFnQixFQUFFLENBQ2hCLElBQStCLEVBQy9CLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxrQkFBa0I7WUFDakMsU0FBUyxFQUFFLGtCQUFrQjtZQUM3QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixrQkFBa0IsRUFDbEIsa0JBQWtCLEVBQ2xCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx3QkFBd0I7aUJBQy9CO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixhQUFhLEVBQUUsQ0FDYixJQUE0QixFQUM1QixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZUFBZTtZQUM5QixTQUFTLEVBQUUsZUFBZTtZQUMxQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixlQUFlLEVBQ2YsZUFBZSxFQUNmLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxxQkFBcUI7aUJBQzVCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixZQUFZLEVBQUUsQ0FDWixJQUEyQixFQUMzQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsY0FBYztZQUM3QixTQUFTLEVBQUUsY0FBYztZQUN6QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixjQUFjLEVBQ2QsY0FBYyxFQUNkLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxvQkFBb0I7aUJBQzNCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQkFBaUIsRUFBRSxDQUNqQixJQUFnQyxFQUNoQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUJBQW1CO1lBQ2xDLFNBQVMsRUFBRSxtQkFBbUI7WUFDOUIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUJBQW1CLEVBQ25CLG1CQUFtQixFQUNuQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUJBQXlCO2lCQUNoQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osdUJBQXVCLEVBQUUsQ0FHdkIsSUFBc0MsRUFDdEMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHlCQUF5QjtZQUN4QyxTQUFTLEVBQUUseUJBQXlCO1lBQ3BDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHlCQUF5QixFQUN6Qix5QkFBeUIsRUFDekIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLCtCQUErQjtpQkFDdEM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFNBQVMsRUFBRSxDQUNULElBQXdCLEVBQ3hCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxXQUFXO1lBQzFCLFNBQVMsRUFBRSxXQUFXO1lBQ3RCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFdBQVcsRUFDWCxXQUFXLEVBQ1gsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGlCQUFpQjtpQkFDeEI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGVBQWUsRUFBRSxDQUNmLElBQThCLEVBQzlCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxpQkFBaUI7WUFDaEMsU0FBUyxFQUFFLGlCQUFpQjtZQUM1QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixpQkFBaUIsRUFDakIsaUJBQWlCLEVBQ2pCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx1QkFBdUI7aUJBQzlCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixtQkFBbUIsRUFBRSxDQUNuQixJQUFrQyxFQUNsQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUscUJBQXFCO1lBQ3BDLFNBQVMsRUFBRSxxQkFBcUI7WUFDaEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YscUJBQXFCLEVBQ3JCLHFCQUFxQixFQUNyQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsMkJBQTJCO2lCQUNsQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osY0FBYyxFQUFFLENBQ2QsSUFBNkIsRUFDN0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGdCQUFnQjtZQUMvQixTQUFTLEVBQUUsZ0JBQWdCO1lBQzNCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHNCQUFzQjtpQkFDN0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQ0FBc0MsRUFBRSxDQUd0QyxJQUFxRCxFQUNyRCxPQUtDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0NBQXdDO1lBQ3ZELFNBQVMsRUFBRSx3Q0FBd0M7WUFDbkQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0NBQXdDLEVBQ3hDLHdDQUF3QyxFQUN4QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOENBQThDO2lCQUNyRDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osc0NBQXNDLEVBQUUsQ0FHdEMsSUFBcUQsRUFDckQsT0FLQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHdDQUF3QztZQUN2RCxTQUFTLEVBQUUsd0NBQXdDO1lBQ25ELEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHdDQUF3QyxFQUN4Qyx3Q0FBd0MsRUFDeEMsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDhDQUE4QztpQkFDckQ7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG1DQUFtQyxFQUFFLENBR25DLElBQWtELEVBQ2xELE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxxQ0FBcUM7WUFDcEQsU0FBUyxFQUFFLHFDQUFxQztZQUNoRCxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixxQ0FBcUMsRUFDckMscUNBQXFDLEVBQ3JDLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwyQ0FBMkM7aUJBQ2xEO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSix1Q0FBdUMsRUFBRSxDQUd2QyxJQUFzRCxFQUN0RCxPQUtDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUseUNBQXlDO1lBQ3hELFNBQVMsRUFBRSx5Q0FBeUM7WUFDcEQsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YseUNBQXlDLEVBQ3pDLHlDQUF5QyxFQUN6QyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsK0NBQStDO2lCQUN0RDthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osV0FBVyxFQUFFLENBQ1gsSUFBMEIsRUFDMUIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGFBQWE7WUFDNUIsU0FBUyxFQUFFLGFBQWE7WUFDeEIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsYUFBYSxFQUNiLGFBQWEsRUFDYixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsbUJBQW1CO2lCQUMxQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osNEJBQTRCLEVBQUUsQ0FHNUIsSUFBMkMsRUFDM0MsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDhCQUE4QjtZQUM3QyxTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDhCQUE4QixFQUM5Qiw4QkFBOEIsRUFDOUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9DQUFvQztpQkFDM0M7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG1CQUFtQixFQUFFLENBQ25CLElBQWtDLEVBQ2xDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxxQkFBcUI7WUFDcEMsU0FBUyxFQUFFLHFCQUFxQjtZQUNoQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixxQkFBcUIsRUFDckIscUJBQXFCLEVBQ3JCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwyQkFBMkI7aUJBQ2xDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSix1QkFBdUIsRUFBRSxDQUd2QixJQUFzQyxFQUN0QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUseUJBQXlCO1lBQ3hDLFNBQVMsRUFBRSx5QkFBeUI7WUFDcEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YseUJBQXlCLEVBQ3pCLHlCQUF5QixFQUN6QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsK0JBQStCO2lCQUN0QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0oscUJBQXFCLEVBQUUsQ0FDckIsSUFBb0MsRUFDcEMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHVCQUF1QjtZQUN0QyxTQUFTLEVBQUUsdUJBQXVCO1lBQ2xDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHVCQUF1QixFQUN2Qix1QkFBdUIsRUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDZCQUE2QjtpQkFDcEM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHVCQUF1QixFQUFFLENBR3ZCLElBQXNDLEVBQ3RDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx5QkFBeUI7WUFDeEMsU0FBUyxFQUFFLHlCQUF5QjtZQUNwQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix5QkFBeUIsRUFDekIseUJBQXlCLEVBQ3pCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwrQkFBK0I7aUJBQ3RDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiw2QkFBNkIsRUFBRSxDQUc3QixJQUE0QyxFQUM1QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsK0JBQStCO1lBQzlDLFNBQVMsRUFBRSwrQkFBK0I7WUFDMUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsK0JBQStCLEVBQy9CLCtCQUErQixFQUMvQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUscUNBQXFDO2lCQUM1QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDJCQUEyQixFQUFFLENBRzNCLElBQTBDLEVBQzFDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw2QkFBNkI7WUFDNUMsU0FBUyxFQUFFLDZCQUE2QjtZQUN4QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw2QkFBNkIsRUFDN0IsNkJBQTZCLEVBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxtQ0FBbUM7aUJBQzFDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiwyQkFBMkIsRUFBRSxDQUczQixJQUEwQyxFQUMxQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsNkJBQTZCO1lBQzVDLFNBQVMsRUFBRSw2QkFBNkI7WUFDeEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsNkJBQTZCLEVBQzdCLDZCQUE2QixFQUM3QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsbUNBQW1DO2lCQUMxQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osd0JBQXdCLEVBQUUsQ0FHeEIsSUFBdUMsRUFDdkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDBCQUEwQjtZQUN6QyxTQUFTLEVBQUUsMEJBQTBCO1lBQ3JDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDBCQUEwQixFQUMxQiwwQkFBMEIsRUFDMUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGdDQUFnQztpQkFDdkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHNCQUFzQixFQUFFLENBR3RCLElBQXFDLEVBQ3JDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx3QkFBd0I7WUFDdkMsU0FBUyxFQUFFLHdCQUF3QjtZQUNuQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix3QkFBd0IsRUFDeEIsd0JBQXdCLEVBQ3hCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw4QkFBOEI7aUJBQ3JDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiwrQkFBK0IsRUFBRSxDQUcvQixJQUE4QyxFQUM5QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsaUNBQWlDO1lBQ2hELFNBQVMsRUFBRSxpQ0FBaUM7WUFDNUMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsaUNBQWlDLEVBQ2pDLGlDQUFpQyxFQUNqQyxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsdUNBQXVDO2lCQUM5QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDJCQUEyQixFQUFFLENBRzNCLElBQTBDLEVBQzFDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw2QkFBNkI7WUFDNUMsU0FBUyxFQUFFLDZCQUE2QjtZQUN4QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw2QkFBNkIsRUFDN0IsNkJBQTZCLEVBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxtQ0FBbUM7aUJBQzFDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQkFBc0IsRUFBRSxDQUd0QixJQUFxQyxFQUNyQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0JBQXdCO1lBQ3ZDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0JBQXdCLEVBQ3hCLHdCQUF3QixFQUN4QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOEJBQThCO2lCQUNyQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osMkJBQTJCLEVBQUUsQ0FHM0IsSUFBMEMsRUFDMUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDZCQUE2QjtZQUM1QyxTQUFTLEVBQUUsNkJBQTZCO1lBQ3hDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDZCQUE2QixFQUM3Qiw2QkFBNkIsRUFDN0IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG1DQUFtQztpQkFDMUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLDBCQUEwQixFQUFFLENBRzFCLElBQXlDLEVBQ3pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSw0QkFBNEI7WUFDM0MsU0FBUyxFQUFFLDRCQUE0QjtZQUN2QyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDViw0QkFBNEIsRUFDNUIsNEJBQTRCLEVBQzVCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxrQ0FBa0M7aUJBQ3pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSiwwQkFBMEIsRUFBRSxDQUcxQixJQUF5QyxFQUN6QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsNEJBQTRCO1lBQzNDLFNBQVMsRUFBRSw0QkFBNEI7WUFDdkMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsNEJBQTRCLEVBQzVCLDRCQUE0QixFQUM1QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsa0NBQWtDO2lCQUN6QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osbUJBQW1CLEVBQUUsQ0FDbkIsSUFBa0MsRUFDbEMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHFCQUFxQjtZQUNwQyxTQUFTLEVBQUUscUJBQXFCO1lBQ2hDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHFCQUFxQixFQUNyQixxQkFBcUIsRUFDckIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDJCQUEyQjtpQkFDbEM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFlBQVksRUFBRSxDQUNaLElBQTJCLEVBQzNCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxjQUFjO1lBQzdCLFNBQVMsRUFBRSxjQUFjO1lBQ3pCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGNBQWMsRUFDZCxjQUFjLEVBQ2QsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9CQUFvQjtpQkFDM0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGFBQWEsRUFBRSxDQUNiLElBQTRCLEVBQzVCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxlQUFlO1lBQzlCLFNBQVMsRUFBRSxlQUFlO1lBQzFCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGVBQWUsRUFDZixlQUFlLEVBQ2YsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHFCQUFxQjtpQkFDNUI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGNBQWMsRUFBRSxDQUNkLElBQTZCLEVBQzdCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxnQkFBZ0I7WUFDL0IsU0FBUyxFQUFFLGdCQUFnQjtZQUMzQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixnQkFBZ0IsRUFDaEIsZ0JBQWdCLEVBQ2hCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxzQkFBc0I7aUJBQzdCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixpQkFBaUIsRUFBRSxDQUNqQixJQUFnQyxFQUNoQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsbUJBQW1CO1lBQ2xDLFNBQVMsRUFBRSxtQkFBbUI7WUFDOUIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsbUJBQW1CLEVBQ25CLG1CQUFtQixFQUNuQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUseUJBQXlCO2lCQUNoQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osWUFBWSxFQUFFLENBQ1osSUFBMkIsRUFDM0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGNBQWM7WUFDN0IsU0FBUyxFQUFFLGNBQWM7WUFDekIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsY0FBYyxFQUNkLGNBQWMsRUFDZCxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0JBQW9CO2lCQUMzQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osMkJBQTJCLEVBQUUsQ0FHM0IsSUFBMEMsRUFDMUMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDZCQUE2QjtZQUM1QyxTQUFTLEVBQUUsNkJBQTZCO1lBQ3hDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDZCQUE2QixFQUM3Qiw2QkFBNkIsRUFDN0IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG1DQUFtQztpQkFDMUM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSix1QkFBdUIsRUFBRSxDQUd2QixJQUFzQyxFQUN0QyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUseUJBQXlCO1lBQ3hDLFNBQVMsRUFBRSx5QkFBeUI7WUFDcEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YseUJBQXlCLEVBQ3pCLHlCQUF5QixFQUN6QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsK0JBQStCO2lCQUN0QzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osY0FBYyxFQUFFLENBQ2QsSUFBNkIsRUFDN0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGdCQUFnQjtZQUMvQixTQUFTLEVBQUUsZ0JBQWdCO1lBQzNCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHNCQUFzQjtpQkFDN0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFlBQVksRUFBRSxDQUNaLElBQTJCLEVBQzNCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxjQUFjO1lBQzdCLFNBQVMsRUFBRSxjQUFjO1lBQ3pCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGNBQWMsRUFDZCxjQUFjLEVBQ2QsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9CQUFvQjtpQkFDM0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFNBQVMsRUFBRSxDQUNULElBQXdCLEVBQ3hCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxXQUFXO1lBQzFCLFNBQVMsRUFBRSxXQUFXO1lBQ3RCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFdBQVcsRUFDWCxXQUFXLEVBQ1gsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGlCQUFpQjtpQkFDeEI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFVBQVUsRUFBRSxDQUNWLElBQXlCLEVBQ3pCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxZQUFZO1lBQzNCLFNBQVMsRUFBRSxZQUFZO1lBQ3ZCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFlBQVksRUFDWixZQUFZLEVBQ1osT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGtCQUFrQjtpQkFDekI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFVBQVUsRUFBRSxDQUNWLElBQXlCLEVBQ3pCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxZQUFZO1lBQzNCLFNBQVMsRUFBRSxZQUFZO1lBQ3ZCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFlBQVksRUFDWixZQUFZLEVBQ1osT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGtCQUFrQjtpQkFDekI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFNBQVMsRUFBRSxDQUNULElBQXdCLEVBQ3hCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxXQUFXO1lBQzFCLFNBQVMsRUFBRSxXQUFXO1lBQ3RCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFdBQVcsRUFDWCxXQUFXLEVBQ1gsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGlCQUFpQjtpQkFDeEI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFdBQVcsRUFBRSxDQUNYLElBQTBCLEVBQzFCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFNBQVMsRUFBRSxhQUFhO1lBQ3hCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGFBQWEsRUFDYixhQUFhLEVBQ2IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG1CQUFtQjtpQkFDMUI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG1CQUFtQixFQUFFLENBQ25CLElBQWtDLEVBQ2xDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxxQkFBcUI7WUFDcEMsU0FBUyxFQUFFLHFCQUFxQjtZQUNoQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixxQkFBcUIsRUFDckIscUJBQXFCLEVBQ3JCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwyQkFBMkI7aUJBQ2xDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixzQkFBc0IsRUFBRSxDQUd0QixJQUFxQyxFQUNyQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsd0JBQXdCO1lBQ3ZDLFNBQVMsRUFBRSx3QkFBd0I7WUFDbkMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysd0JBQXdCLEVBQ3hCLHdCQUF3QixFQUN4QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsOEJBQThCO2lCQUNyQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0oseUJBQXlCLEVBQUUsQ0FHekIsSUFBd0MsRUFDeEMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDJCQUEyQjtZQUMxQyxTQUFTLEVBQUUsMkJBQTJCO1lBQ3RDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDJCQUEyQixFQUMzQiwyQkFBMkIsRUFDM0IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGlDQUFpQztpQkFDeEM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixxQkFBcUIsRUFBRSxDQUNyQixJQUFvQyxFQUNwQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FLYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsdUJBQXVCO1lBQ3RDLFNBQVMsRUFBRSx1QkFBdUI7WUFDbEMsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsdUJBQXVCLEVBQ3ZCLHVCQUF1QixFQUN2QixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsNkJBQTZCO2lCQUNwQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osc0JBQXNCLEVBQUUsQ0FHdEIsSUFBcUMsRUFDckMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHdCQUF3QjtZQUN2QyxTQUFTLEVBQUUsd0JBQXdCO1lBQ25DLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHdCQUF3QixFQUN4Qix3QkFBd0IsRUFDeEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDhCQUE4QjtpQkFDckM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFlBQVksRUFBRSxDQUNaLElBQTJCLEVBQzNCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxjQUFjO1lBQzdCLFNBQVMsRUFBRSxjQUFjO1lBQ3pCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGNBQWMsRUFDZCxjQUFjLEVBQ2QsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9CQUFvQjtpQkFDM0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHFCQUFxQixFQUFFLENBQ3JCLElBQW9DLEVBQ3BDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx1QkFBdUI7WUFDdEMsU0FBUyxFQUFFLHVCQUF1QjtZQUNsQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix1QkFBdUIsRUFDdkIsdUJBQXVCLEVBQ3ZCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw2QkFBNkI7aUJBQ3BDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixrQkFBa0IsRUFBRSxDQUNsQixJQUFpQyxFQUNqQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsb0JBQW9CO1lBQ25DLFNBQVMsRUFBRSxvQkFBb0I7WUFDL0IsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysb0JBQW9CLEVBQ3BCLG9CQUFvQixFQUNwQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsMEJBQTBCO2lCQUNqQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osWUFBWSxFQUFFLENBQ1osSUFBMkIsRUFDM0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGNBQWM7WUFDN0IsU0FBUyxFQUFFLGNBQWM7WUFDekIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsY0FBYyxFQUNkLGNBQWMsRUFDZCxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0JBQW9CO2lCQUMzQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osZ0JBQWdCLEVBQUUsQ0FDaEIsSUFBK0IsRUFDL0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGtCQUFrQjtZQUNqQyxTQUFTLEVBQUUsa0JBQWtCO1lBQzdCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGtCQUFrQixFQUNsQixrQkFBa0IsRUFDbEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHdCQUF3QjtpQkFDL0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFdBQVcsRUFBRSxDQUNYLElBQTBCLEVBQzFCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFNBQVMsRUFBRSxhQUFhO1lBQ3hCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGFBQWEsRUFDYixhQUFhLEVBQ2IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG1CQUFtQjtpQkFDMUI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFlBQVksRUFBRSxDQUNaLElBQTJCLEVBQzNCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxjQUFjO1lBQzdCLFNBQVMsRUFBRSxjQUFjO1lBQ3pCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGNBQWMsRUFDZCxjQUFjLEVBQ2QsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG9CQUFvQjtpQkFDM0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFdBQVcsRUFBRSxDQUNYLElBQTBCLEVBQzFCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxhQUFhO1lBQzVCLFNBQVMsRUFBRSxhQUFhO1lBQ3hCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGFBQWEsRUFDYixhQUFhLEVBQ2IsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLG1CQUFtQjtpQkFDMUI7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLG1CQUFtQixFQUFFLENBQ25CLElBQWtDLEVBQ2xDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxxQkFBcUI7WUFDcEMsU0FBUyxFQUFFLHFCQUFxQjtZQUNoQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixxQkFBcUIsRUFDckIscUJBQXFCLEVBQ3JCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwyQkFBMkI7aUJBQ2xDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixrQkFBa0IsRUFBRSxDQUNsQixJQUFpQyxFQUNqQyxPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsb0JBQW9CO1lBQ25DLFNBQVMsRUFBRSxvQkFBb0I7WUFDL0IsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysb0JBQW9CLEVBQ3BCLG9CQUFvQixFQUNwQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsMEJBQTBCO2lCQUNqQzthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGlCQUFpQixFQUFFLENBQ2pCLElBQWdDLEVBQ2hDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxtQkFBbUI7WUFDbEMsU0FBUyxFQUFFLG1CQUFtQjtZQUM5QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixtQkFBbUIsRUFDbkIsbUJBQW1CLEVBQ25CLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSx5QkFBeUI7aUJBQ2hDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixnQkFBZ0IsRUFBRSxDQUNoQixJQUErQixFQUMvQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsa0JBQWtCO1lBQ2pDLFNBQVMsRUFBRSxrQkFBa0I7WUFDN0IsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1Ysa0JBQWtCLEVBQ2xCLGtCQUFrQixFQUNsQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsd0JBQXdCO2lCQUMvQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osVUFBVSxFQUFFLENBQ1YsSUFBeUIsRUFDekIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLFlBQVk7WUFDM0IsU0FBUyxFQUFFLFlBQVk7WUFDdkIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsWUFBWSxFQUNaLFlBQVksRUFDWixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsa0JBQWtCO2lCQUN6QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osYUFBYSxFQUFFLENBQ2IsSUFBNEIsRUFDNUIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGVBQWU7WUFDOUIsU0FBUyxFQUFFLGVBQWU7WUFDMUIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZUFBZSxFQUNmLGVBQWUsRUFDZixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUscUJBQXFCO2lCQUM1QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osb0JBQW9CLEVBQUUsQ0FDcEIsSUFBbUMsRUFDbkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLHNCQUFzQjtZQUNyQyxTQUFTLEVBQUUsc0JBQXNCO1lBQ2pDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLHNCQUFzQixFQUN0QixzQkFBc0IsRUFDdEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDRCQUE0QjtpQkFDbkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLGtCQUFrQixFQUFFLENBQ2xCLElBQWlDLEVBQ2pDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxvQkFBb0I7WUFDbkMsU0FBUyxFQUFFLG9CQUFvQjtZQUMvQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixvQkFBb0IsRUFDcEIsb0JBQW9CLEVBQ3BCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSwwQkFBMEI7aUJBQ2pDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixjQUFjLEVBQUUsQ0FDZCxJQUE2QixFQUM3QixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsZ0JBQWdCO1lBQy9CLFNBQVMsRUFBRSxnQkFBZ0I7WUFDM0IsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZ0JBQWdCLEVBQ2hCLGdCQUFnQixFQUNoQixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsc0JBQXNCO2lCQUM3QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osWUFBWSxFQUFFLENBQ1osSUFBMkIsRUFDM0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGNBQWM7WUFDN0IsU0FBUyxFQUFFLGNBQWM7WUFDekIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsY0FBYyxFQUNkLGNBQWMsRUFDZCxPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsb0JBQW9CO2lCQUMzQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osYUFBYSxFQUFFLENBQ2IsSUFBNEIsRUFDNUIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGVBQWU7WUFDOUIsU0FBUyxFQUFFLGVBQWU7WUFDMUIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsZUFBZSxFQUNmLGVBQWUsRUFDZixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUscUJBQXFCO2lCQUM1QjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osd0JBQXdCLEVBQUUsQ0FHeEIsSUFBdUMsRUFDdkMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBS2I7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLDBCQUEwQjtZQUN6QyxTQUFTLEVBQUUsMEJBQTBCO1lBQ3JDLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLDBCQUEwQixFQUMxQiwwQkFBMEIsRUFDMUIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGdDQUFnQztpQkFDdkM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLHFCQUFxQixFQUFFLENBQ3JCLElBQW9DLEVBQ3BDLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUtiO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSx1QkFBdUI7WUFDdEMsU0FBUyxFQUFFLHVCQUF1QjtZQUNsQyxHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVix1QkFBdUIsRUFDdkIsdUJBQXVCLEVBQ3ZCLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSw2QkFBNkI7aUJBQ3BDO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixXQUFXLEVBQUUsQ0FDWCxJQUEwQixFQUMxQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsYUFBYTtZQUM1QixTQUFTLEVBQUUsYUFBYTtZQUN4QixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixhQUFhLEVBQ2IsYUFBYSxFQUNiLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxtQkFBbUI7aUJBQzFCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixNQUFNLEVBQUUsQ0FDTixJQUFxQixFQUNyQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsUUFBUTtZQUN2QixTQUFTLEVBQUUsUUFBUTtZQUNuQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixRQUFRLEVBQ1IsUUFBUSxFQUNSLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxjQUFjO2lCQUNyQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osa0JBQWtCLEVBQUUsQ0FDbEIsSUFBaUMsRUFDakMsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLG9CQUFvQjtZQUNuQyxTQUFTLEVBQUUsb0JBQW9CO1lBQy9CLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLG9CQUFvQixFQUNwQixvQkFBb0IsRUFDcEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLDBCQUEwQjtpQkFDakM7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLE9BQU8sRUFBRSxDQUNQLElBQXNCLEVBQ3RCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxTQUFTO1lBQ3hCLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFNBQVMsRUFDVCxTQUFTLEVBQ1QsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGVBQWU7aUJBQ3RCO2FBQ0YsQ0FDRjtTQUNGLENBQUM7UUFDSixNQUFNLEVBQUUsQ0FDTixJQUFxQixFQUNyQixPQUVDLEVBQ0QsRUFBRSxDQUNGLElBQUksNEJBQVksQ0FFYjtZQUNELE1BQU07WUFDTixTQUFTLEVBQUUsVUFBVTtZQUNyQixhQUFhLEVBQUUsUUFBUTtZQUN2QixTQUFTLEVBQUUsUUFBUTtZQUNuQixHQUFHLElBQUEsbUNBQW1CLEVBQ3BCLFVBQVUsRUFDVixRQUFRLEVBQ1IsUUFBUSxFQUNSLE9BQU8sRUFBRSxNQUFNLEVBQ2YsSUFBSSxFQUNKO2dCQUNFO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxjQUFjO2lCQUNyQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osV0FBVyxFQUFFLENBQ1gsSUFBMEIsRUFDMUIsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGFBQWE7WUFDNUIsU0FBUyxFQUFFLGFBQWE7WUFDeEIsR0FBRyxJQUFBLG1DQUFtQixFQUNwQixVQUFVLEVBQ1YsYUFBYSxFQUNiLGFBQWEsRUFDYixPQUFPLEVBQUUsTUFBTSxFQUNmLElBQUksRUFDSjtnQkFDRTtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsbUJBQW1CO2lCQUMxQjthQUNGLENBQ0Y7U0FDRixDQUFDO1FBQ0osY0FBYyxFQUFFLENBQ2QsSUFBNkIsRUFDN0IsT0FFQyxFQUNELEVBQUUsQ0FDRixJQUFJLDRCQUFZLENBRWI7WUFDRCxNQUFNO1lBQ04sU0FBUyxFQUFFLFVBQVU7WUFDckIsYUFBYSxFQUFFLGdCQUFnQjtZQUMvQixTQUFTLEVBQUUsZ0JBQWdCO1lBQzNCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLHNCQUFzQjtpQkFDN0I7YUFDRixDQUNGO1NBQ0YsQ0FBQztRQUNKLFVBQVUsRUFBRSxDQUNWLElBQXlCLEVBQ3pCLE9BRUMsRUFDRCxFQUFFLENBQ0YsSUFBSSw0QkFBWSxDQUViO1lBQ0QsTUFBTTtZQUNOLFNBQVMsRUFBRSxVQUFVO1lBQ3JCLGFBQWEsRUFBRSxZQUFZO1lBQzNCLFNBQVMsRUFBRSxZQUFZO1lBQ3ZCLEdBQUcsSUFBQSxtQ0FBbUIsRUFDcEIsVUFBVSxFQUNWLFlBQVksRUFDWixZQUFZLEVBQ1osT0FBTyxFQUFFLE1BQU0sRUFDZixJQUFJLEVBQ0o7Z0JBQ0U7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLGtCQUFrQjtpQkFDekI7YUFDRixDQUNGO1NBQ0YsQ0FBQztLQUNMLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDdXN0b20gbXV0YXRpb24gb3BlcmF0aW9uc1xuICogQGdlbmVyYXRlZCBieSBAY29uc3RydWN0aXZlLWlvL2dyYXBocWwtY29kZWdlblxuICogRE8gTk9UIEVESVQgLSBjaGFuZ2VzIHdpbGwgYmUgb3ZlcndyaXR0ZW5cbiAqL1xuaW1wb3J0IHsgT3JtQ2xpZW50IH0gZnJvbSAnLi4vY2xpZW50JztcbmltcG9ydCB7IFF1ZXJ5QnVpbGRlciwgYnVpbGRDdXN0b21Eb2N1bWVudCB9IGZyb20gJy4uL3F1ZXJ5LWJ1aWxkZXInO1xuaW1wb3J0IHR5cGUgeyBJbmZlclNlbGVjdFJlc3VsdCwgRGVlcEV4YWN0IH0gZnJvbSAnLi4vc2VsZWN0LXR5cGVzJztcbmltcG9ydCB0eXBlIHtcbiAgVXBkYXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVEYXRhYmFzZUJ5U2NoZW1hTmFtZUlucHV0LFxuICBVcGRhdGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWVJbnB1dCxcbiAgVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIFVwZGF0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dCxcbiAgVXBkYXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIFVwZGF0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIFVwZGF0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWdJbnB1dCxcbiAgVXBkYXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dCxcbiAgVXBkYXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIFVwZGF0ZVNjaGVtYUJ5U2NoZW1hTmFtZUlucHV0LFxuICBVcGRhdGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWVJbnB1dCxcbiAgVXBkYXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBVcGRhdGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzSW5wdXQsXG4gIFVwZGF0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkSW5wdXQsXG4gIFVwZGF0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZElucHV0LFxuICBVcGRhdGVBcGlCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIFVwZGF0ZUFwcEJ5U2l0ZUlkSW5wdXQsXG4gIFVwZGF0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluSW5wdXQsXG4gIFVwZGF0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZElucHV0LFxuICBVcGRhdGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlSW5wdXQsXG4gIFVwZGF0ZVJsc01vZHVsZUJ5QXBpSWRJbnB1dCxcbiAgVXBkYXRlUm9sZVR5cGVCeU5hbWVJbnB1dCxcbiAgVXBkYXRlVXNlckJ5VXNlcm5hbWVJbnB1dCxcbiAgVXBkYXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXJJbnB1dCxcbiAgVXBkYXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzc0lucHV0LFxuICBVcGRhdGVFbWFpbEJ5RW1haWxJbnB1dCxcbiAgVXBkYXRlUGhvbmVOdW1iZXJCeU51bWJlcklucHV0LFxuICBEZWxldGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZURhdGFiYXNlQnlTY2hlbWFOYW1lSW5wdXQsXG4gIERlbGV0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZUlucHV0LFxuICBEZWxldGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgRGVsZXRlRmllbGRCeVRhYmxlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBEZWxldGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgRGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgRGVsZXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1Z0lucHV0LFxuICBEZWxldGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBEZWxldGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgRGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lSW5wdXQsXG4gIERlbGV0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0LFxuICBEZWxldGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZUlucHV0LFxuICBEZWxldGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQsXG4gIERlbGV0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXNJbnB1dCxcbiAgRGVsZXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWRJbnB1dCxcbiAgRGVsZXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkSW5wdXQsXG4gIERlbGV0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCxcbiAgRGVsZXRlQXBwQnlTaXRlSWRJbnB1dCxcbiAgRGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW5JbnB1dCxcbiAgRGVsZXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkSW5wdXQsXG4gIERlbGV0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGVJbnB1dCxcbiAgRGVsZXRlUmxzTW9kdWxlQnlBcGlJZElucHV0LFxuICBEZWxldGVSb2xlVHlwZUJ5TmFtZUlucHV0LFxuICBEZWxldGVVc2VyQnlVc2VybmFtZUlucHV0LFxuICBEZWxldGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcklucHV0LFxuICBEZWxldGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzSW5wdXQsXG4gIERlbGV0ZUVtYWlsQnlFbWFpbElucHV0LFxuICBEZWxldGVQaG9uZU51bWJlckJ5TnVtYmVySW5wdXQsXG4gIEFwcGx5UmxzSW5wdXQsXG4gIEJvb3RzdHJhcFVzZXJJbnB1dCxcbiAgQ3JlYXRlVXNlckRhdGFiYXNlSW5wdXQsXG4gIFByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJJbnB1dCxcbiAgU2V0RmllbGRPcmRlcklucHV0LFxuICBGcmVlemVPYmplY3RzSW5wdXQsXG4gIEluc2VydE5vZGVBdFBhdGhJbnB1dCxcbiAgUmVtb3ZlTm9kZUF0UGF0aElucHV0LFxuICBTZXREYXRhQXRQYXRoSW5wdXQsXG4gIFVwZGF0ZU5vZGVBdFBhdGhJbnB1dCxcbiAgSW5pdEVtcHR5UmVwb0lucHV0LFxuICBTZXRBbmRDb21taXRJbnB1dCxcbiAgU2V0UHJvcHNBbmRDb21taXRJbnB1dCxcbiAgQWRkQ29uc3RyYWludE5vb3BJbXBvcnRJbnB1dCxcbiAgQWRkSW1wb3J0SW5wdXQsXG4gIEFkZFNjaGVtYUltcG9ydElucHV0LFxuICBBZGRTY2hlbWFOb29wSW1wb3J0SW5wdXQsXG4gIEFkZFRhYmxlSW1wb3J0SW5wdXQsXG4gIEFkZFRhYmxlTm9vcEltcG9ydElucHV0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9uc0lucHV0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlc0lucHV0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblRhYmxlc0lucHV0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXNJbnB1dCxcbiAgQWx0ZXJQb2xpY3lJbnB1dCxcbiAgQWx0ZXJUYWJsZUFkZENoZWNrQ29uc3RyYWludElucHV0LFxuICBBbHRlclRhYmxlQWRkQ29sdW1uSW5wdXQsXG4gIEFsdGVyVGFibGVBZGRGb3JlaWduS2V5SW5wdXQsXG4gIEFsdGVyVGFibGVBZGRJbmhlcml0c0lucHV0LFxuICBBbHRlclRhYmxlQWRkUHJpbWFyeUtleUlucHV0LFxuICBBbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludElucHV0LFxuICBBbHRlclRhYmxlRHJvcENvbHVtbklucHV0LFxuICBBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHRJbnB1dCxcbiAgQWx0ZXJUYWJsZURyb3BDb2x1bW5Ob3ROdWxsSW5wdXQsXG4gIEFsdGVyVGFibGVEcm9wQ29uc3RyYWludElucHV0LFxuICBBbHRlclRhYmxlRHJvcEluaGVyaXRzSW5wdXQsXG4gIEFsdGVyVGFibGVNb2RpZnlDaGVja0NvbnN0cmFpbnRJbnB1dCxcbiAgQWx0ZXJUYWJsZVBlcm1CaXRsZW5JbnB1dCxcbiAgQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0SW5wdXQsXG4gIEFsdGVyVGFibGVSZW5hbWVDb2x1bW5JbnB1dCxcbiAgQWx0ZXJUYWJsZVNldENvbHVtbkRhdGFUeXBlSW5wdXQsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0SW5wdXQsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5Ob3ROdWxsSW5wdXQsXG4gIEFsdGVyVGFibGVTZXRTY2hlbWFJbnB1dCxcbiAgQ3JlYXRlQ29sdW1uSW5wdXQsXG4gIENyZWF0ZUZpeHR1cmVJbnB1dCxcbiAgQ3JlYXRlRnVuY3Rpb25JbnB1dCxcbiAgQ3JlYXRlSW5kZXhVbnNhZmVJbnB1dCxcbiAgQ3JlYXRlSW5zZXJ0SW5wdXQsXG4gIENyZWF0ZVRyaWdnZXJEaXN0aW5jdEZpZWxkc0lucHV0LFxuICBEZW5vcm1hbGl6ZWRGaWVsZHNJbnB1dCxcbiAgRGlzYWJsZVJvd0xldmVsU2VjdXJpdHlJbnB1dCxcbiAgRHJvcENvbnN0cmFpbnRJbnB1dCxcbiAgRHJvcEZ1bmN0aW9uSW5wdXQsXG4gIERyb3BJbmRleElucHV0LFxuICBEcm9wUG9saWN5SW5wdXQsXG4gIERyb3BTY2hlbWFJbnB1dCxcbiAgRHJvcFRhYmxlSW5wdXQsXG4gIERyb3BUcmlnZ2VySW5wdXQsXG4gIERyb3BUcmlnZ2VyRnVuY3Rpb25JbnB1dCxcbiAgRW5hYmxlUm93TGV2ZWxTZWN1cml0eUlucHV0LFxuICBFbnN1cmVEZWZhdWx0VmFsdWVzSW5zZXJ0SW5wdXQsXG4gIEdyYW50VXNhZ2VPblNjaGVtYUlucHV0LFxuICBJbW11dGFibGVGaWVsZFRyaWdnZXJJbnB1dCxcbiAgSW5mbGVjdGlvbkZpZWxkVHJpZ2dlcklucHV0LFxuICBJbnNlcnRBY3Rpb25JbnB1dCxcbiAgTW9kaWZ5Q2hlY2tDb25zdHJhaW50SW5wdXQsXG4gIE93bmVkRmllbGRzVHJpZ2dlcklucHV0LFxuICBQZW9wbGVzdGFtcHNJbnB1dCxcbiAgUmVuYW1lQ29uc3RyYWludElucHV0LFxuICBSZW5hbWVJbmRleElucHV0LFxuICBSZW5hbWVTY2hlbWFJbnB1dCxcbiAgUmVuYW1lVGFibGVJbnB1dCxcbiAgUmV2b2tlVXNhZ2VPblNjaGVtYUlucHV0LFxuICBTZXRDb21tZW50T25Db2x1bW5JbnB1dCxcbiAgU2V0Q29tbWVudE9uRnVuY3Rpb25JbnB1dCxcbiAgU2V0Q29tbWVudE9uVGFibGVJbnB1dCxcbiAgU2x1Z0ZpZWxkVHJpZ2dlcklucHV0LFxuICBUaW1lc3RhbXBzSW5wdXQsXG4gIENoZWNrUGFzc3dvcmRJbnB1dCxcbiAgQ29uZmlybURlbGV0ZUFjY291bnRJbnB1dCxcbiAgRXh0ZW5kVG9rZW5FeHBpcmVzSW5wdXQsXG4gIEZvcmdvdFBhc3N3b3JkSW5wdXQsXG4gIE9uZVRpbWVUb2tlbklucHV0LFxuICBSZXNldFBhc3N3b3JkSW5wdXQsXG4gIFNlbmRBY2NvdW50RGVsZXRpb25FbWFpbElucHV0LFxuICBTZW5kVmVyaWZpY2F0aW9uRW1haWxJbnB1dCxcbiAgU2V0UGFzc3dvcmRJbnB1dCxcbiAgU2lnbkluSW5wdXQsXG4gIFNpZ25Jbk9uZVRpbWVUb2tlbklucHV0LFxuICBTaWduT3V0SW5wdXQsXG4gIFNpZ25VcElucHV0LFxuICBWZXJpZnlFbWFpbElucHV0LFxuICBWZXJpZnlQYXNzd29yZElucHV0LFxuICBWZXJpZnlUb3RwSW5wdXQsXG4gIFVwZGF0ZUNoZWNrQ29uc3RyYWludFBheWxvYWQsXG4gIFVwZGF0ZURhdGFiYXNlUGF5bG9hZCxcbiAgVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25QYXlsb2FkLFxuICBVcGRhdGVGaWVsZFBheWxvYWQsXG4gIFVwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50UGF5bG9hZCxcbiAgVXBkYXRlSW5kZXhQYXlsb2FkLFxuICBVcGRhdGVMaW1pdEZ1bmN0aW9uUGF5bG9hZCxcbiAgVXBkYXRlTm9kZVR5cGVSZWdpc3RyeVBheWxvYWQsXG4gIFVwZGF0ZVBvbGljeVBheWxvYWQsXG4gIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50UGF5bG9hZCxcbiAgVXBkYXRlUHJvY2VkdXJlUGF5bG9hZCxcbiAgVXBkYXRlU2NoZW1hUGF5bG9hZCxcbiAgVXBkYXRlVGFibGVQYXlsb2FkLFxuICBVcGRhdGVUcmlnZ2VyUGF5bG9hZCxcbiAgVXBkYXRlVHJpZ2dlckZ1bmN0aW9uUGF5bG9hZCxcbiAgVXBkYXRlVW5pcXVlQ29uc3RyYWludFBheWxvYWQsXG4gIFVwZGF0ZUFzdEFjdGlvblBheWxvYWQsXG4gIFVwZGF0ZUFwaUV4dGVuc2lvblBheWxvYWQsXG4gIFVwZGF0ZUFwaVNjaGVtYVBheWxvYWQsXG4gIFVwZGF0ZUFwaVBheWxvYWQsXG4gIFVwZGF0ZUFwcFBheWxvYWQsXG4gIFVwZGF0ZURvbWFpblBheWxvYWQsXG4gIFVwZGF0ZUhpZXJhcmNoeU1vZHVsZVBheWxvYWQsXG4gIFVwZGF0ZVByb2ZpbGVzTW9kdWxlUGF5bG9hZCxcbiAgVXBkYXRlUmxzTW9kdWxlUGF5bG9hZCxcbiAgVXBkYXRlUm9sZVR5cGVQYXlsb2FkLFxuICBVcGRhdGVVc2VyUGF5bG9hZCxcbiAgVXBkYXRlQ29ubmVjdGVkQWNjb3VudFBheWxvYWQsXG4gIFVwZGF0ZUNyeXB0b0FkZHJlc3NQYXlsb2FkLFxuICBVcGRhdGVFbWFpbFBheWxvYWQsXG4gIFVwZGF0ZVBob25lTnVtYmVyUGF5bG9hZCxcbiAgRGVsZXRlQ2hlY2tDb25zdHJhaW50UGF5bG9hZCxcbiAgRGVsZXRlRGF0YWJhc2VQYXlsb2FkLFxuICBEZWxldGVEYXRhYmFzZUV4dGVuc2lvblBheWxvYWQsXG4gIERlbGV0ZUZpZWxkUGF5bG9hZCxcbiAgRGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRQYXlsb2FkLFxuICBEZWxldGVJbmRleFBheWxvYWQsXG4gIERlbGV0ZUxpbWl0RnVuY3Rpb25QYXlsb2FkLFxuICBEZWxldGVOb2RlVHlwZVJlZ2lzdHJ5UGF5bG9hZCxcbiAgRGVsZXRlUG9saWN5UGF5bG9hZCxcbiAgRGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRQYXlsb2FkLFxuICBEZWxldGVQcm9jZWR1cmVQYXlsb2FkLFxuICBEZWxldGVTY2hlbWFQYXlsb2FkLFxuICBEZWxldGVUYWJsZVBheWxvYWQsXG4gIERlbGV0ZVRyaWdnZXJQYXlsb2FkLFxuICBEZWxldGVUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkLFxuICBEZWxldGVVbmlxdWVDb25zdHJhaW50UGF5bG9hZCxcbiAgRGVsZXRlQXN0QWN0aW9uUGF5bG9hZCxcbiAgRGVsZXRlQXBpRXh0ZW5zaW9uUGF5bG9hZCxcbiAgRGVsZXRlQXBpU2NoZW1hUGF5bG9hZCxcbiAgRGVsZXRlQXBpUGF5bG9hZCxcbiAgRGVsZXRlQXBwUGF5bG9hZCxcbiAgRGVsZXRlRG9tYWluUGF5bG9hZCxcbiAgRGVsZXRlSGllcmFyY2h5TW9kdWxlUGF5bG9hZCxcbiAgRGVsZXRlUHJvZmlsZXNNb2R1bGVQYXlsb2FkLFxuICBEZWxldGVSbHNNb2R1bGVQYXlsb2FkLFxuICBEZWxldGVSb2xlVHlwZVBheWxvYWQsXG4gIERlbGV0ZVVzZXJQYXlsb2FkLFxuICBEZWxldGVDb25uZWN0ZWRBY2NvdW50UGF5bG9hZCxcbiAgRGVsZXRlQ3J5cHRvQWRkcmVzc1BheWxvYWQsXG4gIERlbGV0ZUVtYWlsUGF5bG9hZCxcbiAgRGVsZXRlUGhvbmVOdW1iZXJQYXlsb2FkLFxuICBBcHBseVJsc1BheWxvYWQsXG4gIEJvb3RzdHJhcFVzZXJQYXlsb2FkLFxuICBDcmVhdGVVc2VyRGF0YWJhc2VQYXlsb2FkLFxuICBQcm92aXNpb25EYXRhYmFzZVdpdGhVc2VyUGF5bG9hZCxcbiAgU2V0RmllbGRPcmRlclBheWxvYWQsXG4gIEZyZWV6ZU9iamVjdHNQYXlsb2FkLFxuICBJbnNlcnROb2RlQXRQYXRoUGF5bG9hZCxcbiAgUmVtb3ZlTm9kZUF0UGF0aFBheWxvYWQsXG4gIFNldERhdGFBdFBhdGhQYXlsb2FkLFxuICBVcGRhdGVOb2RlQXRQYXRoUGF5bG9hZCxcbiAgSW5pdEVtcHR5UmVwb1BheWxvYWQsXG4gIFNldEFuZENvbW1pdFBheWxvYWQsXG4gIFNldFByb3BzQW5kQ29tbWl0UGF5bG9hZCxcbiAgQWRkQ29uc3RyYWludE5vb3BJbXBvcnRQYXlsb2FkLFxuICBBZGRJbXBvcnRQYXlsb2FkLFxuICBBZGRTY2hlbWFJbXBvcnRQYXlsb2FkLFxuICBBZGRTY2hlbWFOb29wSW1wb3J0UGF5bG9hZCxcbiAgQWRkVGFibGVJbXBvcnRQYXlsb2FkLFxuICBBZGRUYWJsZU5vb3BJbXBvcnRQYXlsb2FkLFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9uc1BheWxvYWQsXG4gIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzUGF5bG9hZCxcbiAgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXNQYXlsb2FkLFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXNQYXlsb2FkLFxuICBBbHRlclBvbGljeVBheWxvYWQsXG4gIEFsdGVyVGFibGVBZGRDaGVja0NvbnN0cmFpbnRQYXlsb2FkLFxuICBBbHRlclRhYmxlQWRkQ29sdW1uUGF5bG9hZCxcbiAgQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXlQYXlsb2FkLFxuICBBbHRlclRhYmxlQWRkSW5oZXJpdHNQYXlsb2FkLFxuICBBbHRlclRhYmxlQWRkUHJpbWFyeUtleVBheWxvYWQsXG4gIEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50UGF5bG9hZCxcbiAgQWx0ZXJUYWJsZURyb3BDb2x1bW5QYXlsb2FkLFxuICBBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHRQYXlsb2FkLFxuICBBbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGxQYXlsb2FkLFxuICBBbHRlclRhYmxlRHJvcENvbnN0cmFpbnRQYXlsb2FkLFxuICBBbHRlclRhYmxlRHJvcEluaGVyaXRzUGF5bG9hZCxcbiAgQWx0ZXJUYWJsZU1vZGlmeUNoZWNrQ29uc3RyYWludFBheWxvYWQsXG4gIEFsdGVyVGFibGVQZXJtQml0bGVuUGF5bG9hZCxcbiAgQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0UGF5bG9hZCxcbiAgQWx0ZXJUYWJsZVJlbmFtZUNvbHVtblBheWxvYWQsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZVBheWxvYWQsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0UGF5bG9hZCxcbiAgQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGxQYXlsb2FkLFxuICBBbHRlclRhYmxlU2V0U2NoZW1hUGF5bG9hZCxcbiAgQ3JlYXRlQ29sdW1uUGF5bG9hZCxcbiAgQ3JlYXRlRml4dHVyZVBheWxvYWQsXG4gIENyZWF0ZUZ1bmN0aW9uUGF5bG9hZCxcbiAgQ3JlYXRlSW5kZXhVbnNhZmVQYXlsb2FkLFxuICBDcmVhdGVJbnNlcnRQYXlsb2FkLFxuICBDcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHNQYXlsb2FkLFxuICBEZW5vcm1hbGl6ZWRGaWVsZHNQYXlsb2FkLFxuICBEaXNhYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWQsXG4gIERyb3BDb25zdHJhaW50UGF5bG9hZCxcbiAgRHJvcEZ1bmN0aW9uUGF5bG9hZCxcbiAgRHJvcEluZGV4UGF5bG9hZCxcbiAgRHJvcFBvbGljeVBheWxvYWQsXG4gIERyb3BTY2hlbWFQYXlsb2FkLFxuICBEcm9wVGFibGVQYXlsb2FkLFxuICBEcm9wVHJpZ2dlclBheWxvYWQsXG4gIERyb3BUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkLFxuICBFbmFibGVSb3dMZXZlbFNlY3VyaXR5UGF5bG9hZCxcbiAgRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydFBheWxvYWQsXG4gIEdyYW50VXNhZ2VPblNjaGVtYVBheWxvYWQsXG4gIEltbXV0YWJsZUZpZWxkVHJpZ2dlclBheWxvYWQsXG4gIEluZmxlY3Rpb25GaWVsZFRyaWdnZXJQYXlsb2FkLFxuICBJbnNlcnRBY3Rpb25QYXlsb2FkLFxuICBNb2RpZnlDaGVja0NvbnN0cmFpbnRQYXlsb2FkLFxuICBPd25lZEZpZWxkc1RyaWdnZXJQYXlsb2FkLFxuICBQZW9wbGVzdGFtcHNQYXlsb2FkLFxuICBSZW5hbWVDb25zdHJhaW50UGF5bG9hZCxcbiAgUmVuYW1lSW5kZXhQYXlsb2FkLFxuICBSZW5hbWVTY2hlbWFQYXlsb2FkLFxuICBSZW5hbWVUYWJsZVBheWxvYWQsXG4gIFJldm9rZVVzYWdlT25TY2hlbWFQYXlsb2FkLFxuICBTZXRDb21tZW50T25Db2x1bW5QYXlsb2FkLFxuICBTZXRDb21tZW50T25GdW5jdGlvblBheWxvYWQsXG4gIFNldENvbW1lbnRPblRhYmxlUGF5bG9hZCxcbiAgU2x1Z0ZpZWxkVHJpZ2dlclBheWxvYWQsXG4gIFRpbWVzdGFtcHNQYXlsb2FkLFxuICBDaGVja1Bhc3N3b3JkUGF5bG9hZCxcbiAgQ29uZmlybURlbGV0ZUFjY291bnRQYXlsb2FkLFxuICBFeHRlbmRUb2tlbkV4cGlyZXNQYXlsb2FkLFxuICBGb3Jnb3RQYXNzd29yZFBheWxvYWQsXG4gIE9uZVRpbWVUb2tlblBheWxvYWQsXG4gIFJlc2V0UGFzc3dvcmRQYXlsb2FkLFxuICBTZW5kQWNjb3VudERlbGV0aW9uRW1haWxQYXlsb2FkLFxuICBTZW5kVmVyaWZpY2F0aW9uRW1haWxQYXlsb2FkLFxuICBTZXRQYXNzd29yZFBheWxvYWQsXG4gIFNpZ25JblBheWxvYWQsXG4gIFNpZ25Jbk9uZVRpbWVUb2tlblBheWxvYWQsXG4gIFNpZ25PdXRQYXlsb2FkLFxuICBTaWduVXBQYXlsb2FkLFxuICBWZXJpZnlFbWFpbFBheWxvYWQsXG4gIFZlcmlmeVBhc3N3b3JkUGF5bG9hZCxcbiAgVmVyaWZ5VG90cFBheWxvYWQsXG4gIFVwZGF0ZUNoZWNrQ29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZURhdGFiYXNlUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25QYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVGaWVsZFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlSW5kZXhQYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVMaW1pdEZ1bmN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlTm9kZVR5cGVSZWdpc3RyeVBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZVBvbGljeVBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlUHJvY2VkdXJlUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlU2NoZW1hUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlVGFibGVQYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVUcmlnZ2VyUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlVHJpZ2dlckZ1bmN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlVW5pcXVlQ29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUFzdEFjdGlvblBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUFwaUV4dGVuc2lvblBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUFwaVNjaGVtYVBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUFwaVBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUFwcFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZURvbWFpblBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUhpZXJhcmNoeU1vZHVsZVBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZVByb2ZpbGVzTW9kdWxlUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlUmxzTW9kdWxlUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlUm9sZVR5cGVQYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVVc2VyUGF5bG9hZFNlbGVjdCxcbiAgVXBkYXRlQ29ubmVjdGVkQWNjb3VudFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZUNyeXB0b0FkZHJlc3NQYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVFbWFpbFBheWxvYWRTZWxlY3QsXG4gIFVwZGF0ZVBob25lTnVtYmVyUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQ2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlRGF0YWJhc2VQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVEYXRhYmFzZUV4dGVuc2lvblBheWxvYWRTZWxlY3QsXG4gIERlbGV0ZUZpZWxkUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVJbmRleFBheWxvYWRTZWxlY3QsXG4gIERlbGV0ZUxpbWl0RnVuY3Rpb25QYXlsb2FkU2VsZWN0LFxuICBEZWxldGVOb2RlVHlwZVJlZ2lzdHJ5UGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlUG9saWN5UGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVQcm9jZWR1cmVQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVTY2hlbWFQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVUYWJsZVBheWxvYWRTZWxlY3QsXG4gIERlbGV0ZVRyaWdnZXJQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkU2VsZWN0LFxuICBEZWxldGVVbmlxdWVDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQXN0QWN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQXBpRXh0ZW5zaW9uUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQXBpU2NoZW1hUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQXBpUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQXBwUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlRG9tYWluUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlSGllcmFyY2h5TW9kdWxlUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlUHJvZmlsZXNNb2R1bGVQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVSbHNNb2R1bGVQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVSb2xlVHlwZVBheWxvYWRTZWxlY3QsXG4gIERlbGV0ZVVzZXJQYXlsb2FkU2VsZWN0LFxuICBEZWxldGVDb25uZWN0ZWRBY2NvdW50UGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlQ3J5cHRvQWRkcmVzc1BheWxvYWRTZWxlY3QsXG4gIERlbGV0ZUVtYWlsUGF5bG9hZFNlbGVjdCxcbiAgRGVsZXRlUGhvbmVOdW1iZXJQYXlsb2FkU2VsZWN0LFxuICBBcHBseVJsc1BheWxvYWRTZWxlY3QsXG4gIEJvb3RzdHJhcFVzZXJQYXlsb2FkU2VsZWN0LFxuICBDcmVhdGVVc2VyRGF0YWJhc2VQYXlsb2FkU2VsZWN0LFxuICBQcm92aXNpb25EYXRhYmFzZVdpdGhVc2VyUGF5bG9hZFNlbGVjdCxcbiAgU2V0RmllbGRPcmRlclBheWxvYWRTZWxlY3QsXG4gIEZyZWV6ZU9iamVjdHNQYXlsb2FkU2VsZWN0LFxuICBJbnNlcnROb2RlQXRQYXRoUGF5bG9hZFNlbGVjdCxcbiAgUmVtb3ZlTm9kZUF0UGF0aFBheWxvYWRTZWxlY3QsXG4gIFNldERhdGFBdFBhdGhQYXlsb2FkU2VsZWN0LFxuICBVcGRhdGVOb2RlQXRQYXRoUGF5bG9hZFNlbGVjdCxcbiAgSW5pdEVtcHR5UmVwb1BheWxvYWRTZWxlY3QsXG4gIFNldEFuZENvbW1pdFBheWxvYWRTZWxlY3QsXG4gIFNldFByb3BzQW5kQ29tbWl0UGF5bG9hZFNlbGVjdCxcbiAgQWRkQ29uc3RyYWludE5vb3BJbXBvcnRQYXlsb2FkU2VsZWN0LFxuICBBZGRJbXBvcnRQYXlsb2FkU2VsZWN0LFxuICBBZGRTY2hlbWFJbXBvcnRQYXlsb2FkU2VsZWN0LFxuICBBZGRTY2hlbWFOb29wSW1wb3J0UGF5bG9hZFNlbGVjdCxcbiAgQWRkVGFibGVJbXBvcnRQYXlsb2FkU2VsZWN0LFxuICBBZGRUYWJsZU5vb3BJbXBvcnRQYXlsb2FkU2VsZWN0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9uc1BheWxvYWRTZWxlY3QsXG4gIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzUGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXNQYXlsb2FkU2VsZWN0LFxuICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXNQYXlsb2FkU2VsZWN0LFxuICBBbHRlclBvbGljeVBheWxvYWRTZWxlY3QsXG4gIEFsdGVyVGFibGVBZGRDaGVja0NvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlQWRkQ29sdW1uUGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXlQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlQWRkSW5oZXJpdHNQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlQWRkUHJpbWFyeUtleVBheWxvYWRTZWxlY3QsXG4gIEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZURyb3BDb2x1bW5QYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHRQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGxQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlRHJvcENvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlRHJvcEluaGVyaXRzUGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZU1vZGlmeUNoZWNrQ29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gIEFsdGVyVGFibGVQZXJtQml0bGVuUGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0UGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZVJlbmFtZUNvbHVtblBheWxvYWRTZWxlY3QsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZVBheWxvYWRTZWxlY3QsXG4gIEFsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0UGF5bG9hZFNlbGVjdCxcbiAgQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGxQYXlsb2FkU2VsZWN0LFxuICBBbHRlclRhYmxlU2V0U2NoZW1hUGF5bG9hZFNlbGVjdCxcbiAgQ3JlYXRlQ29sdW1uUGF5bG9hZFNlbGVjdCxcbiAgQ3JlYXRlRml4dHVyZVBheWxvYWRTZWxlY3QsXG4gIENyZWF0ZUZ1bmN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgQ3JlYXRlSW5kZXhVbnNhZmVQYXlsb2FkU2VsZWN0LFxuICBDcmVhdGVJbnNlcnRQYXlsb2FkU2VsZWN0LFxuICBDcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHNQYXlsb2FkU2VsZWN0LFxuICBEZW5vcm1hbGl6ZWRGaWVsZHNQYXlsb2FkU2VsZWN0LFxuICBEaXNhYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWRTZWxlY3QsXG4gIERyb3BDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgRHJvcEZ1bmN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgRHJvcEluZGV4UGF5bG9hZFNlbGVjdCxcbiAgRHJvcFBvbGljeVBheWxvYWRTZWxlY3QsXG4gIERyb3BTY2hlbWFQYXlsb2FkU2VsZWN0LFxuICBEcm9wVGFibGVQYXlsb2FkU2VsZWN0LFxuICBEcm9wVHJpZ2dlclBheWxvYWRTZWxlY3QsXG4gIERyb3BUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkU2VsZWN0LFxuICBFbmFibGVSb3dMZXZlbFNlY3VyaXR5UGF5bG9hZFNlbGVjdCxcbiAgRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydFBheWxvYWRTZWxlY3QsXG4gIEdyYW50VXNhZ2VPblNjaGVtYVBheWxvYWRTZWxlY3QsXG4gIEltbXV0YWJsZUZpZWxkVHJpZ2dlclBheWxvYWRTZWxlY3QsXG4gIEluZmxlY3Rpb25GaWVsZFRyaWdnZXJQYXlsb2FkU2VsZWN0LFxuICBJbnNlcnRBY3Rpb25QYXlsb2FkU2VsZWN0LFxuICBNb2RpZnlDaGVja0NvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICBPd25lZEZpZWxkc1RyaWdnZXJQYXlsb2FkU2VsZWN0LFxuICBQZW9wbGVzdGFtcHNQYXlsb2FkU2VsZWN0LFxuICBSZW5hbWVDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgUmVuYW1lSW5kZXhQYXlsb2FkU2VsZWN0LFxuICBSZW5hbWVTY2hlbWFQYXlsb2FkU2VsZWN0LFxuICBSZW5hbWVUYWJsZVBheWxvYWRTZWxlY3QsXG4gIFJldm9rZVVzYWdlT25TY2hlbWFQYXlsb2FkU2VsZWN0LFxuICBTZXRDb21tZW50T25Db2x1bW5QYXlsb2FkU2VsZWN0LFxuICBTZXRDb21tZW50T25GdW5jdGlvblBheWxvYWRTZWxlY3QsXG4gIFNldENvbW1lbnRPblRhYmxlUGF5bG9hZFNlbGVjdCxcbiAgU2x1Z0ZpZWxkVHJpZ2dlclBheWxvYWRTZWxlY3QsXG4gIFRpbWVzdGFtcHNQYXlsb2FkU2VsZWN0LFxuICBDaGVja1Bhc3N3b3JkUGF5bG9hZFNlbGVjdCxcbiAgQ29uZmlybURlbGV0ZUFjY291bnRQYXlsb2FkU2VsZWN0LFxuICBFeHRlbmRUb2tlbkV4cGlyZXNQYXlsb2FkU2VsZWN0LFxuICBGb3Jnb3RQYXNzd29yZFBheWxvYWRTZWxlY3QsXG4gIE9uZVRpbWVUb2tlblBheWxvYWRTZWxlY3QsXG4gIFJlc2V0UGFzc3dvcmRQYXlsb2FkU2VsZWN0LFxuICBTZW5kQWNjb3VudERlbGV0aW9uRW1haWxQYXlsb2FkU2VsZWN0LFxuICBTZW5kVmVyaWZpY2F0aW9uRW1haWxQYXlsb2FkU2VsZWN0LFxuICBTZXRQYXNzd29yZFBheWxvYWRTZWxlY3QsXG4gIFNpZ25JblBheWxvYWRTZWxlY3QsXG4gIFNpZ25Jbk9uZVRpbWVUb2tlblBheWxvYWRTZWxlY3QsXG4gIFNpZ25PdXRQYXlsb2FkU2VsZWN0LFxuICBTaWduVXBQYXlsb2FkU2VsZWN0LFxuICBWZXJpZnlFbWFpbFBheWxvYWRTZWxlY3QsXG4gIFZlcmlmeVBhc3N3b3JkUGF5bG9hZFNlbGVjdCxcbiAgVmVyaWZ5VG90cFBheWxvYWRTZWxlY3QsXG59IGZyb20gJy4uL2lucHV0LXR5cGVzJztcbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZURhdGFiYXNlQnlTY2hlbWFOYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZURhdGFiYXNlQnlTY2hlbWFOYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVGaWVsZEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlRmllbGRCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWdJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVTY2hlbWFCeVNjaGVtYU5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlU2NoZW1hQnlTY2hlbWFOYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXNWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95c0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZFZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWRWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVBcHBCeVNpdGVJZFZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVBcHBCeVNpdGVJZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpblZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpbklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVIaWVyYXJjaHlNb2R1bGVCeURhdGFiYXNlSWRWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlUHJvZmlsZXNNb2R1bGVCeURhdGFiYXNlSWRBbmRNZW1iZXJzaGlwVHlwZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVSbHNNb2R1bGVCeUFwaUlkVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZVJsc01vZHVsZUJ5QXBpSWRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlUm9sZVR5cGVCeU5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlUm9sZVR5cGVCeU5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlVXNlckJ5VXNlcm5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlVXNlckJ5VXNlcm5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXJWYXJpYWJsZXMge1xuICBpbnB1dDogVXBkYXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXJJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzc1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFVwZGF0ZUVtYWlsQnlFbWFpbFZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVFbWFpbEJ5RW1haWxJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgVXBkYXRlUGhvbmVOdW1iZXJCeU51bWJlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBVcGRhdGVQaG9uZU51bWJlckJ5TnVtYmVySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVEYXRhYmFzZUJ5U2NoZW1hTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVEYXRhYmFzZUJ5U2NoZW1hTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlRmllbGRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1Z1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVNjaGVtYUJ5U2NoZW1hTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXNJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWRWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVBcGlCeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlQXBwQnlTaXRlSWRWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlQXBwQnlTaXRlSWRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW5WYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW5JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGVsZXRlUmxzTW9kdWxlQnlBcGlJZFZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZWxldGVSbHNNb2R1bGVCeUFwaUlkSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVJvbGVUeXBlQnlOYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVJvbGVUeXBlQnlOYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVVzZXJCeVVzZXJuYW1lVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZVVzZXJCeVVzZXJuYW1lSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVyVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERlbGV0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3NWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzc0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEZWxldGVFbWFpbEJ5RW1haWxWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlRW1haWxCeUVtYWlsSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbGV0ZVBob25lTnVtYmVyQnlOdW1iZXJWYXJpYWJsZXMge1xuICBpbnB1dDogRGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlcklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBcHBseVJsc1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBBcHBseVJsc0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBCb290c3RyYXBVc2VyVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEJvb3RzdHJhcFVzZXJJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlVXNlckRhdGFiYXNlVmFyaWFibGVzIHtcbiAgaW5wdXQ6IENyZWF0ZVVzZXJEYXRhYmFzZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBQcm92aXNpb25EYXRhYmFzZVdpdGhVc2VyVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2V0RmllbGRPcmRlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBTZXRGaWVsZE9yZGVySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEZyZWV6ZU9iamVjdHNWYXJpYWJsZXMge1xuICBpbnB1dDogRnJlZXplT2JqZWN0c0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBJbnNlcnROb2RlQXRQYXRoVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEluc2VydE5vZGVBdFBhdGhJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUmVtb3ZlTm9kZUF0UGF0aFZhcmlhYmxlcyB7XG4gIGlucHV0OiBSZW1vdmVOb2RlQXRQYXRoSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFNldERhdGFBdFBhdGhWYXJpYWJsZXMge1xuICBpbnB1dDogU2V0RGF0YUF0UGF0aElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBVcGRhdGVOb2RlQXRQYXRoVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFVwZGF0ZU5vZGVBdFBhdGhJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgSW5pdEVtcHR5UmVwb1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBJbml0RW1wdHlSZXBvSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFNldEFuZENvbW1pdFZhcmlhYmxlcyB7XG4gIGlucHV0OiBTZXRBbmRDb21taXRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2V0UHJvcHNBbmRDb21taXRWYXJpYWJsZXMge1xuICBpbnB1dDogU2V0UHJvcHNBbmRDb21taXRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWRkQ29uc3RyYWludE5vb3BJbXBvcnRWYXJpYWJsZXMge1xuICBpbnB1dDogQWRkQ29uc3RyYWludE5vb3BJbXBvcnRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWRkSW1wb3J0VmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFkZEltcG9ydElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBZGRTY2hlbWFJbXBvcnRWYXJpYWJsZXMge1xuICBpbnB1dDogQWRkU2NoZW1hSW1wb3J0SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFkZFNjaGVtYU5vb3BJbXBvcnRWYXJpYWJsZXMge1xuICBpbnB1dDogQWRkU2NoZW1hTm9vcEltcG9ydElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBZGRUYWJsZUltcG9ydFZhcmlhYmxlcyB7XG4gIGlucHV0OiBBZGRUYWJsZUltcG9ydElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBZGRUYWJsZU5vb3BJbXBvcnRWYXJpYWJsZXMge1xuICBpbnB1dDogQWRkVGFibGVOb29wSW1wb3J0SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uRnVuY3Rpb25zVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uRnVuY3Rpb25zSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlc1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXNJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJQb2xpY3lWYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJQb2xpY3lJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJUYWJsZUFkZENoZWNrQ29uc3RyYWludFZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVBZGRDb2x1bW5WYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJUYWJsZUFkZENvbHVtbklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlQWRkRm9yZWlnbktleVZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlclRhYmxlQWRkRm9yZWlnbktleUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlQWRkSW5oZXJpdHNWYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJUYWJsZUFkZEluaGVyaXRzSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVBZGRQcmltYXJ5S2V5VmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVBZGRQcmltYXJ5S2V5SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50VmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVEcm9wQ29sdW1uVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVEcm9wQ29sdW1uSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdFZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJUYWJsZURyb3BDb2x1bW5Ob3ROdWxsVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVEcm9wQ29sdW1uTm90TnVsbElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlRHJvcENvbnN0cmFpbnRWYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJUYWJsZURyb3BDb25zdHJhaW50SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEFsdGVyVGFibGVEcm9wSW5oZXJpdHNWYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJUYWJsZURyb3BJbmhlcml0c0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50VmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVNb2RpZnlDaGVja0NvbnN0cmFpbnRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJUYWJsZVBlcm1CaXRsZW5WYXJpYWJsZXMge1xuICBpbnB1dDogQWx0ZXJUYWJsZVBlcm1CaXRsZW5JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0VmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVQZXJtQml0bGVuRGVmYXVsdElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlUmVuYW1lQ29sdW1uVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVSZW5hbWVDb2x1bW5JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQWx0ZXJUYWJsZVNldENvbHVtbkRhdGFUeXBlVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlU2V0Q29sdW1uRGVmYXVsdFZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlclRhYmxlU2V0Q29sdW1uRGVmYXVsdElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbFZhcmlhYmxlcyB7XG4gIGlucHV0OiBBbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBBbHRlclRhYmxlU2V0U2NoZW1hVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEFsdGVyVGFibGVTZXRTY2hlbWFJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlQ29sdW1uVmFyaWFibGVzIHtcbiAgaW5wdXQ6IENyZWF0ZUNvbHVtbklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBDcmVhdGVGaXh0dXJlVmFyaWFibGVzIHtcbiAgaW5wdXQ6IENyZWF0ZUZpeHR1cmVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlRnVuY3Rpb25WYXJpYWJsZXMge1xuICBpbnB1dDogQ3JlYXRlRnVuY3Rpb25JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlSW5kZXhVbnNhZmVWYXJpYWJsZXMge1xuICBpbnB1dDogQ3JlYXRlSW5kZXhVbnNhZmVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlSW5zZXJ0VmFyaWFibGVzIHtcbiAgaW5wdXQ6IENyZWF0ZUluc2VydElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBDcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHNWYXJpYWJsZXMge1xuICBpbnB1dDogQ3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERlbm9ybWFsaXplZEZpZWxkc1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBEZW5vcm1hbGl6ZWRGaWVsZHNJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRGlzYWJsZVJvd0xldmVsU2VjdXJpdHlWYXJpYWJsZXMge1xuICBpbnB1dDogRGlzYWJsZVJvd0xldmVsU2VjdXJpdHlJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRHJvcENvbnN0cmFpbnRWYXJpYWJsZXMge1xuICBpbnB1dDogRHJvcENvbnN0cmFpbnRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRHJvcEZ1bmN0aW9uVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERyb3BGdW5jdGlvbklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEcm9wSW5kZXhWYXJpYWJsZXMge1xuICBpbnB1dDogRHJvcEluZGV4SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIERyb3BQb2xpY3lWYXJpYWJsZXMge1xuICBpbnB1dDogRHJvcFBvbGljeUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEcm9wU2NoZW1hVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERyb3BTY2hlbWFJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRHJvcFRhYmxlVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERyb3BUYWJsZUlucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEcm9wVHJpZ2dlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBEcm9wVHJpZ2dlcklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBEcm9wVHJpZ2dlckZ1bmN0aW9uVmFyaWFibGVzIHtcbiAgaW5wdXQ6IERyb3BUcmlnZ2VyRnVuY3Rpb25JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRW5hYmxlUm93TGV2ZWxTZWN1cml0eVZhcmlhYmxlcyB7XG4gIGlucHV0OiBFbmFibGVSb3dMZXZlbFNlY3VyaXR5SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEVuc3VyZURlZmF1bHRWYWx1ZXNJbnNlcnRWYXJpYWJsZXMge1xuICBpbnB1dDogRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBHcmFudFVzYWdlT25TY2hlbWFWYXJpYWJsZXMge1xuICBpbnB1dDogR3JhbnRVc2FnZU9uU2NoZW1hSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEltbXV0YWJsZUZpZWxkVHJpZ2dlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBJbW11dGFibGVGaWVsZFRyaWdnZXJJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgSW5mbGVjdGlvbkZpZWxkVHJpZ2dlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBJbmZsZWN0aW9uRmllbGRUcmlnZ2VySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIEluc2VydEFjdGlvblZhcmlhYmxlcyB7XG4gIGlucHV0OiBJbnNlcnRBY3Rpb25JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgTW9kaWZ5Q2hlY2tDb25zdHJhaW50VmFyaWFibGVzIHtcbiAgaW5wdXQ6IE1vZGlmeUNoZWNrQ29uc3RyYWludElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBPd25lZEZpZWxkc1RyaWdnZXJWYXJpYWJsZXMge1xuICBpbnB1dDogT3duZWRGaWVsZHNUcmlnZ2VySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFBlb3BsZXN0YW1wc1ZhcmlhYmxlcyB7XG4gIGlucHV0OiBQZW9wbGVzdGFtcHNJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUmVuYW1lQ29uc3RyYWludFZhcmlhYmxlcyB7XG4gIGlucHV0OiBSZW5hbWVDb25zdHJhaW50SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFJlbmFtZUluZGV4VmFyaWFibGVzIHtcbiAgaW5wdXQ6IFJlbmFtZUluZGV4SW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFJlbmFtZVNjaGVtYVZhcmlhYmxlcyB7XG4gIGlucHV0OiBSZW5hbWVTY2hlbWFJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUmVuYW1lVGFibGVWYXJpYWJsZXMge1xuICBpbnB1dDogUmVuYW1lVGFibGVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgUmV2b2tlVXNhZ2VPblNjaGVtYVZhcmlhYmxlcyB7XG4gIGlucHV0OiBSZXZva2VVc2FnZU9uU2NoZW1hSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFNldENvbW1lbnRPbkNvbHVtblZhcmlhYmxlcyB7XG4gIGlucHV0OiBTZXRDb21tZW50T25Db2x1bW5JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2V0Q29tbWVudE9uRnVuY3Rpb25WYXJpYWJsZXMge1xuICBpbnB1dDogU2V0Q29tbWVudE9uRnVuY3Rpb25JbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2V0Q29tbWVudE9uVGFibGVWYXJpYWJsZXMge1xuICBpbnB1dDogU2V0Q29tbWVudE9uVGFibGVJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2x1Z0ZpZWxkVHJpZ2dlclZhcmlhYmxlcyB7XG4gIGlucHV0OiBTbHVnRmllbGRUcmlnZ2VySW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFRpbWVzdGFtcHNWYXJpYWJsZXMge1xuICBpbnB1dDogVGltZXN0YW1wc0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBDaGVja1Bhc3N3b3JkVmFyaWFibGVzIHtcbiAgaW5wdXQ6IENoZWNrUGFzc3dvcmRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlybURlbGV0ZUFjY291bnRWYXJpYWJsZXMge1xuICBpbnB1dDogQ29uZmlybURlbGV0ZUFjY291bnRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgRXh0ZW5kVG9rZW5FeHBpcmVzVmFyaWFibGVzIHtcbiAgaW5wdXQ6IEV4dGVuZFRva2VuRXhwaXJlc0lucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBGb3Jnb3RQYXNzd29yZFZhcmlhYmxlcyB7XG4gIGlucHV0OiBGb3Jnb3RQYXNzd29yZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBPbmVUaW1lVG9rZW5WYXJpYWJsZXMge1xuICBpbnB1dDogT25lVGltZVRva2VuSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFJlc2V0UGFzc3dvcmRWYXJpYWJsZXMge1xuICBpbnB1dDogUmVzZXRQYXNzd29yZElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBTZW5kQWNjb3VudERlbGV0aW9uRW1haWxWYXJpYWJsZXMge1xuICBpbnB1dDogU2VuZEFjY291bnREZWxldGlvbkVtYWlsSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFNlbmRWZXJpZmljYXRpb25FbWFpbFZhcmlhYmxlcyB7XG4gIGlucHV0OiBTZW5kVmVyaWZpY2F0aW9uRW1haWxJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2V0UGFzc3dvcmRWYXJpYWJsZXMge1xuICBpbnB1dDogU2V0UGFzc3dvcmRJbnB1dDtcbn1cbmV4cG9ydCBpbnRlcmZhY2UgU2lnbkluVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFNpZ25JbklucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBTaWduSW5PbmVUaW1lVG9rZW5WYXJpYWJsZXMge1xuICBpbnB1dDogU2lnbkluT25lVGltZVRva2VuSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFNpZ25PdXRWYXJpYWJsZXMge1xuICBpbnB1dDogU2lnbk91dElucHV0O1xufVxuZXhwb3J0IGludGVyZmFjZSBTaWduVXBWYXJpYWJsZXMge1xuICBpbnB1dDogU2lnblVwSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFZlcmlmeUVtYWlsVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFZlcmlmeUVtYWlsSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFZlcmlmeVBhc3N3b3JkVmFyaWFibGVzIHtcbiAgaW5wdXQ6IFZlcmlmeVBhc3N3b3JkSW5wdXQ7XG59XG5leHBvcnQgaW50ZXJmYWNlIFZlcmlmeVRvdHBWYXJpYWJsZXMge1xuICBpbnB1dDogVmVyaWZ5VG90cElucHV0O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU11dGF0aW9uT3BlcmF0aW9ucyhjbGllbnQ6IE9ybUNsaWVudCkge1xuICByZXR1cm4ge1xuICAgIHVwZGF0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVDaGVja0NvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBVcGRhdGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUNoZWNrQ29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlQ2hlY2tDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZURhdGFiYXNlQnlTY2hlbWFOYW1lOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZURhdGFiYXNlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVEYXRhYmFzZUJ5U2NoZW1hTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVEYXRhYmFzZVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlRGF0YWJhc2VCeVNjaGVtYU5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZURhdGFiYXNlUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlRGF0YWJhc2VCeVNjaGVtYU5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVEYXRhYmFzZUJ5U2NoZW1hTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlRGF0YWJhc2VCeVNjaGVtYU5hbWUnLFxuICAgICAgICAgICd1cGRhdGVEYXRhYmFzZUJ5U2NoZW1hTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlRGF0YWJhc2VCeVNjaGVtYU5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlRGF0YWJhc2VQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBVcGRhdGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlRGF0YWJhc2VQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlRGF0YWJhc2VQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVGaWVsZEJ5VGFibGVJZEFuZE5hbWU6IDxjb25zdCBTIGV4dGVuZHMgVXBkYXRlRmllbGRQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFVwZGF0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVGaWVsZFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlRmllbGRCeVRhYmxlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxVcGRhdGVGaWVsZFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlRmllbGRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICAndXBkYXRlRmllbGRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVGaWVsZEJ5VGFibGVJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlRm9yZWlnbktleUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBVcGRhdGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlRm9yZWlnbktleUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlRm9yZWlnbktleUNvbnN0cmFpbnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVJbmRleFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogVXBkYXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUluZGV4UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZUluZGV4UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZUxpbWl0RnVuY3Rpb25QYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBVcGRhdGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVMaW1pdEZ1bmN0aW9uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlTGltaXRGdW5jdGlvblBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAndXBkYXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWc6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVOb2RlVHlwZVJlZ2lzdHJ5UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1Z1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVOb2RlVHlwZVJlZ2lzdHJ5UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVOb2RlVHlwZVJlZ2lzdHJ5UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1ZycsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWcnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWcnLFxuICAgICAgICAgICd1cGRhdGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWU6IDxjb25zdCBTIGV4dGVuZHMgVXBkYXRlUG9saWN5UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZVBvbGljeVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8VXBkYXRlUG9saWN5UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlUHJvY2VkdXJlUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVQcm9jZWR1cmVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZVByb2NlZHVyZVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAndXBkYXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlU2NoZW1hUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVTY2hlbWFQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZVNjaGVtYVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAndXBkYXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVTY2hlbWFCeVNjaGVtYU5hbWU6IDxjb25zdCBTIGV4dGVuZHMgVXBkYXRlU2NoZW1hUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVTY2hlbWFCeVNjaGVtYU5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlU2NoZW1hUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVTY2hlbWFCeVNjaGVtYU5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZVNjaGVtYVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZVNjaGVtYUJ5U2NoZW1hTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVNjaGVtYUJ5U2NoZW1hTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlU2NoZW1hQnlTY2hlbWFOYW1lJyxcbiAgICAgICAgICAndXBkYXRlU2NoZW1hQnlTY2hlbWFOYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVTY2hlbWFCeVNjaGVtYU5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZVRhYmxlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlVGFibGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlVGFibGVQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZVRyaWdnZXJQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFVwZGF0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZVRyaWdnZXJQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVUcmlnZ2VyUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICd1cGRhdGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZVRyaWdnZXJGdW5jdGlvblBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IFVwZGF0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlVHJpZ2dlckZ1bmN0aW9uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVVbmlxdWVDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlVW5pcXVlQ29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZVVuaXF1ZUNvbnN0cmFpbnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlQXN0QWN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95c1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVBc3RBY3Rpb25QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXM6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZUFzdEFjdGlvblBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXMnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzJyxcbiAgICAgICAgICAndXBkYXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95cycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95c0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZDogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZUFwaUV4dGVuc2lvblBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IFVwZGF0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUFwaUV4dGVuc2lvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWQ6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZUFwaUV4dGVuc2lvblBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkJyxcbiAgICAgICAgICAndXBkYXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZDogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZUFwaVNjaGVtYVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IFVwZGF0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVBcGlTY2hlbWFQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlQXBpU2NoZW1hUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWQnLFxuICAgICAgICAgICd1cGRhdGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVBcGlCeURhdGFiYXNlSWRBbmROYW1lOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZUFwaVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogVXBkYXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVBcGlQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZUFwaVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVBcGlCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVBcGlCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAndXBkYXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVBcHBCeVNpdGVJZDogPGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVBcHBQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFVwZGF0ZUFwcEJ5U2l0ZUlkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUFwcFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlQXBwQnlTaXRlSWQ6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZUFwcFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUFwcEJ5U2l0ZUlkJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlQXBwQnlTaXRlSWQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUFwcEJ5U2l0ZUlkJyxcbiAgICAgICAgICAndXBkYXRlQXBwQnlTaXRlSWQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUFwcEJ5U2l0ZUlkSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlRG9tYWluUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW5WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlRG9tYWluUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpbjogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlRG9tYWluUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW4nLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpbicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW4nLFxuICAgICAgICAgICd1cGRhdGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW5JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgVXBkYXRlSGllcmFyY2h5TW9kdWxlUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUhpZXJhcmNoeU1vZHVsZVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVIaWVyYXJjaHlNb2R1bGVQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVIaWVyYXJjaHlNb2R1bGVCeURhdGFiYXNlSWQnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVIaWVyYXJjaHlNb2R1bGVCeURhdGFiYXNlSWQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZCcsXG4gICAgICAgICAgJ3VwZGF0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVQcm9maWxlc01vZHVsZVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IFVwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlUHJvZmlsZXNNb2R1bGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFVwZGF0ZVByb2ZpbGVzTW9kdWxlUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlUHJvZmlsZXNNb2R1bGVCeURhdGFiYXNlSWRBbmRNZW1iZXJzaGlwVHlwZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGUnLFxuICAgICAgICAgICd1cGRhdGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVJsc01vZHVsZUJ5QXBpSWQ6IDxjb25zdCBTIGV4dGVuZHMgVXBkYXRlUmxzTW9kdWxlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVSbHNNb2R1bGVCeUFwaUlkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZVJsc01vZHVsZVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlUmxzTW9kdWxlQnlBcGlJZDogSW5mZXJTZWxlY3RSZXN1bHQ8VXBkYXRlUmxzTW9kdWxlUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlUmxzTW9kdWxlQnlBcGlJZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVJsc01vZHVsZUJ5QXBpSWQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZVJsc01vZHVsZUJ5QXBpSWQnLFxuICAgICAgICAgICd1cGRhdGVSbHNNb2R1bGVCeUFwaUlkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVSbHNNb2R1bGVCeUFwaUlkSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZVJvbGVUeXBlQnlOYW1lOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZVJvbGVUeXBlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVSb2xlVHlwZUJ5TmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVSb2xlVHlwZVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlUm9sZVR5cGVCeU5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZVJvbGVUeXBlUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlUm9sZVR5cGVCeU5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVSb2xlVHlwZUJ5TmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlUm9sZVR5cGVCeU5hbWUnLFxuICAgICAgICAgICd1cGRhdGVSb2xlVHlwZUJ5TmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlUm9sZVR5cGVCeU5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlVXNlckJ5VXNlcm5hbWU6IDxjb25zdCBTIGV4dGVuZHMgVXBkYXRlVXNlclBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogVXBkYXRlVXNlckJ5VXNlcm5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVXBkYXRlVXNlclBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdXBkYXRlVXNlckJ5VXNlcm5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZVVzZXJQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVVc2VyQnlVc2VybmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZVVzZXJCeVVzZXJuYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVVc2VyQnlVc2VybmFtZScsXG4gICAgICAgICAgJ3VwZGF0ZVVzZXJCeVVzZXJuYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVVc2VyQnlVc2VybmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcjogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFVwZGF0ZUNvbm5lY3RlZEFjY291bnRQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBVcGRhdGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllclZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVDb25uZWN0ZWRBY2NvdW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcjogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgVXBkYXRlQ29ubmVjdGVkQWNjb3VudFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVyJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXInLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVyJyxcbiAgICAgICAgICAndXBkYXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXInLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVySW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3M6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVDcnlwdG9BZGRyZXNzUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogVXBkYXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzc1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBVcGRhdGVDcnlwdG9BZGRyZXNzUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVDcnlwdG9BZGRyZXNzUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzcycsXG4gICAgICAgIGZpZWxkTmFtZTogJ3VwZGF0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3MnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1VwZGF0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3MnLFxuICAgICAgICAgICd1cGRhdGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdVcGRhdGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHVwZGF0ZUVtYWlsQnlFbWFpbDogPGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVFbWFpbFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogVXBkYXRlRW1haWxCeUVtYWlsVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZUVtYWlsUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVFbWFpbEJ5RW1haWw6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZUVtYWlsUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVXBkYXRlRW1haWxCeUVtYWlsJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlRW1haWxCeUVtYWlsJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVFbWFpbEJ5RW1haWwnLFxuICAgICAgICAgICd1cGRhdGVFbWFpbEJ5RW1haWwnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZUVtYWlsQnlFbWFpbElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB1cGRhdGVQaG9uZU51bWJlckJ5TnVtYmVyOiA8Y29uc3QgUyBleHRlbmRzIFVwZGF0ZVBob25lTnVtYmVyUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVQaG9uZU51bWJlckJ5TnVtYmVyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZVBob25lTnVtYmVyUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB1cGRhdGVQaG9uZU51bWJlckJ5TnVtYmVyOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBVcGRhdGVQaG9uZU51bWJlclBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1VwZGF0ZVBob25lTnVtYmVyQnlOdW1iZXInLFxuICAgICAgICBmaWVsZE5hbWU6ICd1cGRhdGVQaG9uZU51bWJlckJ5TnVtYmVyJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdVcGRhdGVQaG9uZU51bWJlckJ5TnVtYmVyJyxcbiAgICAgICAgICAndXBkYXRlUGhvbmVOdW1iZXJCeU51bWJlcicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVXBkYXRlUGhvbmVOdW1iZXJCeU51bWJlcklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRGVsZXRlQ2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGVsZXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVDaGVja0NvbnN0cmFpbnRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZUNoZWNrQ29uc3RyYWludFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZUNoZWNrQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVDaGVja0NvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlQ2hlY2tDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVEYXRhYmFzZUJ5U2NoZW1hTmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVEYXRhYmFzZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlRGF0YWJhc2VCeVNjaGVtYU5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlRGF0YWJhc2VQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZURhdGFiYXNlQnlTY2hlbWFOYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVEYXRhYmFzZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZURhdGFiYXNlQnlTY2hlbWFOYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlRGF0YWJhc2VCeVNjaGVtYU5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZURhdGFiYXNlQnlTY2hlbWFOYW1lJyxcbiAgICAgICAgICAnZGVsZXRlRGF0YWJhc2VCeVNjaGVtYU5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZURhdGFiYXNlQnlTY2hlbWFOYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZURhdGFiYXNlUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGVsZXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZURhdGFiYXNlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZURhdGFiYXNlUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlRGF0YWJhc2VCeVByaXZhdGVTY2hlbWFOYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWUnLFxuICAgICAgICAgICdkZWxldGVEYXRhYmFzZUJ5UHJpdmF0ZVNjaGVtYU5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZURhdGFiYXNlQnlQcml2YXRlU2NoZW1hTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVEYXRhYmFzZUV4dGVuc2lvblBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVEYXRhYmFzZUV4dGVuc2lvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVEYXRhYmFzZUV4dGVuc2lvblBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZURhdGFiYXNlRXh0ZW5zaW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlRGF0YWJhc2VFeHRlbnNpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVEYXRhYmFzZUV4dGVuc2lvbkJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlRmllbGRCeVRhYmxlSWRBbmROYW1lOiA8Y29uc3QgUyBleHRlbmRzIERlbGV0ZUZpZWxkUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBEZWxldGVGaWVsZEJ5VGFibGVJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlRmllbGRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8RGVsZXRlRmllbGRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVGaWVsZEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVGaWVsZEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZUZpZWxkQnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlRmllbGRCeVRhYmxlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlRm9yZWlnbktleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICdkZWxldGVGb3JlaWduS2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZUZvcmVpZ25LZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWU6IDxjb25zdCBTIGV4dGVuZHMgRGVsZXRlSW5kZXhQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERlbGV0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVJbmRleFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVJbmRleFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUluZGV4QnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlSW5kZXhCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVJbmRleEJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVMaW1pdEZ1bmN0aW9uUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlTGltaXRGdW5jdGlvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlTGltaXRGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZUxpbWl0RnVuY3Rpb25QYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZUxpbWl0RnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVMaW1pdEZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRGVsZXRlTm9kZVR5cGVSZWdpc3RyeVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWdWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlTm9kZVR5cGVSZWdpc3RyeVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1ZzogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlTm9kZVR5cGVSZWdpc3RyeVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZU5vZGVUeXBlUmVnaXN0cnlCeVNsdWcnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVOb2RlVHlwZVJlZ2lzdHJ5QnlTbHVnJyxcbiAgICAgICAgICAnZGVsZXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1ZycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlTm9kZVR5cGVSZWdpc3RyeUJ5U2x1Z0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lOiA8Y29uc3QgUyBleHRlbmRzIERlbGV0ZVBvbGljeVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVQb2xpY3lQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PERlbGV0ZVBvbGljeVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVBvbGljeUJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVQb2xpY3lCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlUG9saWN5QnlUYWJsZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZVByaW1hcnlLZXlDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlUHJpbWFyeUtleUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVQcmltYXJ5S2V5Q29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZVByb2NlZHVyZVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlUHJvY2VkdXJlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVQcm9jZWR1cmVQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVQcm9jZWR1cmVCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlUHJvY2VkdXJlQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVByb2NlZHVyZUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZVNjaGVtYVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlU2NoZW1hUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVTY2hlbWFQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVTY2hlbWFCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlU2NoZW1hQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVNjaGVtYUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lOiA8Y29uc3QgUyBleHRlbmRzIERlbGV0ZVNjaGVtYVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVNjaGVtYVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVTY2hlbWFQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVTY2hlbWFCeVNjaGVtYU5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVTY2hlbWFCeVNjaGVtYU5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZVNjaGVtYUJ5U2NoZW1hTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZVNjaGVtYUJ5U2NoZW1hTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlU2NoZW1hQnlTY2hlbWFOYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVUYWJsZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVRhYmxlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWU6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZVRhYmxlUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlVGFibGVCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgICdkZWxldGVUYWJsZUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVRhYmxlQnlEYXRhYmFzZUlkQW5kTmFtZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVUcmlnZ2VyUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBEZWxldGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVUcmlnZ2VyUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVUcmlnZ2VyQnlUYWJsZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlVHJpZ2dlclBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lJyxcbiAgICAgICAgICAnZGVsZXRlVHJpZ2dlckJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVRyaWdnZXJCeVRhYmxlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWU6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBEZWxldGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVRyaWdnZXJGdW5jdGlvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlVHJpZ2dlckZ1bmN0aW9uUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlVHJpZ2dlckZ1bmN0aW9uQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZVRyaWdnZXJGdW5jdGlvbkJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgICdkZWxldGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVUcmlnZ2VyRnVuY3Rpb25CeURhdGFiYXNlSWRBbmROYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRGVsZXRlVW5pcXVlQ29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVVuaXF1ZUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZVVuaXF1ZUNvbnN0cmFpbnRCeVRhYmxlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVVbmlxdWVDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWUnLFxuICAgICAgICAgICdkZWxldGVVbmlxdWVDb25zdHJhaW50QnlUYWJsZUlkQW5kTmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlVW5pcXVlQ29uc3RyYWludEJ5VGFibGVJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95czogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZUFzdEFjdGlvblBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXNWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlQXN0QWN0aW9uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVBc3RBY3Rpb25QYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVBc3RBY3Rpb25CeURhdGFiYXNlSWRBbmREZXBsb3lzJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95cycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlQXN0QWN0aW9uQnlEYXRhYmFzZUlkQW5kRGVwbG95cycsXG4gICAgICAgICAgJ2RlbGV0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZUFzdEFjdGlvbkJ5RGF0YWJhc2VJZEFuZERlcGxveXNJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlQXBpRXh0ZW5zaW9uQnlTY2hlbWFOYW1lQW5kQXBpSWQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVBcGlFeHRlbnNpb25QYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBEZWxldGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVBcGlFeHRlbnNpb25QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVBcGlFeHRlbnNpb25QYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZCcsXG4gICAgICAgICAgJ2RlbGV0ZUFwaUV4dGVuc2lvbkJ5U2NoZW1hTmFtZUFuZEFwaUlkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVBcGlFeHRlbnNpb25CeVNjaGVtYU5hbWVBbmRBcGlJZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVBcGlTY2hlbWFQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBEZWxldGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlQXBpU2NoZW1hUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWQ6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZUFwaVNjaGVtYVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUFwaVNjaGVtYUJ5QXBpSWRBbmRTY2hlbWFJZCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkJyxcbiAgICAgICAgICAnZGVsZXRlQXBpU2NoZW1hQnlBcGlJZEFuZFNjaGVtYUlkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVBcGlTY2hlbWFCeUFwaUlkQW5kU2NoZW1hSWRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVBcGlQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERlbGV0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlQXBpUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVBcGlCeURhdGFiYXNlSWRBbmROYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVBcGlQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVBcGlCeURhdGFiYXNlSWRBbmROYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlQXBpQnlEYXRhYmFzZUlkQW5kTmFtZScsXG4gICAgICAgICAgJ2RlbGV0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZUFwaUJ5RGF0YWJhc2VJZEFuZE5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlQXBwQnlTaXRlSWQ6IDxjb25zdCBTIGV4dGVuZHMgRGVsZXRlQXBwUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBEZWxldGVBcHBCeVNpdGVJZFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVBcHBQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZUFwcEJ5U2l0ZUlkOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVBcHBQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVBcHBCeVNpdGVJZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUFwcEJ5U2l0ZUlkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVBcHBCeVNpdGVJZCcsXG4gICAgICAgICAgJ2RlbGV0ZUFwcEJ5U2l0ZUlkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVBcHBCeVNpdGVJZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVEb21haW5CeVN1YmRvbWFpbkFuZERvbWFpbjogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZURvbWFpblBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZURvbWFpblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW46IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZURvbWFpblBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW4nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluJyxcbiAgICAgICAgICAnZGVsZXRlRG9tYWluQnlTdWJkb21haW5BbmREb21haW4nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZURvbWFpbkJ5U3ViZG9tYWluQW5kRG9tYWluSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZDogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERlbGV0ZUhpZXJhcmNoeU1vZHVsZVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVIaWVyYXJjaHlNb2R1bGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlSGllcmFyY2h5TW9kdWxlUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlSGllcmFyY2h5TW9kdWxlQnlEYXRhYmFzZUlkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVIaWVyYXJjaHlNb2R1bGVCeURhdGFiYXNlSWQnLFxuICAgICAgICAgICdkZWxldGVIaWVyYXJjaHlNb2R1bGVCeURhdGFiYXNlSWQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZUhpZXJhcmNoeU1vZHVsZUJ5RGF0YWJhc2VJZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRGVsZXRlUHJvZmlsZXNNb2R1bGVQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBEZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVByb2ZpbGVzTW9kdWxlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEZWxldGVQcm9maWxlc01vZHVsZVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVByb2ZpbGVzTW9kdWxlQnlEYXRhYmFzZUlkQW5kTWVtYmVyc2hpcFR5cGUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVQcm9maWxlc01vZHVsZUJ5RGF0YWJhc2VJZEFuZE1lbWJlcnNoaXBUeXBlJyxcbiAgICAgICAgICAnZGVsZXRlUHJvZmlsZXNNb2R1bGVCeURhdGFiYXNlSWRBbmRNZW1iZXJzaGlwVHlwZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlUHJvZmlsZXNNb2R1bGVCeURhdGFiYXNlSWRBbmRNZW1iZXJzaGlwVHlwZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVSbHNNb2R1bGVCeUFwaUlkOiA8Y29uc3QgUyBleHRlbmRzIERlbGV0ZVJsc01vZHVsZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlUmxzTW9kdWxlQnlBcGlJZFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVSbHNNb2R1bGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZVJsc01vZHVsZUJ5QXBpSWQ6IEluZmVyU2VsZWN0UmVzdWx0PERlbGV0ZVJsc01vZHVsZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVJsc01vZHVsZUJ5QXBpSWQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVSbHNNb2R1bGVCeUFwaUlkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVSbHNNb2R1bGVCeUFwaUlkJyxcbiAgICAgICAgICAnZGVsZXRlUmxzTW9kdWxlQnlBcGlJZCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlUmxzTW9kdWxlQnlBcGlJZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVSb2xlVHlwZUJ5TmFtZTogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVSb2xlVHlwZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlUm9sZVR5cGVCeU5hbWVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlUm9sZVR5cGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZVJvbGVUeXBlQnlOYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVSb2xlVHlwZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZVJvbGVUeXBlQnlOYW1lJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlUm9sZVR5cGVCeU5hbWUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0RlbGV0ZVJvbGVUeXBlQnlOYW1lJyxcbiAgICAgICAgICAnZGVsZXRlUm9sZVR5cGVCeU5hbWUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVJvbGVUeXBlQnlOYW1lSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbGV0ZVVzZXJCeVVzZXJuYW1lOiA8Y29uc3QgUyBleHRlbmRzIERlbGV0ZVVzZXJQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERlbGV0ZVVzZXJCeVVzZXJuYW1lVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERlbGV0ZVVzZXJQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbGV0ZVVzZXJCeVVzZXJuYW1lOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVVc2VyUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVsZXRlVXNlckJ5VXNlcm5hbWUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVVc2VyQnlVc2VybmFtZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlVXNlckJ5VXNlcm5hbWUnLFxuICAgICAgICAgICdkZWxldGVVc2VyQnlVc2VybmFtZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlVXNlckJ5VXNlcm5hbWVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXI6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVDb25uZWN0ZWRBY2NvdW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGVsZXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXJWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlQ29ubmVjdGVkQWNjb3VudFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlQ29ubmVjdGVkQWNjb3VudEJ5U2VydmljZUFuZElkZW50aWZpZXI6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIERlbGV0ZUNvbm5lY3RlZEFjY291bnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcicsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVyJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcicsXG4gICAgICAgICAgJ2RlbGV0ZUNvbm5lY3RlZEFjY291bnRCeVNlcnZpY2VBbmRJZGVudGlmaWVyJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVDb25uZWN0ZWRBY2NvdW50QnlTZXJ2aWNlQW5kSWRlbnRpZmllcklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRGVsZXRlQ3J5cHRvQWRkcmVzc1BheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IERlbGV0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3NWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGVsZXRlQ3J5cHRvQWRkcmVzc1BheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzczogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlQ3J5cHRvQWRkcmVzc1BheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZUNyeXB0b0FkZHJlc3NCeUFkZHJlc3MnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkZWxldGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZWxldGVDcnlwdG9BZGRyZXNzQnlBZGRyZXNzJyxcbiAgICAgICAgICAnZGVsZXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzcycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRGVsZXRlQ3J5cHRvQWRkcmVzc0J5QWRkcmVzc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkZWxldGVFbWFpbEJ5RW1haWw6IDxjb25zdCBTIGV4dGVuZHMgRGVsZXRlRW1haWxQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERlbGV0ZUVtYWlsQnlFbWFpbFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVFbWFpbFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlRW1haWxCeUVtYWlsOiBJbmZlclNlbGVjdFJlc3VsdDxEZWxldGVFbWFpbFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0RlbGV0ZUVtYWlsQnlFbWFpbCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2RlbGV0ZUVtYWlsQnlFbWFpbCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlRW1haWxCeUVtYWlsJyxcbiAgICAgICAgICAnZGVsZXRlRW1haWxCeUVtYWlsJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEZWxldGVFbWFpbEJ5RW1haWxJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlcjogPGNvbnN0IFMgZXh0ZW5kcyBEZWxldGVQaG9uZU51bWJlclBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlclZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZWxldGVQaG9uZU51bWJlclBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlcjogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRGVsZXRlUGhvbmVOdW1iZXJQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEZWxldGVQaG9uZU51bWJlckJ5TnVtYmVyJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlcicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRGVsZXRlUGhvbmVOdW1iZXJCeU51bWJlcicsXG4gICAgICAgICAgJ2RlbGV0ZVBob25lTnVtYmVyQnlOdW1iZXInLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0RlbGV0ZVBob25lTnVtYmVyQnlOdW1iZXJJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYXBwbHlSbHM6IDxjb25zdCBTIGV4dGVuZHMgQXBwbHlSbHNQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IEFwcGx5UmxzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFwcGx5UmxzUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhcHBseVJsczogSW5mZXJTZWxlY3RSZXN1bHQ8QXBwbHlSbHNQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBcHBseVJscycsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FwcGx5UmxzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBcHBseVJscycsXG4gICAgICAgICAgJ2FwcGx5UmxzJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBcHBseVJsc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBib290c3RyYXBVc2VyOiA8Y29uc3QgUyBleHRlbmRzIEJvb3RzdHJhcFVzZXJQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IEJvb3RzdHJhcFVzZXJWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQm9vdHN0cmFwVXNlclBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYm9vdHN0cmFwVXNlcjogSW5mZXJTZWxlY3RSZXN1bHQ8Qm9vdHN0cmFwVXNlclBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Jvb3RzdHJhcFVzZXInLFxuICAgICAgICBmaWVsZE5hbWU6ICdib290c3RyYXBVc2VyJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdCb290c3RyYXBVc2VyJyxcbiAgICAgICAgICAnYm9vdHN0cmFwVXNlcicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQm9vdHN0cmFwVXNlcklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBjcmVhdGVVc2VyRGF0YWJhc2U6IDxjb25zdCBTIGV4dGVuZHMgQ3JlYXRlVXNlckRhdGFiYXNlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBDcmVhdGVVc2VyRGF0YWJhc2VWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQ3JlYXRlVXNlckRhdGFiYXNlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBjcmVhdGVVc2VyRGF0YWJhc2U6IEluZmVyU2VsZWN0UmVzdWx0PENyZWF0ZVVzZXJEYXRhYmFzZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0NyZWF0ZVVzZXJEYXRhYmFzZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2NyZWF0ZVVzZXJEYXRhYmFzZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQ3JlYXRlVXNlckRhdGFiYXNlJyxcbiAgICAgICAgICAnY3JlYXRlVXNlckRhdGFiYXNlJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdDcmVhdGVVc2VyRGF0YWJhc2VJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgcHJvdmlzaW9uRGF0YWJhc2VXaXRoVXNlcjogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIFByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBQcm92aXNpb25EYXRhYmFzZVdpdGhVc2VyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXI6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIFByb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdQcm92aXNpb25EYXRhYmFzZVdpdGhVc2VyJyxcbiAgICAgICAgZmllbGROYW1lOiAncHJvdmlzaW9uRGF0YWJhc2VXaXRoVXNlcicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnUHJvdmlzaW9uRGF0YWJhc2VXaXRoVXNlcicsXG4gICAgICAgICAgJ3Byb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXInLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1Byb3Zpc2lvbkRhdGFiYXNlV2l0aFVzZXJJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2V0RmllbGRPcmRlcjogPGNvbnN0IFMgZXh0ZW5kcyBTZXRGaWVsZE9yZGVyUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTZXRGaWVsZE9yZGVyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNldEZpZWxkT3JkZXJQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNldEZpZWxkT3JkZXI6IEluZmVyU2VsZWN0UmVzdWx0PFNldEZpZWxkT3JkZXJQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTZXRGaWVsZE9yZGVyJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2V0RmllbGRPcmRlcicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2V0RmllbGRPcmRlcicsXG4gICAgICAgICAgJ3NldEZpZWxkT3JkZXInLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NldEZpZWxkT3JkZXJJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZnJlZXplT2JqZWN0czogPGNvbnN0IFMgZXh0ZW5kcyBGcmVlemVPYmplY3RzUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBGcmVlemVPYmplY3RzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEZyZWV6ZU9iamVjdHNQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGZyZWV6ZU9iamVjdHM6IEluZmVyU2VsZWN0UmVzdWx0PEZyZWV6ZU9iamVjdHNQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdGcmVlemVPYmplY3RzJyxcbiAgICAgICAgZmllbGROYW1lOiAnZnJlZXplT2JqZWN0cycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRnJlZXplT2JqZWN0cycsXG4gICAgICAgICAgJ2ZyZWV6ZU9iamVjdHMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0ZyZWV6ZU9iamVjdHNJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgaW5zZXJ0Tm9kZUF0UGF0aDogPGNvbnN0IFMgZXh0ZW5kcyBJbnNlcnROb2RlQXRQYXRoUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBJbnNlcnROb2RlQXRQYXRoVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEluc2VydE5vZGVBdFBhdGhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGluc2VydE5vZGVBdFBhdGg6IEluZmVyU2VsZWN0UmVzdWx0PEluc2VydE5vZGVBdFBhdGhQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdJbnNlcnROb2RlQXRQYXRoJyxcbiAgICAgICAgZmllbGROYW1lOiAnaW5zZXJ0Tm9kZUF0UGF0aCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnSW5zZXJ0Tm9kZUF0UGF0aCcsXG4gICAgICAgICAgJ2luc2VydE5vZGVBdFBhdGgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0luc2VydE5vZGVBdFBhdGhJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgcmVtb3ZlTm9kZUF0UGF0aDogPGNvbnN0IFMgZXh0ZW5kcyBSZW1vdmVOb2RlQXRQYXRoUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBSZW1vdmVOb2RlQXRQYXRoVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFJlbW92ZU5vZGVBdFBhdGhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHJlbW92ZU5vZGVBdFBhdGg6IEluZmVyU2VsZWN0UmVzdWx0PFJlbW92ZU5vZGVBdFBhdGhQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdSZW1vdmVOb2RlQXRQYXRoJyxcbiAgICAgICAgZmllbGROYW1lOiAncmVtb3ZlTm9kZUF0UGF0aCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnUmVtb3ZlTm9kZUF0UGF0aCcsXG4gICAgICAgICAgJ3JlbW92ZU5vZGVBdFBhdGgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1JlbW92ZU5vZGVBdFBhdGhJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2V0RGF0YUF0UGF0aDogPGNvbnN0IFMgZXh0ZW5kcyBTZXREYXRhQXRQYXRoUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTZXREYXRhQXRQYXRoVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNldERhdGFBdFBhdGhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNldERhdGFBdFBhdGg6IEluZmVyU2VsZWN0UmVzdWx0PFNldERhdGFBdFBhdGhQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTZXREYXRhQXRQYXRoJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2V0RGF0YUF0UGF0aCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2V0RGF0YUF0UGF0aCcsXG4gICAgICAgICAgJ3NldERhdGFBdFBhdGgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NldERhdGFBdFBhdGhJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdXBkYXRlTm9kZUF0UGF0aDogPGNvbnN0IFMgZXh0ZW5kcyBVcGRhdGVOb2RlQXRQYXRoUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBVcGRhdGVOb2RlQXRQYXRoVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFVwZGF0ZU5vZGVBdFBhdGhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHVwZGF0ZU5vZGVBdFBhdGg6IEluZmVyU2VsZWN0UmVzdWx0PFVwZGF0ZU5vZGVBdFBhdGhQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdVcGRhdGVOb2RlQXRQYXRoJyxcbiAgICAgICAgZmllbGROYW1lOiAndXBkYXRlTm9kZUF0UGF0aCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVXBkYXRlTm9kZUF0UGF0aCcsXG4gICAgICAgICAgJ3VwZGF0ZU5vZGVBdFBhdGgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1VwZGF0ZU5vZGVBdFBhdGhJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgaW5pdEVtcHR5UmVwbzogPGNvbnN0IFMgZXh0ZW5kcyBJbml0RW1wdHlSZXBvUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBJbml0RW1wdHlSZXBvVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEluaXRFbXB0eVJlcG9QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGluaXRFbXB0eVJlcG86IEluZmVyU2VsZWN0UmVzdWx0PEluaXRFbXB0eVJlcG9QYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdJbml0RW1wdHlSZXBvJyxcbiAgICAgICAgZmllbGROYW1lOiAnaW5pdEVtcHR5UmVwbycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnSW5pdEVtcHR5UmVwbycsXG4gICAgICAgICAgJ2luaXRFbXB0eVJlcG8nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0luaXRFbXB0eVJlcG9JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2V0QW5kQ29tbWl0OiA8Y29uc3QgUyBleHRlbmRzIFNldEFuZENvbW1pdFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogU2V0QW5kQ29tbWl0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNldEFuZENvbW1pdFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgc2V0QW5kQ29tbWl0OiBJbmZlclNlbGVjdFJlc3VsdDxTZXRBbmRDb21taXRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTZXRBbmRDb21taXQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdzZXRBbmRDb21taXQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1NldEFuZENvbW1pdCcsXG4gICAgICAgICAgJ3NldEFuZENvbW1pdCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnU2V0QW5kQ29tbWl0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHNldFByb3BzQW5kQ29tbWl0OiA8Y29uc3QgUyBleHRlbmRzIFNldFByb3BzQW5kQ29tbWl0UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTZXRQcm9wc0FuZENvbW1pdFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBTZXRQcm9wc0FuZENvbW1pdFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgc2V0UHJvcHNBbmRDb21taXQ6IEluZmVyU2VsZWN0UmVzdWx0PFNldFByb3BzQW5kQ29tbWl0UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnU2V0UHJvcHNBbmRDb21taXQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdzZXRQcm9wc0FuZENvbW1pdCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2V0UHJvcHNBbmRDb21taXQnLFxuICAgICAgICAgICdzZXRQcm9wc0FuZENvbW1pdCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnU2V0UHJvcHNBbmRDb21taXRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWRkQ29uc3RyYWludE5vb3BJbXBvcnQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBZGRDb25zdHJhaW50Tm9vcEltcG9ydFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFkZENvbnN0cmFpbnROb29wSW1wb3J0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFkZENvbnN0cmFpbnROb29wSW1wb3J0UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhZGRDb25zdHJhaW50Tm9vcEltcG9ydDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWRkQ29uc3RyYWludE5vb3BJbXBvcnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBZGRDb25zdHJhaW50Tm9vcEltcG9ydCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FkZENvbnN0cmFpbnROb29wSW1wb3J0JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBZGRDb25zdHJhaW50Tm9vcEltcG9ydCcsXG4gICAgICAgICAgJ2FkZENvbnN0cmFpbnROb29wSW1wb3J0JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBZGRDb25zdHJhaW50Tm9vcEltcG9ydElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhZGRJbXBvcnQ6IDxjb25zdCBTIGV4dGVuZHMgQWRkSW1wb3J0UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBBZGRJbXBvcnRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWRkSW1wb3J0UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhZGRJbXBvcnQ6IEluZmVyU2VsZWN0UmVzdWx0PEFkZEltcG9ydFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FkZEltcG9ydCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FkZEltcG9ydCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWRkSW1wb3J0JyxcbiAgICAgICAgICAnYWRkSW1wb3J0JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBZGRJbXBvcnRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWRkU2NoZW1hSW1wb3J0OiA8Y29uc3QgUyBleHRlbmRzIEFkZFNjaGVtYUltcG9ydFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWRkU2NoZW1hSW1wb3J0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFkZFNjaGVtYUltcG9ydFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWRkU2NoZW1hSW1wb3J0OiBJbmZlclNlbGVjdFJlc3VsdDxBZGRTY2hlbWFJbXBvcnRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBZGRTY2hlbWFJbXBvcnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhZGRTY2hlbWFJbXBvcnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FkZFNjaGVtYUltcG9ydCcsXG4gICAgICAgICAgJ2FkZFNjaGVtYUltcG9ydCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWRkU2NoZW1hSW1wb3J0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFkZFNjaGVtYU5vb3BJbXBvcnQ6IDxjb25zdCBTIGV4dGVuZHMgQWRkU2NoZW1hTm9vcEltcG9ydFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWRkU2NoZW1hTm9vcEltcG9ydFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBZGRTY2hlbWFOb29wSW1wb3J0UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhZGRTY2hlbWFOb29wSW1wb3J0OiBJbmZlclNlbGVjdFJlc3VsdDxBZGRTY2hlbWFOb29wSW1wb3J0UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWRkU2NoZW1hTm9vcEltcG9ydCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FkZFNjaGVtYU5vb3BJbXBvcnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FkZFNjaGVtYU5vb3BJbXBvcnQnLFxuICAgICAgICAgICdhZGRTY2hlbWFOb29wSW1wb3J0JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBZGRTY2hlbWFOb29wSW1wb3J0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFkZFRhYmxlSW1wb3J0OiA8Y29uc3QgUyBleHRlbmRzIEFkZFRhYmxlSW1wb3J0UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBBZGRUYWJsZUltcG9ydFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBZGRUYWJsZUltcG9ydFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWRkVGFibGVJbXBvcnQ6IEluZmVyU2VsZWN0UmVzdWx0PEFkZFRhYmxlSW1wb3J0UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWRkVGFibGVJbXBvcnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhZGRUYWJsZUltcG9ydCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWRkVGFibGVJbXBvcnQnLFxuICAgICAgICAgICdhZGRUYWJsZUltcG9ydCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWRkVGFibGVJbXBvcnRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWRkVGFibGVOb29wSW1wb3J0OiA8Y29uc3QgUyBleHRlbmRzIEFkZFRhYmxlTm9vcEltcG9ydFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWRkVGFibGVOb29wSW1wb3J0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFkZFRhYmxlTm9vcEltcG9ydFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWRkVGFibGVOb29wSW1wb3J0OiBJbmZlclNlbGVjdFJlc3VsdDxBZGRUYWJsZU5vb3BJbXBvcnRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBZGRUYWJsZU5vb3BJbXBvcnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhZGRUYWJsZU5vb3BJbXBvcnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FkZFRhYmxlTm9vcEltcG9ydCcsXG4gICAgICAgICAgJ2FkZFRhYmxlTm9vcEltcG9ydCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWRkVGFibGVOb29wSW1wb3J0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uRnVuY3Rpb25zOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25GdW5jdGlvbnNQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9uc1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxcbiAgICAgICAgICBTLFxuICAgICAgICAgIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uRnVuY3Rpb25zUGF5bG9hZFNlbGVjdFxuICAgICAgICA+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25GdW5jdGlvbnM6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uRnVuY3Rpb25zUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25GdW5jdGlvbnMnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9ucycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25GdW5jdGlvbnMnLFxuICAgICAgICAgICdhbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPbkZ1bmN0aW9ucycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25GdW5jdGlvbnNJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25TZXF1ZW5jZXM6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlc1BheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFxuICAgICAgICAgIFMsXG4gICAgICAgICAgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25TZXF1ZW5jZXNQYXlsb2FkU2VsZWN0XG4gICAgICAgID47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlczogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25TZXF1ZW5jZXNQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlcycsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlcycsXG4gICAgICAgICAgJ2FsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uU2VxdWVuY2VzJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblNlcXVlbmNlc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblRhYmxlczogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXNWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXNQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlckRlZmF1bHRQcml2aWxlZ2VzR3JhbnRPblRhYmxlc1BheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzJyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXMnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzJyxcbiAgICAgICAgICAnYWx0ZXJEZWZhdWx0UHJpdmlsZWdlc0dyYW50T25UYWJsZXMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyRGVmYXVsdFByaXZpbGVnZXNHcmFudE9uVGFibGVzSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlczogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlc1BheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlc1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxcbiAgICAgICAgICBTLFxuICAgICAgICAgIEFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlc1BheWxvYWRTZWxlY3RcbiAgICAgICAgPjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlczogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc1Jldm9rZU9uU2VxdWVuY2VzUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJEZWZhdWx0UHJpdmlsZWdlc1Jldm9rZU9uU2VxdWVuY2VzJyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJEZWZhdWx0UHJpdmlsZWdlc1Jldm9rZU9uU2VxdWVuY2VzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXMnLFxuICAgICAgICAgICdhbHRlckRlZmF1bHRQcml2aWxlZ2VzUmV2b2tlT25TZXF1ZW5jZXMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyRGVmYXVsdFByaXZpbGVnZXNSZXZva2VPblNlcXVlbmNlc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhbHRlclBvbGljeTogPGNvbnN0IFMgZXh0ZW5kcyBBbHRlclBvbGljeVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWx0ZXJQb2xpY3lWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWx0ZXJQb2xpY3lQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyUG9saWN5OiBJbmZlclNlbGVjdFJlc3VsdDxBbHRlclBvbGljeVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FsdGVyUG9saWN5JyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJQb2xpY3knLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyUG9saWN5JyxcbiAgICAgICAgICAnYWx0ZXJQb2xpY3knLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyUG9saWN5SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVBZGRDaGVja0NvbnN0cmFpbnQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZUFkZENoZWNrQ29uc3RyYWludFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZUFkZENoZWNrQ29uc3RyYWludCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVBZGRDaGVja0NvbnN0cmFpbnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVBZGRDaGVja0NvbnN0cmFpbnQnLFxuICAgICAgICAgICdhbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlQWRkQ2hlY2tDb25zdHJhaW50SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVBZGRDb2x1bW46IDxjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZUFkZENvbHVtblBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZUFkZENvbHVtblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlQWRkQ29sdW1uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlQWRkQ29sdW1uOiBJbmZlclNlbGVjdFJlc3VsdDxBbHRlclRhYmxlQWRkQ29sdW1uUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZUFkZENvbHVtbicsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVBZGRDb2x1bW4nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVBZGRDb2x1bW4nLFxuICAgICAgICAgICdhbHRlclRhYmxlQWRkQ29sdW1uJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlQWRkQ29sdW1uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVBZGRGb3JlaWduS2V5OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXlQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlQWRkRm9yZWlnbktleVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlQWRkRm9yZWlnbktleVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXk6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIEFsdGVyVGFibGVBZGRGb3JlaWduS2V5UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXknLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlQWRkRm9yZWlnbktleScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXknLFxuICAgICAgICAgICdhbHRlclRhYmxlQWRkRm9yZWlnbktleScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZUFkZEZvcmVpZ25LZXlJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJUYWJsZUFkZEluaGVyaXRzOiA8Y29uc3QgUyBleHRlbmRzIEFsdGVyVGFibGVBZGRJbmhlcml0c1BheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZUFkZEluaGVyaXRzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFsdGVyVGFibGVBZGRJbmhlcml0c1BheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZUFkZEluaGVyaXRzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlQWRkSW5oZXJpdHNQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlclRhYmxlQWRkSW5oZXJpdHMnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlQWRkSW5oZXJpdHMnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVBZGRJbmhlcml0cycsXG4gICAgICAgICAgJ2FsdGVyVGFibGVBZGRJbmhlcml0cycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZUFkZEluaGVyaXRzSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVBZGRQcmltYXJ5S2V5OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZUFkZFByaW1hcnlLZXlQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlQWRkUHJpbWFyeUtleVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlQWRkUHJpbWFyeUtleVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZUFkZFByaW1hcnlLZXk6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIEFsdGVyVGFibGVBZGRQcmltYXJ5S2V5UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZUFkZFByaW1hcnlLZXknLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlQWRkUHJpbWFyeUtleScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZUFkZFByaW1hcnlLZXknLFxuICAgICAgICAgICdhbHRlclRhYmxlQWRkUHJpbWFyeUtleScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZUFkZFByaW1hcnlLZXlJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJUYWJsZUFkZFVuaXF1ZUNvbnN0cmFpbnQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWx0ZXJUYWJsZUFkZFVuaXF1ZUNvbnN0cmFpbnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludCcsXG4gICAgICAgICAgJ2FsdGVyVGFibGVBZGRVbmlxdWVDb25zdHJhaW50JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlQWRkVW5pcXVlQ29uc3RyYWludElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhbHRlclRhYmxlRHJvcENvbHVtbjogPGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlRHJvcENvbHVtblBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZURyb3BDb2x1bW5WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWx0ZXJUYWJsZURyb3BDb2x1bW5QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyVGFibGVEcm9wQ29sdW1uOiBJbmZlclNlbGVjdFJlc3VsdDxBbHRlclRhYmxlRHJvcENvbHVtblBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FsdGVyVGFibGVEcm9wQ29sdW1uJyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJUYWJsZURyb3BDb2x1bW4nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVEcm9wQ29sdW1uJyxcbiAgICAgICAgICAnYWx0ZXJUYWJsZURyb3BDb2x1bW4nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyVGFibGVEcm9wQ29sdW1uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdDogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIEFsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWx0ZXJUYWJsZURyb3BDb2x1bW5EZWZhdWx0UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZURyb3BDb2x1bW5EZWZhdWx0JyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJUYWJsZURyb3BDb2x1bW5EZWZhdWx0JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHQnLFxuICAgICAgICAgICdhbHRlclRhYmxlRHJvcENvbHVtbkRlZmF1bHQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyVGFibGVEcm9wQ29sdW1uRGVmYXVsdElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGw6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGxQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGxWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWx0ZXJUYWJsZURyb3BDb2x1bW5Ob3ROdWxsUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGw6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIEFsdGVyVGFibGVEcm9wQ29sdW1uTm90TnVsbFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FsdGVyVGFibGVEcm9wQ29sdW1uTm90TnVsbCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVEcm9wQ29sdW1uTm90TnVsbCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZURyb3BDb2x1bW5Ob3ROdWxsJyxcbiAgICAgICAgICAnYWx0ZXJUYWJsZURyb3BDb2x1bW5Ob3ROdWxsJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlRHJvcENvbHVtbk5vdE51bGxJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJUYWJsZURyb3BDb25zdHJhaW50OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZURyb3BDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZURyb3BDb25zdHJhaW50VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFsdGVyVGFibGVEcm9wQ29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZURyb3BDb25zdHJhaW50OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlRHJvcENvbnN0cmFpbnRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlclRhYmxlRHJvcENvbnN0cmFpbnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlRHJvcENvbnN0cmFpbnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVEcm9wQ29uc3RyYWludCcsXG4gICAgICAgICAgJ2FsdGVyVGFibGVEcm9wQ29uc3RyYWludCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZURyb3BDb25zdHJhaW50SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVEcm9wSW5oZXJpdHM6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlRHJvcEluaGVyaXRzUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZURyb3BJbmhlcml0c1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlRHJvcEluaGVyaXRzUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlRHJvcEluaGVyaXRzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlRHJvcEluaGVyaXRzUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZURyb3BJbmhlcml0cycsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVEcm9wSW5oZXJpdHMnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVEcm9wSW5oZXJpdHMnLFxuICAgICAgICAgICdhbHRlclRhYmxlRHJvcEluaGVyaXRzJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlRHJvcEluaGVyaXRzSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVNb2RpZnlDaGVja0NvbnN0cmFpbnQ6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZU1vZGlmeUNoZWNrQ29uc3RyYWludFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50UGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZU1vZGlmeUNoZWNrQ29uc3RyYWludCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVNb2RpZnlDaGVja0NvbnN0cmFpbnQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVNb2RpZnlDaGVja0NvbnN0cmFpbnQnLFxuICAgICAgICAgICdhbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlTW9kaWZ5Q2hlY2tDb25zdHJhaW50SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVQZXJtQml0bGVuOiA8Y29uc3QgUyBleHRlbmRzIEFsdGVyVGFibGVQZXJtQml0bGVuUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlUGVybUJpdGxlblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlUGVybUJpdGxlblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZVBlcm1CaXRsZW46IEluZmVyU2VsZWN0UmVzdWx0PEFsdGVyVGFibGVQZXJtQml0bGVuUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZVBlcm1CaXRsZW4nLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlUGVybUJpdGxlbicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZVBlcm1CaXRsZW4nLFxuICAgICAgICAgICdhbHRlclRhYmxlUGVybUJpdGxlbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZVBlcm1CaXRsZW5JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFsdGVyVGFibGVQZXJtQml0bGVuRGVmYXVsdFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlUGVybUJpdGxlbkRlZmF1bHRQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlclRhYmxlUGVybUJpdGxlbkRlZmF1bHQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlUGVybUJpdGxlbkRlZmF1bHQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVQZXJtQml0bGVuRGVmYXVsdCcsXG4gICAgICAgICAgJ2FsdGVyVGFibGVQZXJtQml0bGVuRGVmYXVsdCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZVBlcm1CaXRsZW5EZWZhdWx0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVSZW5hbWVDb2x1bW46IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlUmVuYW1lQ29sdW1uUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZVJlbmFtZUNvbHVtblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlUmVuYW1lQ29sdW1uUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBhbHRlclRhYmxlUmVuYW1lQ29sdW1uOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlUmVuYW1lQ29sdW1uUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZVJlbmFtZUNvbHVtbicsXG4gICAgICAgIGZpZWxkTmFtZTogJ2FsdGVyVGFibGVSZW5hbWVDb2x1bW4nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVSZW5hbWVDb2x1bW4nLFxuICAgICAgICAgICdhbHRlclRhYmxlUmVuYW1lQ29sdW1uJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdBbHRlclRhYmxlUmVuYW1lQ29sdW1uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIEFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlU2V0Q29sdW1uRGF0YVR5cGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgQWx0ZXJUYWJsZVNldENvbHVtbkRhdGFUeXBlUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZVNldENvbHVtbkRhdGFUeXBlJyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJUYWJsZVNldENvbHVtbkRhdGFUeXBlJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdBbHRlclRhYmxlU2V0Q29sdW1uRGF0YVR5cGUnLFxuICAgICAgICAgICdhbHRlclRhYmxlU2V0Q29sdW1uRGF0YVR5cGUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyVGFibGVTZXRDb2x1bW5EYXRhVHlwZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBhbHRlclRhYmxlU2V0Q29sdW1uRGVmYXVsdDogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIEFsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQWx0ZXJUYWJsZVNldENvbHVtbkRlZmF1bHRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQWx0ZXJUYWJsZVNldENvbHVtbkRlZmF1bHRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBBbHRlclRhYmxlU2V0Q29sdW1uRGVmYXVsdFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0FsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0JyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJUYWJsZVNldENvbHVtbkRlZmF1bHQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0FsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0JyxcbiAgICAgICAgICAnYWx0ZXJUYWJsZVNldENvbHVtbkRlZmF1bHQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyVGFibGVTZXRDb2x1bW5EZWZhdWx0SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGFsdGVyVGFibGVTZXRDb2x1bW5Ob3ROdWxsOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGxQYXlsb2FkU2VsZWN0LFxuICAgID4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBBbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgYWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGw6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIEFsdGVyVGFibGVTZXRDb2x1bW5Ob3ROdWxsUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGwnLFxuICAgICAgICBmaWVsZE5hbWU6ICdhbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGwnLFxuICAgICAgICAgICdhbHRlclRhYmxlU2V0Q29sdW1uTm90TnVsbCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQWx0ZXJUYWJsZVNldENvbHVtbk5vdE51bGxJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgYWx0ZXJUYWJsZVNldFNjaGVtYTogPGNvbnN0IFMgZXh0ZW5kcyBBbHRlclRhYmxlU2V0U2NoZW1hUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBBbHRlclRhYmxlU2V0U2NoZW1hVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEFsdGVyVGFibGVTZXRTY2hlbWFQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGFsdGVyVGFibGVTZXRTY2hlbWE6IEluZmVyU2VsZWN0UmVzdWx0PEFsdGVyVGFibGVTZXRTY2hlbWFQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdBbHRlclRhYmxlU2V0U2NoZW1hJyxcbiAgICAgICAgZmllbGROYW1lOiAnYWx0ZXJUYWJsZVNldFNjaGVtYScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQWx0ZXJUYWJsZVNldFNjaGVtYScsXG4gICAgICAgICAgJ2FsdGVyVGFibGVTZXRTY2hlbWEnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0FsdGVyVGFibGVTZXRTY2hlbWFJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgY3JlYXRlQ29sdW1uOiA8Y29uc3QgUyBleHRlbmRzIENyZWF0ZUNvbHVtblBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQ3JlYXRlQ29sdW1uVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIENyZWF0ZUNvbHVtblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgY3JlYXRlQ29sdW1uOiBJbmZlclNlbGVjdFJlc3VsdDxDcmVhdGVDb2x1bW5QYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdDcmVhdGVDb2x1bW4nLFxuICAgICAgICBmaWVsZE5hbWU6ICdjcmVhdGVDb2x1bW4nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0NyZWF0ZUNvbHVtbicsXG4gICAgICAgICAgJ2NyZWF0ZUNvbHVtbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQ3JlYXRlQ29sdW1uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGNyZWF0ZUZpeHR1cmU6IDxjb25zdCBTIGV4dGVuZHMgQ3JlYXRlRml4dHVyZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogQ3JlYXRlRml4dHVyZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBDcmVhdGVGaXh0dXJlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBjcmVhdGVGaXh0dXJlOiBJbmZlclNlbGVjdFJlc3VsdDxDcmVhdGVGaXh0dXJlUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQ3JlYXRlRml4dHVyZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2NyZWF0ZUZpeHR1cmUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0NyZWF0ZUZpeHR1cmUnLFxuICAgICAgICAgICdjcmVhdGVGaXh0dXJlJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdDcmVhdGVGaXh0dXJlSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGNyZWF0ZUZ1bmN0aW9uOiA8Y29uc3QgUyBleHRlbmRzIENyZWF0ZUZ1bmN0aW9uUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBDcmVhdGVGdW5jdGlvblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBDcmVhdGVGdW5jdGlvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgY3JlYXRlRnVuY3Rpb246IEluZmVyU2VsZWN0UmVzdWx0PENyZWF0ZUZ1bmN0aW9uUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnQ3JlYXRlRnVuY3Rpb24nLFxuICAgICAgICBmaWVsZE5hbWU6ICdjcmVhdGVGdW5jdGlvbicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQ3JlYXRlRnVuY3Rpb24nLFxuICAgICAgICAgICdjcmVhdGVGdW5jdGlvbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQ3JlYXRlRnVuY3Rpb25JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgY3JlYXRlSW5kZXhVbnNhZmU6IDxjb25zdCBTIGV4dGVuZHMgQ3JlYXRlSW5kZXhVbnNhZmVQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IENyZWF0ZUluZGV4VW5zYWZlVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIENyZWF0ZUluZGV4VW5zYWZlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBjcmVhdGVJbmRleFVuc2FmZTogSW5mZXJTZWxlY3RSZXN1bHQ8Q3JlYXRlSW5kZXhVbnNhZmVQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdDcmVhdGVJbmRleFVuc2FmZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2NyZWF0ZUluZGV4VW5zYWZlJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdDcmVhdGVJbmRleFVuc2FmZScsXG4gICAgICAgICAgJ2NyZWF0ZUluZGV4VW5zYWZlJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdDcmVhdGVJbmRleFVuc2FmZUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBjcmVhdGVJbnNlcnQ6IDxjb25zdCBTIGV4dGVuZHMgQ3JlYXRlSW5zZXJ0UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBDcmVhdGVJbnNlcnRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgQ3JlYXRlSW5zZXJ0UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBjcmVhdGVJbnNlcnQ6IEluZmVyU2VsZWN0UmVzdWx0PENyZWF0ZUluc2VydFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0NyZWF0ZUluc2VydCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2NyZWF0ZUluc2VydCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQ3JlYXRlSW5zZXJ0JyxcbiAgICAgICAgICAnY3JlYXRlSW5zZXJ0JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdDcmVhdGVJbnNlcnRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgY3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgQ3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogQ3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIENyZWF0ZVRyaWdnZXJEaXN0aW5jdEZpZWxkc1BheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgY3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBDcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHNQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdDcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHMnLFxuICAgICAgICBmaWVsZE5hbWU6ICdjcmVhdGVUcmlnZ2VyRGlzdGluY3RGaWVsZHMnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0NyZWF0ZVRyaWdnZXJEaXN0aW5jdEZpZWxkcycsXG4gICAgICAgICAgJ2NyZWF0ZVRyaWdnZXJEaXN0aW5jdEZpZWxkcycsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnQ3JlYXRlVHJpZ2dlckRpc3RpbmN0RmllbGRzSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRlbm9ybWFsaXplZEZpZWxkczogPGNvbnN0IFMgZXh0ZW5kcyBEZW5vcm1hbGl6ZWRGaWVsZHNQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERlbm9ybWFsaXplZEZpZWxkc1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEZW5vcm1hbGl6ZWRGaWVsZHNQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRlbm9ybWFsaXplZEZpZWxkczogSW5mZXJTZWxlY3RSZXN1bHQ8RGVub3JtYWxpemVkRmllbGRzUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRGVub3JtYWxpemVkRmllbGRzJyxcbiAgICAgICAgZmllbGROYW1lOiAnZGVub3JtYWxpemVkRmllbGRzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEZW5vcm1hbGl6ZWRGaWVsZHMnLFxuICAgICAgICAgICdkZW5vcm1hbGl6ZWRGaWVsZHMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0Rlbm9ybWFsaXplZEZpZWxkc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkaXNhYmxlUm93TGV2ZWxTZWN1cml0eTogPFxuICAgICAgY29uc3QgUyBleHRlbmRzIERpc2FibGVSb3dMZXZlbFNlY3VyaXR5UGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogRGlzYWJsZVJvd0xldmVsU2VjdXJpdHlWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRGlzYWJsZVJvd0xldmVsU2VjdXJpdHlQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRpc2FibGVSb3dMZXZlbFNlY3VyaXR5OiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBEaXNhYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Rpc2FibGVSb3dMZXZlbFNlY3VyaXR5JyxcbiAgICAgICAgZmllbGROYW1lOiAnZGlzYWJsZVJvd0xldmVsU2VjdXJpdHknLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0Rpc2FibGVSb3dMZXZlbFNlY3VyaXR5JyxcbiAgICAgICAgICAnZGlzYWJsZVJvd0xldmVsU2VjdXJpdHknLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0Rpc2FibGVSb3dMZXZlbFNlY3VyaXR5SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRyb3BDb25zdHJhaW50OiA8Y29uc3QgUyBleHRlbmRzIERyb3BDb25zdHJhaW50UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBEcm9wQ29uc3RyYWludFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEcm9wQ29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZHJvcENvbnN0cmFpbnQ6IEluZmVyU2VsZWN0UmVzdWx0PERyb3BDb25zdHJhaW50UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRHJvcENvbnN0cmFpbnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkcm9wQ29uc3RyYWludCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRHJvcENvbnN0cmFpbnQnLFxuICAgICAgICAgICdkcm9wQ29uc3RyYWludCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRHJvcENvbnN0cmFpbnRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZHJvcEZ1bmN0aW9uOiA8Y29uc3QgUyBleHRlbmRzIERyb3BGdW5jdGlvblBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogRHJvcEZ1bmN0aW9uVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERyb3BGdW5jdGlvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZHJvcEZ1bmN0aW9uOiBJbmZlclNlbGVjdFJlc3VsdDxEcm9wRnVuY3Rpb25QYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEcm9wRnVuY3Rpb24nLFxuICAgICAgICBmaWVsZE5hbWU6ICdkcm9wRnVuY3Rpb24nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0Ryb3BGdW5jdGlvbicsXG4gICAgICAgICAgJ2Ryb3BGdW5jdGlvbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRHJvcEZ1bmN0aW9uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGRyb3BJbmRleDogPGNvbnN0IFMgZXh0ZW5kcyBEcm9wSW5kZXhQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERyb3BJbmRleFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBEcm9wSW5kZXhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGRyb3BJbmRleDogSW5mZXJTZWxlY3RSZXN1bHQ8RHJvcEluZGV4UGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnRHJvcEluZGV4JyxcbiAgICAgICAgZmllbGROYW1lOiAnZHJvcEluZGV4JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEcm9wSW5kZXgnLFxuICAgICAgICAgICdkcm9wSW5kZXgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0Ryb3BJbmRleElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkcm9wUG9saWN5OiA8Y29uc3QgUyBleHRlbmRzIERyb3BQb2xpY3lQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERyb3BQb2xpY3lWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRHJvcFBvbGljeVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZHJvcFBvbGljeTogSW5mZXJTZWxlY3RSZXN1bHQ8RHJvcFBvbGljeVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Ryb3BQb2xpY3knLFxuICAgICAgICBmaWVsZE5hbWU6ICdkcm9wUG9saWN5JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEcm9wUG9saWN5JyxcbiAgICAgICAgICAnZHJvcFBvbGljeScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRHJvcFBvbGljeUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkcm9wU2NoZW1hOiA8Y29uc3QgUyBleHRlbmRzIERyb3BTY2hlbWFQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERyb3BTY2hlbWFWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRHJvcFNjaGVtYVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZHJvcFNjaGVtYTogSW5mZXJTZWxlY3RSZXN1bHQ8RHJvcFNjaGVtYVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Ryb3BTY2hlbWEnLFxuICAgICAgICBmaWVsZE5hbWU6ICdkcm9wU2NoZW1hJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEcm9wU2NoZW1hJyxcbiAgICAgICAgICAnZHJvcFNjaGVtYScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRHJvcFNjaGVtYUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkcm9wVGFibGU6IDxjb25zdCBTIGV4dGVuZHMgRHJvcFRhYmxlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBEcm9wVGFibGVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRHJvcFRhYmxlUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkcm9wVGFibGU6IEluZmVyU2VsZWN0UmVzdWx0PERyb3BUYWJsZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Ryb3BUYWJsZScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2Ryb3BUYWJsZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRHJvcFRhYmxlJyxcbiAgICAgICAgICAnZHJvcFRhYmxlJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEcm9wVGFibGVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZHJvcFRyaWdnZXI6IDxjb25zdCBTIGV4dGVuZHMgRHJvcFRyaWdnZXJQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERyb3BUcmlnZ2VyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIERyb3BUcmlnZ2VyUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBkcm9wVHJpZ2dlcjogSW5mZXJTZWxlY3RSZXN1bHQ8RHJvcFRyaWdnZXJQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdEcm9wVHJpZ2dlcicsXG4gICAgICAgIGZpZWxkTmFtZTogJ2Ryb3BUcmlnZ2VyJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEcm9wVHJpZ2dlcicsXG4gICAgICAgICAgJ2Ryb3BUcmlnZ2VyJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdEcm9wVHJpZ2dlcklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBkcm9wVHJpZ2dlckZ1bmN0aW9uOiA8Y29uc3QgUyBleHRlbmRzIERyb3BUcmlnZ2VyRnVuY3Rpb25QYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IERyb3BUcmlnZ2VyRnVuY3Rpb25WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRHJvcFRyaWdnZXJGdW5jdGlvblBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZHJvcFRyaWdnZXJGdW5jdGlvbjogSW5mZXJTZWxlY3RSZXN1bHQ8RHJvcFRyaWdnZXJGdW5jdGlvblBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Ryb3BUcmlnZ2VyRnVuY3Rpb24nLFxuICAgICAgICBmaWVsZE5hbWU6ICdkcm9wVHJpZ2dlckZ1bmN0aW9uJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdEcm9wVHJpZ2dlckZ1bmN0aW9uJyxcbiAgICAgICAgICAnZHJvcFRyaWdnZXJGdW5jdGlvbicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRHJvcFRyaWdnZXJGdW5jdGlvbklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBlbmFibGVSb3dMZXZlbFNlY3VyaXR5OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRW5hYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEVuYWJsZVJvd0xldmVsU2VjdXJpdHlWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRW5hYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZW5hYmxlUm93TGV2ZWxTZWN1cml0eTogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRW5hYmxlUm93TGV2ZWxTZWN1cml0eVBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0VuYWJsZVJvd0xldmVsU2VjdXJpdHknLFxuICAgICAgICBmaWVsZE5hbWU6ICdlbmFibGVSb3dMZXZlbFNlY3VyaXR5JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdFbmFibGVSb3dMZXZlbFNlY3VyaXR5JyxcbiAgICAgICAgICAnZW5hYmxlUm93TGV2ZWxTZWN1cml0eScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRW5hYmxlUm93TGV2ZWxTZWN1cml0eUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBlbnN1cmVEZWZhdWx0VmFsdWVzSW5zZXJ0OiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydFBheWxvYWRTZWxlY3QsXG4gICAgPihcbiAgICAgIGFyZ3M6IEVuc3VyZURlZmF1bHRWYWx1ZXNJbnNlcnRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgZW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0Vuc3VyZURlZmF1bHRWYWx1ZXNJbnNlcnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdlbnN1cmVEZWZhdWx0VmFsdWVzSW5zZXJ0JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdFbnN1cmVEZWZhdWx0VmFsdWVzSW5zZXJ0JyxcbiAgICAgICAgICAnZW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnRW5zdXJlRGVmYXVsdFZhbHVlc0luc2VydElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBncmFudFVzYWdlT25TY2hlbWE6IDxjb25zdCBTIGV4dGVuZHMgR3JhbnRVc2FnZU9uU2NoZW1hUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBHcmFudFVzYWdlT25TY2hlbWFWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgR3JhbnRVc2FnZU9uU2NoZW1hUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBncmFudFVzYWdlT25TY2hlbWE6IEluZmVyU2VsZWN0UmVzdWx0PEdyYW50VXNhZ2VPblNjaGVtYVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0dyYW50VXNhZ2VPblNjaGVtYScsXG4gICAgICAgIGZpZWxkTmFtZTogJ2dyYW50VXNhZ2VPblNjaGVtYScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnR3JhbnRVc2FnZU9uU2NoZW1hJyxcbiAgICAgICAgICAnZ3JhbnRVc2FnZU9uU2NoZW1hJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdHcmFudFVzYWdlT25TY2hlbWFJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgaW1tdXRhYmxlRmllbGRUcmlnZ2VyOiA8Y29uc3QgUyBleHRlbmRzIEltbXV0YWJsZUZpZWxkVHJpZ2dlclBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogSW1tdXRhYmxlRmllbGRUcmlnZ2VyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEltbXV0YWJsZUZpZWxkVHJpZ2dlclBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgaW1tdXRhYmxlRmllbGRUcmlnZ2VyOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBJbW11dGFibGVGaWVsZFRyaWdnZXJQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdJbW11dGFibGVGaWVsZFRyaWdnZXInLFxuICAgICAgICBmaWVsZE5hbWU6ICdpbW11dGFibGVGaWVsZFRyaWdnZXInLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0ltbXV0YWJsZUZpZWxkVHJpZ2dlcicsXG4gICAgICAgICAgJ2ltbXV0YWJsZUZpZWxkVHJpZ2dlcicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnSW1tdXRhYmxlRmllbGRUcmlnZ2VySW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGluZmxlY3Rpb25GaWVsZFRyaWdnZXI6IDxcbiAgICAgIGNvbnN0IFMgZXh0ZW5kcyBJbmZsZWN0aW9uRmllbGRUcmlnZ2VyUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogSW5mbGVjdGlvbkZpZWxkVHJpZ2dlclZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBJbmZsZWN0aW9uRmllbGRUcmlnZ2VyUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBpbmZsZWN0aW9uRmllbGRUcmlnZ2VyOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBJbmZsZWN0aW9uRmllbGRUcmlnZ2VyUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnSW5mbGVjdGlvbkZpZWxkVHJpZ2dlcicsXG4gICAgICAgIGZpZWxkTmFtZTogJ2luZmxlY3Rpb25GaWVsZFRyaWdnZXInLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ0luZmxlY3Rpb25GaWVsZFRyaWdnZXInLFxuICAgICAgICAgICdpbmZsZWN0aW9uRmllbGRUcmlnZ2VyJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdJbmZsZWN0aW9uRmllbGRUcmlnZ2VySW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIGluc2VydEFjdGlvbjogPGNvbnN0IFMgZXh0ZW5kcyBJbnNlcnRBY3Rpb25QYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IEluc2VydEFjdGlvblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBJbnNlcnRBY3Rpb25QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGluc2VydEFjdGlvbjogSW5mZXJTZWxlY3RSZXN1bHQ8SW5zZXJ0QWN0aW9uUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnSW5zZXJ0QWN0aW9uJyxcbiAgICAgICAgZmllbGROYW1lOiAnaW5zZXJ0QWN0aW9uJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdJbnNlcnRBY3Rpb24nLFxuICAgICAgICAgICdpbnNlcnRBY3Rpb24nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0luc2VydEFjdGlvbklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBtb2RpZnlDaGVja0NvbnN0cmFpbnQ6IDxjb25zdCBTIGV4dGVuZHMgTW9kaWZ5Q2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBNb2RpZnlDaGVja0NvbnN0cmFpbnRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgTW9kaWZ5Q2hlY2tDb25zdHJhaW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBtb2RpZnlDaGVja0NvbnN0cmFpbnQ6IEluZmVyU2VsZWN0UmVzdWx0PFxuICAgICAgICAgIE1vZGlmeUNoZWNrQ29uc3RyYWludFBheWxvYWQsXG4gICAgICAgICAgU1xuICAgICAgICA+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ01vZGlmeUNoZWNrQ29uc3RyYWludCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ21vZGlmeUNoZWNrQ29uc3RyYWludCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnTW9kaWZ5Q2hlY2tDb25zdHJhaW50JyxcbiAgICAgICAgICAnbW9kaWZ5Q2hlY2tDb25zdHJhaW50JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdNb2RpZnlDaGVja0NvbnN0cmFpbnRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgb3duZWRGaWVsZHNUcmlnZ2VyOiA8Y29uc3QgUyBleHRlbmRzIE93bmVkRmllbGRzVHJpZ2dlclBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogT3duZWRGaWVsZHNUcmlnZ2VyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIE93bmVkRmllbGRzVHJpZ2dlclBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgb3duZWRGaWVsZHNUcmlnZ2VyOiBJbmZlclNlbGVjdFJlc3VsdDxPd25lZEZpZWxkc1RyaWdnZXJQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdPd25lZEZpZWxkc1RyaWdnZXInLFxuICAgICAgICBmaWVsZE5hbWU6ICdvd25lZEZpZWxkc1RyaWdnZXInLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ093bmVkRmllbGRzVHJpZ2dlcicsXG4gICAgICAgICAgJ293bmVkRmllbGRzVHJpZ2dlcicsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnT3duZWRGaWVsZHNUcmlnZ2VySW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHBlb3BsZXN0YW1wczogPGNvbnN0IFMgZXh0ZW5kcyBQZW9wbGVzdGFtcHNQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFBlb3BsZXN0YW1wc1ZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBQZW9wbGVzdGFtcHNQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHBlb3BsZXN0YW1wczogSW5mZXJTZWxlY3RSZXN1bHQ8UGVvcGxlc3RhbXBzUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnUGVvcGxlc3RhbXBzJyxcbiAgICAgICAgZmllbGROYW1lOiAncGVvcGxlc3RhbXBzJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdQZW9wbGVzdGFtcHMnLFxuICAgICAgICAgICdwZW9wbGVzdGFtcHMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1Blb3BsZXN0YW1wc0lucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICByZW5hbWVDb25zdHJhaW50OiA8Y29uc3QgUyBleHRlbmRzIFJlbmFtZUNvbnN0cmFpbnRQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFJlbmFtZUNvbnN0cmFpbnRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgUmVuYW1lQ29uc3RyYWludFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgcmVuYW1lQ29uc3RyYWludDogSW5mZXJTZWxlY3RSZXN1bHQ8UmVuYW1lQ29uc3RyYWludFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1JlbmFtZUNvbnN0cmFpbnQnLFxuICAgICAgICBmaWVsZE5hbWU6ICdyZW5hbWVDb25zdHJhaW50JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdSZW5hbWVDb25zdHJhaW50JyxcbiAgICAgICAgICAncmVuYW1lQ29uc3RyYWludCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnUmVuYW1lQ29uc3RyYWludElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICByZW5hbWVJbmRleDogPGNvbnN0IFMgZXh0ZW5kcyBSZW5hbWVJbmRleFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogUmVuYW1lSW5kZXhWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgUmVuYW1lSW5kZXhQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHJlbmFtZUluZGV4OiBJbmZlclNlbGVjdFJlc3VsdDxSZW5hbWVJbmRleFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1JlbmFtZUluZGV4JyxcbiAgICAgICAgZmllbGROYW1lOiAncmVuYW1lSW5kZXgnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1JlbmFtZUluZGV4JyxcbiAgICAgICAgICAncmVuYW1lSW5kZXgnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1JlbmFtZUluZGV4SW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHJlbmFtZVNjaGVtYTogPGNvbnN0IFMgZXh0ZW5kcyBSZW5hbWVTY2hlbWFQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFJlbmFtZVNjaGVtYVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBSZW5hbWVTY2hlbWFQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHJlbmFtZVNjaGVtYTogSW5mZXJTZWxlY3RSZXN1bHQ8UmVuYW1lU2NoZW1hUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnUmVuYW1lU2NoZW1hJyxcbiAgICAgICAgZmllbGROYW1lOiAncmVuYW1lU2NoZW1hJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdSZW5hbWVTY2hlbWEnLFxuICAgICAgICAgICdyZW5hbWVTY2hlbWEnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1JlbmFtZVNjaGVtYUlucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICByZW5hbWVUYWJsZTogPGNvbnN0IFMgZXh0ZW5kcyBSZW5hbWVUYWJsZVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogUmVuYW1lVGFibGVWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgUmVuYW1lVGFibGVQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHJlbmFtZVRhYmxlOiBJbmZlclNlbGVjdFJlc3VsdDxSZW5hbWVUYWJsZVBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1JlbmFtZVRhYmxlJyxcbiAgICAgICAgZmllbGROYW1lOiAncmVuYW1lVGFibGUnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1JlbmFtZVRhYmxlJyxcbiAgICAgICAgICAncmVuYW1lVGFibGUnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1JlbmFtZVRhYmxlSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHJldm9rZVVzYWdlT25TY2hlbWE6IDxjb25zdCBTIGV4dGVuZHMgUmV2b2tlVXNhZ2VPblNjaGVtYVBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogUmV2b2tlVXNhZ2VPblNjaGVtYVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBSZXZva2VVc2FnZU9uU2NoZW1hUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICByZXZva2VVc2FnZU9uU2NoZW1hOiBJbmZlclNlbGVjdFJlc3VsdDxSZXZva2VVc2FnZU9uU2NoZW1hUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnUmV2b2tlVXNhZ2VPblNjaGVtYScsXG4gICAgICAgIGZpZWxkTmFtZTogJ3Jldm9rZVVzYWdlT25TY2hlbWEnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1Jldm9rZVVzYWdlT25TY2hlbWEnLFxuICAgICAgICAgICdyZXZva2VVc2FnZU9uU2NoZW1hJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdSZXZva2VVc2FnZU9uU2NoZW1hSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHNldENvbW1lbnRPbkNvbHVtbjogPGNvbnN0IFMgZXh0ZW5kcyBTZXRDb21tZW50T25Db2x1bW5QYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFNldENvbW1lbnRPbkNvbHVtblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBTZXRDb21tZW50T25Db2x1bW5QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNldENvbW1lbnRPbkNvbHVtbjogSW5mZXJTZWxlY3RSZXN1bHQ8U2V0Q29tbWVudE9uQ29sdW1uUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnU2V0Q29tbWVudE9uQ29sdW1uJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2V0Q29tbWVudE9uQ29sdW1uJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdTZXRDb21tZW50T25Db2x1bW4nLFxuICAgICAgICAgICdzZXRDb21tZW50T25Db2x1bW4nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NldENvbW1lbnRPbkNvbHVtbklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBzZXRDb21tZW50T25GdW5jdGlvbjogPGNvbnN0IFMgZXh0ZW5kcyBTZXRDb21tZW50T25GdW5jdGlvblBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogU2V0Q29tbWVudE9uRnVuY3Rpb25WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgU2V0Q29tbWVudE9uRnVuY3Rpb25QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNldENvbW1lbnRPbkZ1bmN0aW9uOiBJbmZlclNlbGVjdFJlc3VsdDxTZXRDb21tZW50T25GdW5jdGlvblBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1NldENvbW1lbnRPbkZ1bmN0aW9uJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2V0Q29tbWVudE9uRnVuY3Rpb24nLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1NldENvbW1lbnRPbkZ1bmN0aW9uJyxcbiAgICAgICAgICAnc2V0Q29tbWVudE9uRnVuY3Rpb24nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NldENvbW1lbnRPbkZ1bmN0aW9uSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHNldENvbW1lbnRPblRhYmxlOiA8Y29uc3QgUyBleHRlbmRzIFNldENvbW1lbnRPblRhYmxlUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTZXRDb21tZW50T25UYWJsZVZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBTZXRDb21tZW50T25UYWJsZVBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgc2V0Q29tbWVudE9uVGFibGU6IEluZmVyU2VsZWN0UmVzdWx0PFNldENvbW1lbnRPblRhYmxlUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnU2V0Q29tbWVudE9uVGFibGUnLFxuICAgICAgICBmaWVsZE5hbWU6ICdzZXRDb21tZW50T25UYWJsZScsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2V0Q29tbWVudE9uVGFibGUnLFxuICAgICAgICAgICdzZXRDb21tZW50T25UYWJsZScsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnU2V0Q29tbWVudE9uVGFibGVJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2x1Z0ZpZWxkVHJpZ2dlcjogPGNvbnN0IFMgZXh0ZW5kcyBTbHVnRmllbGRUcmlnZ2VyUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTbHVnRmllbGRUcmlnZ2VyVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNsdWdGaWVsZFRyaWdnZXJQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNsdWdGaWVsZFRyaWdnZXI6IEluZmVyU2VsZWN0UmVzdWx0PFNsdWdGaWVsZFRyaWdnZXJQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTbHVnRmllbGRUcmlnZ2VyJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2x1Z0ZpZWxkVHJpZ2dlcicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2x1Z0ZpZWxkVHJpZ2dlcicsXG4gICAgICAgICAgJ3NsdWdGaWVsZFRyaWdnZXInLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NsdWdGaWVsZFRyaWdnZXJJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdGltZXN0YW1wczogPGNvbnN0IFMgZXh0ZW5kcyBUaW1lc3RhbXBzUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBUaW1lc3RhbXBzVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFRpbWVzdGFtcHNQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHRpbWVzdGFtcHM6IEluZmVyU2VsZWN0UmVzdWx0PFRpbWVzdGFtcHNQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdUaW1lc3RhbXBzJyxcbiAgICAgICAgZmllbGROYW1lOiAndGltZXN0YW1wcycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVGltZXN0YW1wcycsXG4gICAgICAgICAgJ3RpbWVzdGFtcHMnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1RpbWVzdGFtcHNJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgY2hlY2tQYXNzd29yZDogPGNvbnN0IFMgZXh0ZW5kcyBDaGVja1Bhc3N3b3JkUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBDaGVja1Bhc3N3b3JkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIENoZWNrUGFzc3dvcmRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIGNoZWNrUGFzc3dvcmQ6IEluZmVyU2VsZWN0UmVzdWx0PENoZWNrUGFzc3dvcmRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdDaGVja1Bhc3N3b3JkJyxcbiAgICAgICAgZmllbGROYW1lOiAnY2hlY2tQYXNzd29yZCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnQ2hlY2tQYXNzd29yZCcsXG4gICAgICAgICAgJ2NoZWNrUGFzc3dvcmQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ0NoZWNrUGFzc3dvcmRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgY29uZmlybURlbGV0ZUFjY291bnQ6IDxjb25zdCBTIGV4dGVuZHMgQ29uZmlybURlbGV0ZUFjY291bnRQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IENvbmZpcm1EZWxldGVBY2NvdW50VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIENvbmZpcm1EZWxldGVBY2NvdW50UGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBjb25maXJtRGVsZXRlQWNjb3VudDogSW5mZXJTZWxlY3RSZXN1bHQ8Q29uZmlybURlbGV0ZUFjY291bnRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdDb25maXJtRGVsZXRlQWNjb3VudCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2NvbmZpcm1EZWxldGVBY2NvdW50JyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdDb25maXJtRGVsZXRlQWNjb3VudCcsXG4gICAgICAgICAgJ2NvbmZpcm1EZWxldGVBY2NvdW50JyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdDb25maXJtRGVsZXRlQWNjb3VudElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBleHRlbmRUb2tlbkV4cGlyZXM6IDxjb25zdCBTIGV4dGVuZHMgRXh0ZW5kVG9rZW5FeHBpcmVzUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBFeHRlbmRUb2tlbkV4cGlyZXNWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgRXh0ZW5kVG9rZW5FeHBpcmVzUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBleHRlbmRUb2tlbkV4cGlyZXM6IEluZmVyU2VsZWN0UmVzdWx0PEV4dGVuZFRva2VuRXhwaXJlc1BheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ0V4dGVuZFRva2VuRXhwaXJlcycsXG4gICAgICAgIGZpZWxkTmFtZTogJ2V4dGVuZFRva2VuRXhwaXJlcycsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnRXh0ZW5kVG9rZW5FeHBpcmVzJyxcbiAgICAgICAgICAnZXh0ZW5kVG9rZW5FeHBpcmVzJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdFeHRlbmRUb2tlbkV4cGlyZXNJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgZm9yZ290UGFzc3dvcmQ6IDxjb25zdCBTIGV4dGVuZHMgRm9yZ290UGFzc3dvcmRQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IEZvcmdvdFBhc3N3b3JkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIEZvcmdvdFBhc3N3b3JkUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBmb3Jnb3RQYXNzd29yZDogSW5mZXJTZWxlY3RSZXN1bHQ8Rm9yZ290UGFzc3dvcmRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdGb3Jnb3RQYXNzd29yZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ2ZvcmdvdFBhc3N3b3JkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdGb3Jnb3RQYXNzd29yZCcsXG4gICAgICAgICAgJ2ZvcmdvdFBhc3N3b3JkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdGb3Jnb3RQYXNzd29yZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBvbmVUaW1lVG9rZW46IDxjb25zdCBTIGV4dGVuZHMgT25lVGltZVRva2VuUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBPbmVUaW1lVG9rZW5WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgT25lVGltZVRva2VuUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBvbmVUaW1lVG9rZW46IEluZmVyU2VsZWN0UmVzdWx0PE9uZVRpbWVUb2tlblBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ09uZVRpbWVUb2tlbicsXG4gICAgICAgIGZpZWxkTmFtZTogJ29uZVRpbWVUb2tlbicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnT25lVGltZVRva2VuJyxcbiAgICAgICAgICAnb25lVGltZVRva2VuJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdPbmVUaW1lVG9rZW5JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgcmVzZXRQYXNzd29yZDogPGNvbnN0IFMgZXh0ZW5kcyBSZXNldFBhc3N3b3JkUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBSZXNldFBhc3N3b3JkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFJlc2V0UGFzc3dvcmRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHJlc2V0UGFzc3dvcmQ6IEluZmVyU2VsZWN0UmVzdWx0PFJlc2V0UGFzc3dvcmRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdSZXNldFBhc3N3b3JkJyxcbiAgICAgICAgZmllbGROYW1lOiAncmVzZXRQYXNzd29yZCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnUmVzZXRQYXNzd29yZCcsXG4gICAgICAgICAgJ3Jlc2V0UGFzc3dvcmQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1Jlc2V0UGFzc3dvcmRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2VuZEFjY291bnREZWxldGlvbkVtYWlsOiA8XG4gICAgICBjb25zdCBTIGV4dGVuZHMgU2VuZEFjY291bnREZWxldGlvbkVtYWlsUGF5bG9hZFNlbGVjdCxcbiAgICA+KFxuICAgICAgYXJnczogU2VuZEFjY291bnREZWxldGlvbkVtYWlsVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNlbmRBY2NvdW50RGVsZXRpb25FbWFpbFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgc2VuZEFjY291bnREZWxldGlvbkVtYWlsOiBJbmZlclNlbGVjdFJlc3VsdDxcbiAgICAgICAgICBTZW5kQWNjb3VudERlbGV0aW9uRW1haWxQYXlsb2FkLFxuICAgICAgICAgIFNcbiAgICAgICAgPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTZW5kQWNjb3VudERlbGV0aW9uRW1haWwnLFxuICAgICAgICBmaWVsZE5hbWU6ICdzZW5kQWNjb3VudERlbGV0aW9uRW1haWwnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1NlbmRBY2NvdW50RGVsZXRpb25FbWFpbCcsXG4gICAgICAgICAgJ3NlbmRBY2NvdW50RGVsZXRpb25FbWFpbCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnU2VuZEFjY291bnREZWxldGlvbkVtYWlsSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHNlbmRWZXJpZmljYXRpb25FbWFpbDogPGNvbnN0IFMgZXh0ZW5kcyBTZW5kVmVyaWZpY2F0aW9uRW1haWxQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFNlbmRWZXJpZmljYXRpb25FbWFpbFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBTZW5kVmVyaWZpY2F0aW9uRW1haWxQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNlbmRWZXJpZmljYXRpb25FbWFpbDogSW5mZXJTZWxlY3RSZXN1bHQ8XG4gICAgICAgICAgU2VuZFZlcmlmaWNhdGlvbkVtYWlsUGF5bG9hZCxcbiAgICAgICAgICBTXG4gICAgICAgID47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnU2VuZFZlcmlmaWNhdGlvbkVtYWlsJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2VuZFZlcmlmaWNhdGlvbkVtYWlsJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdTZW5kVmVyaWZpY2F0aW9uRW1haWwnLFxuICAgICAgICAgICdzZW5kVmVyaWZpY2F0aW9uRW1haWwnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NlbmRWZXJpZmljYXRpb25FbWFpbElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBzZXRQYXNzd29yZDogPGNvbnN0IFMgZXh0ZW5kcyBTZXRQYXNzd29yZFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogU2V0UGFzc3dvcmRWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgU2V0UGFzc3dvcmRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNldFBhc3N3b3JkOiBJbmZlclNlbGVjdFJlc3VsdDxTZXRQYXNzd29yZFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1NldFBhc3N3b3JkJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2V0UGFzc3dvcmQnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1NldFBhc3N3b3JkJyxcbiAgICAgICAgICAnc2V0UGFzc3dvcmQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NldFBhc3N3b3JkSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHNpZ25JbjogPGNvbnN0IFMgZXh0ZW5kcyBTaWduSW5QYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFNpZ25JblZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBTaWduSW5QYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNpZ25JbjogSW5mZXJTZWxlY3RSZXN1bHQ8U2lnbkluUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnU2lnbkluJyxcbiAgICAgICAgZmllbGROYW1lOiAnc2lnbkluJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdTaWduSW4nLFxuICAgICAgICAgICdzaWduSW4nLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NpZ25JbklucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICBzaWduSW5PbmVUaW1lVG9rZW46IDxjb25zdCBTIGV4dGVuZHMgU2lnbkluT25lVGltZVRva2VuUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTaWduSW5PbmVUaW1lVG9rZW5WYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgU2lnbkluT25lVGltZVRva2VuUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICBzaWduSW5PbmVUaW1lVG9rZW46IEluZmVyU2VsZWN0UmVzdWx0PFNpZ25Jbk9uZVRpbWVUb2tlblBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1NpZ25Jbk9uZVRpbWVUb2tlbicsXG4gICAgICAgIGZpZWxkTmFtZTogJ3NpZ25Jbk9uZVRpbWVUb2tlbicsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2lnbkluT25lVGltZVRva2VuJyxcbiAgICAgICAgICAnc2lnbkluT25lVGltZVRva2VuJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdTaWduSW5PbmVUaW1lVG9rZW5JbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2lnbk91dDogPGNvbnN0IFMgZXh0ZW5kcyBTaWduT3V0UGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBTaWduT3V0VmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNpZ25PdXRQYXlsb2FkU2VsZWN0PjtcbiAgICAgIH0sXG4gICAgKSA9PlxuICAgICAgbmV3IFF1ZXJ5QnVpbGRlcjx7XG4gICAgICAgIHNpZ25PdXQ6IEluZmVyU2VsZWN0UmVzdWx0PFNpZ25PdXRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTaWduT3V0JyxcbiAgICAgICAgZmllbGROYW1lOiAnc2lnbk91dCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnU2lnbk91dCcsXG4gICAgICAgICAgJ3NpZ25PdXQnLFxuICAgICAgICAgIG9wdGlvbnM/LnNlbGVjdCxcbiAgICAgICAgICBhcmdzLFxuICAgICAgICAgIFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2lucHV0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ1NpZ25PdXRJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgc2lnblVwOiA8Y29uc3QgUyBleHRlbmRzIFNpZ25VcFBheWxvYWRTZWxlY3Q+KFxuICAgICAgYXJnczogU2lnblVwVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFNpZ25VcFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgc2lnblVwOiBJbmZlclNlbGVjdFJlc3VsdDxTaWduVXBQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdTaWduVXAnLFxuICAgICAgICBmaWVsZE5hbWU6ICdzaWduVXAnLFxuICAgICAgICAuLi5idWlsZEN1c3RvbURvY3VtZW50KFxuICAgICAgICAgICdtdXRhdGlvbicsXG4gICAgICAgICAgJ1NpZ25VcCcsXG4gICAgICAgICAgJ3NpZ25VcCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnU2lnblVwSW5wdXQhJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKSxcbiAgICAgIH0pLFxuICAgIHZlcmlmeUVtYWlsOiA8Y29uc3QgUyBleHRlbmRzIFZlcmlmeUVtYWlsUGF5bG9hZFNlbGVjdD4oXG4gICAgICBhcmdzOiBWZXJpZnlFbWFpbFZhcmlhYmxlcyxcbiAgICAgIG9wdGlvbnM/OiB7XG4gICAgICAgIHNlbGVjdD86IERlZXBFeGFjdDxTLCBWZXJpZnlFbWFpbFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdmVyaWZ5RW1haWw6IEluZmVyU2VsZWN0UmVzdWx0PFZlcmlmeUVtYWlsUGF5bG9hZCwgUz47XG4gICAgICB9Pih7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgb3BlcmF0aW9uOiAnbXV0YXRpb24nLFxuICAgICAgICBvcGVyYXRpb25OYW1lOiAnVmVyaWZ5RW1haWwnLFxuICAgICAgICBmaWVsZE5hbWU6ICd2ZXJpZnlFbWFpbCcsXG4gICAgICAgIC4uLmJ1aWxkQ3VzdG9tRG9jdW1lbnQoXG4gICAgICAgICAgJ211dGF0aW9uJyxcbiAgICAgICAgICAnVmVyaWZ5RW1haWwnLFxuICAgICAgICAgICd2ZXJpZnlFbWFpbCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVmVyaWZ5RW1haWxJbnB1dCEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLFxuICAgICAgfSksXG4gICAgdmVyaWZ5UGFzc3dvcmQ6IDxjb25zdCBTIGV4dGVuZHMgVmVyaWZ5UGFzc3dvcmRQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFZlcmlmeVBhc3N3b3JkVmFyaWFibGVzLFxuICAgICAgb3B0aW9ucz86IHtcbiAgICAgICAgc2VsZWN0PzogRGVlcEV4YWN0PFMsIFZlcmlmeVBhc3N3b3JkUGF5bG9hZFNlbGVjdD47XG4gICAgICB9LFxuICAgICkgPT5cbiAgICAgIG5ldyBRdWVyeUJ1aWxkZXI8e1xuICAgICAgICB2ZXJpZnlQYXNzd29yZDogSW5mZXJTZWxlY3RSZXN1bHQ8VmVyaWZ5UGFzc3dvcmRQYXlsb2FkLCBTPjtcbiAgICAgIH0+KHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBvcGVyYXRpb246ICdtdXRhdGlvbicsXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6ICdWZXJpZnlQYXNzd29yZCcsXG4gICAgICAgIGZpZWxkTmFtZTogJ3ZlcmlmeVBhc3N3b3JkJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdWZXJpZnlQYXNzd29yZCcsXG4gICAgICAgICAgJ3ZlcmlmeVBhc3N3b3JkJyxcbiAgICAgICAgICBvcHRpb25zPy5zZWxlY3QsXG4gICAgICAgICAgYXJncyxcbiAgICAgICAgICBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG5hbWU6ICdpbnB1dCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdWZXJpZnlQYXNzd29yZElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgICB2ZXJpZnlUb3RwOiA8Y29uc3QgUyBleHRlbmRzIFZlcmlmeVRvdHBQYXlsb2FkU2VsZWN0PihcbiAgICAgIGFyZ3M6IFZlcmlmeVRvdHBWYXJpYWJsZXMsXG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBzZWxlY3Q/OiBEZWVwRXhhY3Q8UywgVmVyaWZ5VG90cFBheWxvYWRTZWxlY3Q+O1xuICAgICAgfSxcbiAgICApID0+XG4gICAgICBuZXcgUXVlcnlCdWlsZGVyPHtcbiAgICAgICAgdmVyaWZ5VG90cDogSW5mZXJTZWxlY3RSZXN1bHQ8VmVyaWZ5VG90cFBheWxvYWQsIFM+O1xuICAgICAgfT4oe1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIG9wZXJhdGlvbjogJ211dGF0aW9uJyxcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogJ1ZlcmlmeVRvdHAnLFxuICAgICAgICBmaWVsZE5hbWU6ICd2ZXJpZnlUb3RwJyxcbiAgICAgICAgLi4uYnVpbGRDdXN0b21Eb2N1bWVudChcbiAgICAgICAgICAnbXV0YXRpb24nLFxuICAgICAgICAgICdWZXJpZnlUb3RwJyxcbiAgICAgICAgICAndmVyaWZ5VG90cCcsXG4gICAgICAgICAgb3B0aW9ucz8uc2VsZWN0LFxuICAgICAgICAgIGFyZ3MsXG4gICAgICAgICAgW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBuYW1lOiAnaW5wdXQnLFxuICAgICAgICAgICAgICB0eXBlOiAnVmVyaWZ5VG90cElucHV0IScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICksXG4gICAgICB9KSxcbiAgfTtcbn1cbiJdfQ==