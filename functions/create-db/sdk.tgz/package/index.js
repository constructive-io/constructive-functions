"use strict";
/**
 * @constructive-db/constructive-sdk
 *
 * Auto-generated GraphQL types and ORM client for Constructive applications.
 *
 * This package uses @constructive-io/graphql-codegen to generate:
 * - TypeScript types for all GraphQL entities
 * - ORM client with Prisma-like API
 * - Standalone fetch functions for queries
 * - React Query hooks (optional, disabled by default)
 *
 * To generate the SDK, run:
 *   pnpm run generate
 *
 * To generate with React Query hooks:
 *   1. Set reactQuery.enabled = true in graphql-sdk.config.ts
 *   2. Run: pnpm run generate:hooks
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SDK_NAME = exports.SDK_VERSION = exports.TableCategory = exports.FieldCategory = void 0;
// Re-export generated code
__exportStar(require("./generated"), exports);
// input-types exports some types that are also in generated/index.ts, so we exclude duplicates
var input_types_1 = require("./generated/input-types");
// Enum types
Object.defineProperty(exports, "FieldCategory", { enumerable: true, get: function () { return input_types_1.FieldCategory; } });
Object.defineProperty(exports, "TableCategory", { enumerable: true, get: function () { return input_types_1.TableCategory; } });
// SDK metadata
exports.SDK_VERSION = '0.0.1';
exports.SDK_NAME = '@constructive-db/constructive-sdk';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7OztHQWlCRzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFSCwyQkFBMkI7QUFDM0IsOENBQTRCO0FBQzVCLCtGQUErRjtBQUMvRix1REFLaUM7QUFKL0IsYUFBYTtBQUNiLDRHQUFBLGFBQWEsT0FBQTtBQUNiLDRHQUFBLGFBQWEsT0FBQTtBQUlmLGVBQWU7QUFDRixRQUFBLFdBQVcsR0FBRyxPQUFPLENBQUM7QUFDdEIsUUFBQSxRQUFRLEdBQUcsbUNBQW1DLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBjb25zdHJ1Y3RpdmUtZGIvY29uc3RydWN0aXZlLXNka1xuICpcbiAqIEF1dG8tZ2VuZXJhdGVkIEdyYXBoUUwgdHlwZXMgYW5kIE9STSBjbGllbnQgZm9yIENvbnN0cnVjdGl2ZSBhcHBsaWNhdGlvbnMuXG4gKlxuICogVGhpcyBwYWNrYWdlIHVzZXMgQGNvbnN0cnVjdGl2ZS1pby9ncmFwaHFsLWNvZGVnZW4gdG8gZ2VuZXJhdGU6XG4gKiAtIFR5cGVTY3JpcHQgdHlwZXMgZm9yIGFsbCBHcmFwaFFMIGVudGl0aWVzXG4gKiAtIE9STSBjbGllbnQgd2l0aCBQcmlzbWEtbGlrZSBBUElcbiAqIC0gU3RhbmRhbG9uZSBmZXRjaCBmdW5jdGlvbnMgZm9yIHF1ZXJpZXNcbiAqIC0gUmVhY3QgUXVlcnkgaG9va3MgKG9wdGlvbmFsLCBkaXNhYmxlZCBieSBkZWZhdWx0KVxuICpcbiAqIFRvIGdlbmVyYXRlIHRoZSBTREssIHJ1bjpcbiAqICAgcG5wbSBydW4gZ2VuZXJhdGVcbiAqXG4gKiBUbyBnZW5lcmF0ZSB3aXRoIFJlYWN0IFF1ZXJ5IGhvb2tzOlxuICogICAxLiBTZXQgcmVhY3RRdWVyeS5lbmFibGVkID0gdHJ1ZSBpbiBncmFwaHFsLXNkay5jb25maWcudHNcbiAqICAgMi4gUnVuOiBwbnBtIHJ1biBnZW5lcmF0ZTpob29rc1xuICovXG5cbi8vIFJlLWV4cG9ydCBnZW5lcmF0ZWQgY29kZVxuZXhwb3J0ICogZnJvbSAnLi9nZW5lcmF0ZWQnO1xuLy8gaW5wdXQtdHlwZXMgZXhwb3J0cyBzb21lIHR5cGVzIHRoYXQgYXJlIGFsc28gaW4gZ2VuZXJhdGVkL2luZGV4LnRzLCBzbyB3ZSBleGNsdWRlIGR1cGxpY2F0ZXNcbmV4cG9ydCB7XG4gIC8vIEVudW0gdHlwZXNcbiAgRmllbGRDYXRlZ29yeSxcbiAgVGFibGVDYXRlZ29yeSxcbiAgLy8gSW5wdXQgdHlwZXMgKGV4Y2x1ZGluZyBDb25uZWN0aW9uUmVzdWx0IGFuZCBQYWdlSW5mbyB3aGljaCBhcmUgaW4gZ2VuZXJhdGVkL2luZGV4LnRzKVxufSBmcm9tICcuL2dlbmVyYXRlZC9pbnB1dC10eXBlcyc7XG5cbi8vIFNESyBtZXRhZGF0YVxuZXhwb3J0IGNvbnN0IFNES19WRVJTSU9OID0gJzAuMC4xJztcbmV4cG9ydCBjb25zdCBTREtfTkFNRSA9ICdAY29uc3RydWN0aXZlLWRiL2NvbnN0cnVjdGl2ZS1zZGsnO1xuIl19