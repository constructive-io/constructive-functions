/**
 * @constructive-db/constructive-sdk
 *
 * Auto-generated GraphQL types and ORM client for Constructive applications.
 *
 * This package uses @constructive-io/graphql-codegen to generate:
 * - TypeScript types for all GraphQL entities
 * - ORM client with Prisma-like API
 * - Standalone fetch functions for queries
 * - React Query hooks (optional, disabled by default)
 *
 * To generate the SDK, run:
 *   pnpm run generate
 *
 * To generate with React Query hooks:
 *   1. Set reactQuery.enabled = true in graphql-sdk.config.ts
 *   2. Run: pnpm run generate:hooks
 */
export * from './generated';
export { FieldCategory, TableCategory, } from './generated/input-types';
export declare const SDK_VERSION = "0.0.1";
export declare const SDK_NAME = "@constructive-db/constructive-sdk";
