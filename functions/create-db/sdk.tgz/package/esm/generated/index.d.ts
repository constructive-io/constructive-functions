import type { OrmClientConfig } from './client';
import { CheckConstraintModel } from './models/checkConstraint';
import { UserModel } from './models/user';
import { DatabaseModel } from './models/database';
import { EmailModel } from './models/email';
import { PhoneNumberModel } from './models/phoneNumber';
import { CryptoAddressModel } from './models/cryptoAddress';
import { ConnectedAccountModel } from './models/connectedAccount';
import { AuditLogModel } from './models/auditLog';
import { SchemaModel } from './models/schema';
import { TableModel } from './models/table';
import { FieldModel } from './models/field';
import { DenormalizedTableFieldModel } from './models/denormalizedTableField';
import { FieldModuleModel } from './models/fieldModule';
import { MembershipsModuleModel } from './models/membershipsModule';
import { ForeignKeyConstraintModel } from './models/foreignKeyConstraint';
import { FullTextSearchModel } from './models/fullTextSearch';
import { IndexModel } from './models/index';
import { LimitFunctionModel } from './models/limitFunction';
import { PolicyModel } from './models/policy';
import { PrimaryKeyConstraintModel } from './models/primaryKeyConstraint';
import { TableGrantModel } from './models/tableGrant';
import { TriggerModel } from './models/trigger';
import { UniqueConstraintModel } from './models/uniqueConstraint';
import { ConnectedAccountsModuleModel } from './models/connectedAccountsModule';
import { CryptoAddressesModuleModel } from './models/cryptoAddressesModule';
import { CryptoAuthModuleModel } from './models/cryptoAuthModule';
import { EmailsModuleModel } from './models/emailsModule';
import { EncryptedSecretsModuleModel } from './models/encryptedSecretsModule';
import { TableModuleModel } from './models/tableModule';
import { InvitesModuleModel } from './models/invitesModule';
import { LevelsModuleModel } from './models/levelsModule';
import { LimitsModuleModel } from './models/limitsModule';
import { MembershipTypesModuleModel } from './models/membershipTypesModule';
import { PermissionsModuleModel } from './models/permissionsModule';
import { PhoneNumbersModuleModel } from './models/phoneNumbersModule';
import { ProfilesModuleModel } from './models/profilesModule';
import { SecretsModuleModel } from './models/secretsModule';
import { TokensModuleModel } from './models/tokensModule';
import { UsersModuleModel } from './models/usersModule';
import { HierarchyModuleModel } from './models/hierarchyModule';
import { TableTemplateModuleModel } from './models/tableTemplateModule';
import { SchemaGrantModel } from './models/schemaGrant';
import { ApiSchemaModel } from './models/apiSchema';
import { ApiExtensionModel } from './models/apiExtension';
import { ApiModuleModel } from './models/apiModule';
import { DomainModel } from './models/domain';
import { SiteMetadatumModel } from './models/siteMetadatum';
import { SiteModuleModel } from './models/siteModule';
import { SiteThemeModel } from './models/siteTheme';
import { RlsModuleModel } from './models/rlsModule';
import { UserAuthModuleModel } from './models/userAuthModule';
import { UuidModuleModel } from './models/uuidModule';
import { DatabaseExtensionModel } from './models/databaseExtension';
import { ProcedureModel } from './models/procedure';
import { TriggerFunctionModel } from './models/triggerFunction';
import { ApiModel } from './models/api';
import { SiteModel } from './models/site';
import { AppModel } from './models/app';
import { DefaultIdsModuleModel } from './models/defaultIdsModule';
import { DatabaseProvisionModuleModel } from './models/databaseProvisionModule';
import { ExtensionModel } from './models/extension';
import { NodeTypeRegistryModel } from './models/nodeTypeRegistry';
import { ObjectModel } from './models/object';
import { CommitModel } from './models/commit';
import { RefModel } from './models/ref';
import { StoreModel } from './models/store';
import { AstActionModel } from './models/astAction';
import { AstMigrationModel } from './models/astMigration';
import { SqlMigrationModel } from './models/sqlMigration';
import { RoleTypeModel } from './models/roleType';
export type { OrmClientConfig, QueryResult, GraphQLError } from './client';
export { GraphQLRequestError } from './client';
export { QueryBuilder } from './query-builder';
export * from './select-types';
export * from './models';
export { createQueryOperations } from './query';
export { createMutationOperations } from './mutation';
/**
 * Create an ORM client instance
 *
 * @example
 * ```typescript
 * const db = createClient({
 *   endpoint: 'https://api.example.com/graphql',
 *   headers: { Authorization: 'Bearer token' },
 * });
 *
 * // Query users
 * const users = await db.user.findMany({
 *   select: { id: true, name: true },
 *   first: 10,
 * }).execute();
 *
 * // Create a user
 * const newUser = await db.user.create({
 *   data: { name: 'John', email: 'john@example.com' },
 *   select: { id: true },
 * }).execute();
 * ```
 */
export declare function createClient(config: OrmClientConfig): {
    checkConstraint: CheckConstraintModel;
    user: UserModel;
    database: DatabaseModel;
    email: EmailModel;
    phoneNumber: PhoneNumberModel;
    cryptoAddress: CryptoAddressModel;
    connectedAccount: ConnectedAccountModel;
    auditLog: AuditLogModel;
    schema: SchemaModel;
    table: TableModel;
    field: FieldModel;
    denormalizedTableField: DenormalizedTableFieldModel;
    fieldModule: FieldModuleModel;
    membershipsModule: MembershipsModuleModel;
    foreignKeyConstraint: ForeignKeyConstraintModel;
    fullTextSearch: FullTextSearchModel;
    index: IndexModel;
    limitFunction: LimitFunctionModel;
    policy: PolicyModel;
    primaryKeyConstraint: PrimaryKeyConstraintModel;
    tableGrant: TableGrantModel;
    trigger: TriggerModel;
    uniqueConstraint: UniqueConstraintModel;
    connectedAccountsModule: ConnectedAccountsModuleModel;
    cryptoAddressesModule: CryptoAddressesModuleModel;
    cryptoAuthModule: CryptoAuthModuleModel;
    emailsModule: EmailsModuleModel;
    encryptedSecretsModule: EncryptedSecretsModuleModel;
    tableModule: TableModuleModel;
    invitesModule: InvitesModuleModel;
    levelsModule: LevelsModuleModel;
    limitsModule: LimitsModuleModel;
    membershipTypesModule: MembershipTypesModuleModel;
    permissionsModule: PermissionsModuleModel;
    phoneNumbersModule: PhoneNumbersModuleModel;
    profilesModule: ProfilesModuleModel;
    secretsModule: SecretsModuleModel;
    tokensModule: TokensModuleModel;
    usersModule: UsersModuleModel;
    hierarchyModule: HierarchyModuleModel;
    tableTemplateModule: TableTemplateModuleModel;
    schemaGrant: SchemaGrantModel;
    apiSchema: ApiSchemaModel;
    apiExtension: ApiExtensionModel;
    apiModule: ApiModuleModel;
    domain: DomainModel;
    siteMetadatum: SiteMetadatumModel;
    siteModule: SiteModuleModel;
    siteTheme: SiteThemeModel;
    rlsModule: RlsModuleModel;
    userAuthModule: UserAuthModuleModel;
    uuidModule: UuidModuleModel;
    databaseExtension: DatabaseExtensionModel;
    procedure: ProcedureModel;
    triggerFunction: TriggerFunctionModel;
    api: ApiModel;
    site: SiteModel;
    app: AppModel;
    defaultIdsModule: DefaultIdsModuleModel;
    databaseProvisionModule: DatabaseProvisionModuleModel;
    extension: ExtensionModel;
    nodeTypeRegistry: NodeTypeRegistryModel;
    object: ObjectModel;
    commit: CommitModel;
    ref: RefModel;
    store: StoreModel;
    astAction: AstActionModel;
    astMigration: AstMigrationModel;
    sqlMigration: SqlMigrationModel;
    roleType: RoleTypeModel;
    query: {
        checkConstraintByTableIdAndName: <const S extends import("./input-types").CheckConstraintSelect>(args: import("./query").CheckConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CheckConstraintSelect>;
        }) => import("./query-builder").QueryBuilder<{
            checkConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").CheckConstraint, S>;
        }>;
        databaseBySchemaName: <const S extends import("./input-types").DatabaseSelect>(args: import("./query").DatabaseBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DatabaseSelect>;
        }) => import("./query-builder").QueryBuilder<{
            databaseBySchemaName: import("./select-types").InferSelectResult<import("./input-types").Database, S>;
        }>;
        databaseByPrivateSchemaName: <const S extends import("./input-types").DatabaseSelect>(args: import("./query").DatabaseByPrivateSchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DatabaseSelect>;
        }) => import("./query-builder").QueryBuilder<{
            databaseByPrivateSchemaName: import("./select-types").InferSelectResult<import("./input-types").Database, S>;
        }>;
        databaseExtension: <const S extends import("./input-types").DatabaseExtensionSelect>(args: import("./query").DatabaseExtensionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DatabaseExtensionSelect>;
        }) => import("./query-builder").QueryBuilder<{
            databaseExtension: import("./select-types").InferSelectResult<import("./input-types").DatabaseExtension, S>;
        }>;
        fieldByTableIdAndName: <const S extends import("./input-types").FieldSelect>(args: import("./query").FieldByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").FieldSelect>;
        }) => import("./query-builder").QueryBuilder<{
            fieldByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").Field, S>;
        }>;
        foreignKeyConstraintByTableIdAndName: <const S extends import("./input-types").ForeignKeyConstraintSelect>(args: import("./query").ForeignKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ForeignKeyConstraintSelect>;
        }) => import("./query-builder").QueryBuilder<{
            foreignKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").ForeignKeyConstraint, S>;
        }>;
        indexByDatabaseIdAndName: <const S extends import("./input-types").IndexSelect>(args: import("./query").IndexByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").IndexSelect>;
        }) => import("./query-builder").QueryBuilder<{
            indexByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").Index, S>;
        }>;
        limitFunctionByDatabaseIdAndName: <const S extends import("./input-types").LimitFunctionSelect>(args: import("./query").LimitFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").LimitFunctionSelect>;
        }) => import("./query-builder").QueryBuilder<{
            limitFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").LimitFunction, S>;
        }>;
        nodeTypeRegistryBySlug: <const S extends import("./input-types").NodeTypeRegistrySelect>(args: import("./query").NodeTypeRegistryBySlugVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").NodeTypeRegistrySelect>;
        }) => import("./query-builder").QueryBuilder<{
            nodeTypeRegistryBySlug: import("./select-types").InferSelectResult<import("./input-types").NodeTypeRegistry, S>;
        }>;
        policyByTableIdAndName: <const S extends import("./input-types").PolicySelect>(args: import("./query").PolicyByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").PolicySelect>;
        }) => import("./query-builder").QueryBuilder<{
            policyByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").Policy, S>;
        }>;
        primaryKeyConstraintByTableIdAndName: <const S extends import("./input-types").PrimaryKeyConstraintSelect>(args: import("./query").PrimaryKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").PrimaryKeyConstraintSelect>;
        }) => import("./query-builder").QueryBuilder<{
            primaryKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").PrimaryKeyConstraint, S>;
        }>;
        procedureByDatabaseIdAndName: <const S extends import("./input-types").ProcedureSelect>(args: import("./query").ProcedureByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ProcedureSelect>;
        }) => import("./query-builder").QueryBuilder<{
            procedureByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").Procedure, S>;
        }>;
        schemaByDatabaseIdAndName: <const S extends import("./input-types").SchemaSelect>(args: import("./query").SchemaByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SchemaSelect>;
        }) => import("./query-builder").QueryBuilder<{
            schemaByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").Schema, S>;
        }>;
        schemaBySchemaName: <const S extends import("./input-types").SchemaSelect>(args: import("./query").SchemaBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SchemaSelect>;
        }) => import("./query-builder").QueryBuilder<{
            schemaBySchemaName: import("./select-types").InferSelectResult<import("./input-types").Schema, S>;
        }>;
        tableByDatabaseIdAndName: <const S extends import("./input-types").TableSelect>(args: import("./query").TableByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").TableSelect>;
        }) => import("./query-builder").QueryBuilder<{
            tableByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").Table, S>;
        }>;
        triggerByTableIdAndName: <const S extends import("./input-types").TriggerSelect>(args: import("./query").TriggerByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").TriggerSelect>;
        }) => import("./query-builder").QueryBuilder<{
            triggerByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").Trigger, S>;
        }>;
        triggerFunctionByDatabaseIdAndName: <const S extends import("./input-types").TriggerFunctionSelect>(args: import("./query").TriggerFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").TriggerFunctionSelect>;
        }) => import("./query-builder").QueryBuilder<{
            triggerFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").TriggerFunction, S>;
        }>;
        uniqueConstraintByTableIdAndName: <const S extends import("./input-types").UniqueConstraintSelect>(args: import("./query").UniqueConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UniqueConstraintSelect>;
        }) => import("./query-builder").QueryBuilder<{
            uniqueConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UniqueConstraint, S>;
        }>;
        astActionByDatabaseIdAndDeploys: <const S extends import("./input-types").AstActionSelect>(args: import("./query").AstActionByDatabaseIdAndDeploysVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AstActionSelect>;
        }) => import("./query-builder").QueryBuilder<{
            astActionByDatabaseIdAndDeploys: import("./select-types").InferSelectResult<import("./input-types").AstAction, S>;
        }>;
        apiExtensionBySchemaNameAndApiId: <const S extends import("./input-types").ApiExtensionSelect>(args: import("./query").ApiExtensionBySchemaNameAndApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ApiExtensionSelect>;
        }) => import("./query-builder").QueryBuilder<{
            apiExtensionBySchemaNameAndApiId: import("./select-types").InferSelectResult<import("./input-types").ApiExtension, S>;
        }>;
        apiSchemaByApiIdAndSchemaId: <const S extends import("./input-types").ApiSchemaSelect>(args: import("./query").ApiSchemaByApiIdAndSchemaIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ApiSchemaSelect>;
        }) => import("./query-builder").QueryBuilder<{
            apiSchemaByApiIdAndSchemaId: import("./select-types").InferSelectResult<import("./input-types").ApiSchema, S>;
        }>;
        apiByDatabaseIdAndName: <const S extends import("./input-types").ApiSelect>(args: import("./query").ApiByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ApiSelect>;
        }) => import("./query-builder").QueryBuilder<{
            apiByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").Api, S>;
        }>;
        appBySiteId: <const S extends import("./input-types").AppSelect>(args: import("./query").AppBySiteIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AppSelect>;
        }) => import("./query-builder").QueryBuilder<{
            appBySiteId: import("./select-types").InferSelectResult<import("./input-types").App, S>;
        }>;
        domainBySubdomainAndDomain: <const S extends import("./input-types").DomainSelect>(args: import("./query").DomainBySubdomainAndDomainVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DomainSelect>;
        }) => import("./query-builder").QueryBuilder<{
            domainBySubdomainAndDomain: import("./select-types").InferSelectResult<import("./input-types").Domain, S>;
        }>;
        hierarchyModuleByDatabaseId: <const S extends import("./input-types").HierarchyModuleSelect>(args: import("./query").HierarchyModuleByDatabaseIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").HierarchyModuleSelect>;
        }) => import("./query-builder").QueryBuilder<{
            hierarchyModuleByDatabaseId: import("./select-types").InferSelectResult<import("./input-types").HierarchyModule, S>;
        }>;
        profilesModuleByDatabaseIdAndMembershipType: <const S extends import("./input-types").ProfilesModuleSelect>(args: import("./query").ProfilesModuleByDatabaseIdAndMembershipTypeVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ProfilesModuleSelect>;
        }) => import("./query-builder").QueryBuilder<{
            profilesModuleByDatabaseIdAndMembershipType: import("./select-types").InferSelectResult<import("./input-types").ProfilesModule, S>;
        }>;
        rlsModuleByApiId: <const S extends import("./input-types").RlsModuleSelect>(args: import("./query").RlsModuleByApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RlsModuleSelect>;
        }) => import("./query-builder").QueryBuilder<{
            rlsModuleByApiId: import("./select-types").InferSelectResult<import("./input-types").RlsModule, S>;
        }>;
        roleTypeByName: <const S extends import("./input-types").RoleTypeSelect>(args: import("./query").RoleTypeByNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RoleTypeSelect>;
        }) => import("./query-builder").QueryBuilder<{
            roleTypeByName: import("./select-types").InferSelectResult<import("./input-types").RoleType, S>;
        }>;
        userByUsername: <const S extends import("./input-types").UserSelect>(args: import("./query").UserByUsernameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UserSelect>;
        }) => import("./query-builder").QueryBuilder<{
            userByUsername: import("./select-types").InferSelectResult<import("./input-types").User, S>;
        }>;
        connectedAccountByServiceAndIdentifier: <const S extends import("./input-types").ConnectedAccountSelect>(args: import("./query").ConnectedAccountByServiceAndIdentifierVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ConnectedAccountSelect>;
        }) => import("./query-builder").QueryBuilder<{
            connectedAccountByServiceAndIdentifier: import("./select-types").InferSelectResult<import("./input-types").ConnectedAccount, S>;
        }>;
        cryptoAddressByAddress: <const S extends import("./input-types").CryptoAddressSelect>(args: import("./query").CryptoAddressByAddressVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CryptoAddressSelect>;
        }) => import("./query-builder").QueryBuilder<{
            cryptoAddressByAddress: import("./select-types").InferSelectResult<import("./input-types").CryptoAddress, S>;
        }>;
        emailByEmail: <const S extends import("./input-types").EmailSelect>(args: import("./query").EmailByEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").EmailSelect>;
        }) => import("./query-builder").QueryBuilder<{
            emailByEmail: import("./select-types").InferSelectResult<import("./input-types").Email, S>;
        }>;
        phoneNumberByNumber: <const S extends import("./input-types").PhoneNumberSelect>(args: import("./query").PhoneNumberByNumberVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").PhoneNumberSelect>;
        }) => import("./query-builder").QueryBuilder<{
            phoneNumberByNumber: import("./select-types").InferSelectResult<import("./input-types").PhoneNumber, S>;
        }>;
        getAll: (args: import("./query").GetAllVariables, options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        getAllObjectsFromRoot: (args: import("./query").GetAllObjectsFromRootVariables, options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        getNodeAtPath: <const S extends import("./input-types").ObjectSelect>(args: import("./query").GetNodeAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ObjectSelect>;
        }) => import("./query-builder").QueryBuilder<{
            getNodeAtPath: import("./select-types").InferSelectResult<import("./input-types").Object, S>;
        }>;
        getPathObjectsFromRoot: (args: import("./query").GetPathObjectsFromRootVariables, options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        getObjectAtPath: <const S extends import("./input-types").ObjectSelect>(args: import("./query").GetObjectAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ObjectSelect>;
        }) => import("./query-builder").QueryBuilder<{
            getObjectAtPath: import("./select-types").InferSelectResult<import("./input-types").Object, S>;
        }>;
        revParse: (args: import("./query").RevParseVariables, options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        currentIpAddress: (options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        currentUser: <const S extends import("./input-types").UserSelect>(options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UserSelect>;
        }) => import("./query-builder").QueryBuilder<{
            currentUser: import("./select-types").InferSelectResult<import("./input-types").User, S>;
        }>;
        currentUserAgent: (options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
        currentUserId: (options?: {
            select?: Record<string, unknown>;
        }) => import("./query-builder").QueryBuilder<unknown>;
    };
    mutation: {
        updateCheckConstraintByTableIdAndName: <const S extends import("./input-types").UpdateCheckConstraintPayloadSelect>(args: import("./mutation").UpdateCheckConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateCheckConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateCheckConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateCheckConstraintPayload, S>;
        }>;
        updateDatabaseBySchemaName: <const S extends import("./input-types").UpdateDatabasePayloadSelect>(args: import("./mutation").UpdateDatabaseBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateDatabasePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateDatabaseBySchemaName: import("./select-types").InferSelectResult<import("./input-types").UpdateDatabasePayload, S>;
        }>;
        updateDatabaseByPrivateSchemaName: <const S extends import("./input-types").UpdateDatabasePayloadSelect>(args: import("./mutation").UpdateDatabaseByPrivateSchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateDatabasePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateDatabaseByPrivateSchemaName: import("./select-types").InferSelectResult<import("./input-types").UpdateDatabasePayload, S>;
        }>;
        updateDatabaseExtensionByDatabaseIdAndName: <const S extends import("./input-types").UpdateDatabaseExtensionPayloadSelect>(args: import("./mutation").UpdateDatabaseExtensionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateDatabaseExtensionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateDatabaseExtensionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateDatabaseExtensionPayload, S>;
        }>;
        updateFieldByTableIdAndName: <const S extends import("./input-types").UpdateFieldPayloadSelect>(args: import("./mutation").UpdateFieldByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateFieldPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateFieldByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateFieldPayload, S>;
        }>;
        updateForeignKeyConstraintByTableIdAndName: <const S extends import("./input-types").UpdateForeignKeyConstraintPayloadSelect>(args: import("./mutation").UpdateForeignKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateForeignKeyConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateForeignKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateForeignKeyConstraintPayload, S>;
        }>;
        updateIndexByDatabaseIdAndName: <const S extends import("./input-types").UpdateIndexPayloadSelect>(args: import("./mutation").UpdateIndexByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateIndexPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateIndexByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateIndexPayload, S>;
        }>;
        updateLimitFunctionByDatabaseIdAndName: <const S extends import("./input-types").UpdateLimitFunctionPayloadSelect>(args: import("./mutation").UpdateLimitFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateLimitFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateLimitFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateLimitFunctionPayload, S>;
        }>;
        updateNodeTypeRegistryBySlug: <const S extends import("./input-types").UpdateNodeTypeRegistryPayloadSelect>(args: import("./mutation").UpdateNodeTypeRegistryBySlugVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateNodeTypeRegistryPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateNodeTypeRegistryBySlug: import("./select-types").InferSelectResult<import("./input-types").UpdateNodeTypeRegistryPayload, S>;
        }>;
        updatePolicyByTableIdAndName: <const S extends import("./input-types").UpdatePolicyPayloadSelect>(args: import("./mutation").UpdatePolicyByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdatePolicyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updatePolicyByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdatePolicyPayload, S>;
        }>;
        updatePrimaryKeyConstraintByTableIdAndName: <const S extends import("./input-types").UpdatePrimaryKeyConstraintPayloadSelect>(args: import("./mutation").UpdatePrimaryKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdatePrimaryKeyConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updatePrimaryKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdatePrimaryKeyConstraintPayload, S>;
        }>;
        updateProcedureByDatabaseIdAndName: <const S extends import("./input-types").UpdateProcedurePayloadSelect>(args: import("./mutation").UpdateProcedureByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateProcedurePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateProcedureByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateProcedurePayload, S>;
        }>;
        updateSchemaByDatabaseIdAndName: <const S extends import("./input-types").UpdateSchemaPayloadSelect>(args: import("./mutation").UpdateSchemaByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateSchemaByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateSchemaPayload, S>;
        }>;
        updateSchemaBySchemaName: <const S extends import("./input-types").UpdateSchemaPayloadSelect>(args: import("./mutation").UpdateSchemaBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateSchemaBySchemaName: import("./select-types").InferSelectResult<import("./input-types").UpdateSchemaPayload, S>;
        }>;
        updateTableByDatabaseIdAndName: <const S extends import("./input-types").UpdateTablePayloadSelect>(args: import("./mutation").UpdateTableByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateTablePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateTableByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateTablePayload, S>;
        }>;
        updateTriggerByTableIdAndName: <const S extends import("./input-types").UpdateTriggerPayloadSelect>(args: import("./mutation").UpdateTriggerByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateTriggerByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateTriggerPayload, S>;
        }>;
        updateTriggerFunctionByDatabaseIdAndName: <const S extends import("./input-types").UpdateTriggerFunctionPayloadSelect>(args: import("./mutation").UpdateTriggerFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateTriggerFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateTriggerFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateTriggerFunctionPayload, S>;
        }>;
        updateUniqueConstraintByTableIdAndName: <const S extends import("./input-types").UpdateUniqueConstraintPayloadSelect>(args: import("./mutation").UpdateUniqueConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateUniqueConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateUniqueConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateUniqueConstraintPayload, S>;
        }>;
        updateAstActionByDatabaseIdAndDeploys: <const S extends import("./input-types").UpdateAstActionPayloadSelect>(args: import("./mutation").UpdateAstActionByDatabaseIdAndDeploysVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateAstActionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateAstActionByDatabaseIdAndDeploys: import("./select-types").InferSelectResult<import("./input-types").UpdateAstActionPayload, S>;
        }>;
        updateApiExtensionBySchemaNameAndApiId: <const S extends import("./input-types").UpdateApiExtensionPayloadSelect>(args: import("./mutation").UpdateApiExtensionBySchemaNameAndApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateApiExtensionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateApiExtensionBySchemaNameAndApiId: import("./select-types").InferSelectResult<import("./input-types").UpdateApiExtensionPayload, S>;
        }>;
        updateApiSchemaByApiIdAndSchemaId: <const S extends import("./input-types").UpdateApiSchemaPayloadSelect>(args: import("./mutation").UpdateApiSchemaByApiIdAndSchemaIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateApiSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateApiSchemaByApiIdAndSchemaId: import("./select-types").InferSelectResult<import("./input-types").UpdateApiSchemaPayload, S>;
        }>;
        updateApiByDatabaseIdAndName: <const S extends import("./input-types").UpdateApiPayloadSelect>(args: import("./mutation").UpdateApiByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateApiPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateApiByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").UpdateApiPayload, S>;
        }>;
        updateAppBySiteId: <const S extends import("./input-types").UpdateAppPayloadSelect>(args: import("./mutation").UpdateAppBySiteIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateAppPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateAppBySiteId: import("./select-types").InferSelectResult<import("./input-types").UpdateAppPayload, S>;
        }>;
        updateDomainBySubdomainAndDomain: <const S extends import("./input-types").UpdateDomainPayloadSelect>(args: import("./mutation").UpdateDomainBySubdomainAndDomainVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateDomainPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateDomainBySubdomainAndDomain: import("./select-types").InferSelectResult<import("./input-types").UpdateDomainPayload, S>;
        }>;
        updateHierarchyModuleByDatabaseId: <const S extends import("./input-types").UpdateHierarchyModulePayloadSelect>(args: import("./mutation").UpdateHierarchyModuleByDatabaseIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateHierarchyModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateHierarchyModuleByDatabaseId: import("./select-types").InferSelectResult<import("./input-types").UpdateHierarchyModulePayload, S>;
        }>;
        updateProfilesModuleByDatabaseIdAndMembershipType: <const S extends import("./input-types").UpdateProfilesModulePayloadSelect>(args: import("./mutation").UpdateProfilesModuleByDatabaseIdAndMembershipTypeVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateProfilesModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateProfilesModuleByDatabaseIdAndMembershipType: import("./select-types").InferSelectResult<import("./input-types").UpdateProfilesModulePayload, S>;
        }>;
        updateRlsModuleByApiId: <const S extends import("./input-types").UpdateRlsModulePayloadSelect>(args: import("./mutation").UpdateRlsModuleByApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateRlsModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateRlsModuleByApiId: import("./select-types").InferSelectResult<import("./input-types").UpdateRlsModulePayload, S>;
        }>;
        updateRoleTypeByName: <const S extends import("./input-types").UpdateRoleTypePayloadSelect>(args: import("./mutation").UpdateRoleTypeByNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateRoleTypePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateRoleTypeByName: import("./select-types").InferSelectResult<import("./input-types").UpdateRoleTypePayload, S>;
        }>;
        updateUserByUsername: <const S extends import("./input-types").UpdateUserPayloadSelect>(args: import("./mutation").UpdateUserByUsernameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateUserPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateUserByUsername: import("./select-types").InferSelectResult<import("./input-types").UpdateUserPayload, S>;
        }>;
        updateConnectedAccountByServiceAndIdentifier: <const S extends import("./input-types").UpdateConnectedAccountPayloadSelect>(args: import("./mutation").UpdateConnectedAccountByServiceAndIdentifierVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateConnectedAccountPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateConnectedAccountByServiceAndIdentifier: import("./select-types").InferSelectResult<import("./input-types").UpdateConnectedAccountPayload, S>;
        }>;
        updateCryptoAddressByAddress: <const S extends import("./input-types").UpdateCryptoAddressPayloadSelect>(args: import("./mutation").UpdateCryptoAddressByAddressVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateCryptoAddressPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateCryptoAddressByAddress: import("./select-types").InferSelectResult<import("./input-types").UpdateCryptoAddressPayload, S>;
        }>;
        updateEmailByEmail: <const S extends import("./input-types").UpdateEmailPayloadSelect>(args: import("./mutation").UpdateEmailByEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateEmailPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateEmailByEmail: import("./select-types").InferSelectResult<import("./input-types").UpdateEmailPayload, S>;
        }>;
        updatePhoneNumberByNumber: <const S extends import("./input-types").UpdatePhoneNumberPayloadSelect>(args: import("./mutation").UpdatePhoneNumberByNumberVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdatePhoneNumberPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updatePhoneNumberByNumber: import("./select-types").InferSelectResult<import("./input-types").UpdatePhoneNumberPayload, S>;
        }>;
        deleteCheckConstraintByTableIdAndName: <const S extends import("./input-types").DeleteCheckConstraintPayloadSelect>(args: import("./mutation").DeleteCheckConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteCheckConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteCheckConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteCheckConstraintPayload, S>;
        }>;
        deleteDatabaseBySchemaName: <const S extends import("./input-types").DeleteDatabasePayloadSelect>(args: import("./mutation").DeleteDatabaseBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteDatabasePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteDatabaseBySchemaName: import("./select-types").InferSelectResult<import("./input-types").DeleteDatabasePayload, S>;
        }>;
        deleteDatabaseByPrivateSchemaName: <const S extends import("./input-types").DeleteDatabasePayloadSelect>(args: import("./mutation").DeleteDatabaseByPrivateSchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteDatabasePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteDatabaseByPrivateSchemaName: import("./select-types").InferSelectResult<import("./input-types").DeleteDatabasePayload, S>;
        }>;
        deleteDatabaseExtensionByDatabaseIdAndName: <const S extends import("./input-types").DeleteDatabaseExtensionPayloadSelect>(args: import("./mutation").DeleteDatabaseExtensionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteDatabaseExtensionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteDatabaseExtensionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteDatabaseExtensionPayload, S>;
        }>;
        deleteFieldByTableIdAndName: <const S extends import("./input-types").DeleteFieldPayloadSelect>(args: import("./mutation").DeleteFieldByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteFieldPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteFieldByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteFieldPayload, S>;
        }>;
        deleteForeignKeyConstraintByTableIdAndName: <const S extends import("./input-types").DeleteForeignKeyConstraintPayloadSelect>(args: import("./mutation").DeleteForeignKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteForeignKeyConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteForeignKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteForeignKeyConstraintPayload, S>;
        }>;
        deleteIndexByDatabaseIdAndName: <const S extends import("./input-types").DeleteIndexPayloadSelect>(args: import("./mutation").DeleteIndexByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteIndexPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteIndexByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteIndexPayload, S>;
        }>;
        deleteLimitFunctionByDatabaseIdAndName: <const S extends import("./input-types").DeleteLimitFunctionPayloadSelect>(args: import("./mutation").DeleteLimitFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteLimitFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteLimitFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteLimitFunctionPayload, S>;
        }>;
        deleteNodeTypeRegistryBySlug: <const S extends import("./input-types").DeleteNodeTypeRegistryPayloadSelect>(args: import("./mutation").DeleteNodeTypeRegistryBySlugVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteNodeTypeRegistryPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteNodeTypeRegistryBySlug: import("./select-types").InferSelectResult<import("./input-types").DeleteNodeTypeRegistryPayload, S>;
        }>;
        deletePolicyByTableIdAndName: <const S extends import("./input-types").DeletePolicyPayloadSelect>(args: import("./mutation").DeletePolicyByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeletePolicyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deletePolicyByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeletePolicyPayload, S>;
        }>;
        deletePrimaryKeyConstraintByTableIdAndName: <const S extends import("./input-types").DeletePrimaryKeyConstraintPayloadSelect>(args: import("./mutation").DeletePrimaryKeyConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeletePrimaryKeyConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deletePrimaryKeyConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeletePrimaryKeyConstraintPayload, S>;
        }>;
        deleteProcedureByDatabaseIdAndName: <const S extends import("./input-types").DeleteProcedurePayloadSelect>(args: import("./mutation").DeleteProcedureByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteProcedurePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteProcedureByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteProcedurePayload, S>;
        }>;
        deleteSchemaByDatabaseIdAndName: <const S extends import("./input-types").DeleteSchemaPayloadSelect>(args: import("./mutation").DeleteSchemaByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteSchemaByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteSchemaPayload, S>;
        }>;
        deleteSchemaBySchemaName: <const S extends import("./input-types").DeleteSchemaPayloadSelect>(args: import("./mutation").DeleteSchemaBySchemaNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteSchemaBySchemaName: import("./select-types").InferSelectResult<import("./input-types").DeleteSchemaPayload, S>;
        }>;
        deleteTableByDatabaseIdAndName: <const S extends import("./input-types").DeleteTablePayloadSelect>(args: import("./mutation").DeleteTableByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteTablePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteTableByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteTablePayload, S>;
        }>;
        deleteTriggerByTableIdAndName: <const S extends import("./input-types").DeleteTriggerPayloadSelect>(args: import("./mutation").DeleteTriggerByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteTriggerByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteTriggerPayload, S>;
        }>;
        deleteTriggerFunctionByDatabaseIdAndName: <const S extends import("./input-types").DeleteTriggerFunctionPayloadSelect>(args: import("./mutation").DeleteTriggerFunctionByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteTriggerFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteTriggerFunctionByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteTriggerFunctionPayload, S>;
        }>;
        deleteUniqueConstraintByTableIdAndName: <const S extends import("./input-types").DeleteUniqueConstraintPayloadSelect>(args: import("./mutation").DeleteUniqueConstraintByTableIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteUniqueConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteUniqueConstraintByTableIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteUniqueConstraintPayload, S>;
        }>;
        deleteAstActionByDatabaseIdAndDeploys: <const S extends import("./input-types").DeleteAstActionPayloadSelect>(args: import("./mutation").DeleteAstActionByDatabaseIdAndDeploysVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteAstActionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteAstActionByDatabaseIdAndDeploys: import("./select-types").InferSelectResult<import("./input-types").DeleteAstActionPayload, S>;
        }>;
        deleteApiExtensionBySchemaNameAndApiId: <const S extends import("./input-types").DeleteApiExtensionPayloadSelect>(args: import("./mutation").DeleteApiExtensionBySchemaNameAndApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteApiExtensionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteApiExtensionBySchemaNameAndApiId: import("./select-types").InferSelectResult<import("./input-types").DeleteApiExtensionPayload, S>;
        }>;
        deleteApiSchemaByApiIdAndSchemaId: <const S extends import("./input-types").DeleteApiSchemaPayloadSelect>(args: import("./mutation").DeleteApiSchemaByApiIdAndSchemaIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteApiSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteApiSchemaByApiIdAndSchemaId: import("./select-types").InferSelectResult<import("./input-types").DeleteApiSchemaPayload, S>;
        }>;
        deleteApiByDatabaseIdAndName: <const S extends import("./input-types").DeleteApiPayloadSelect>(args: import("./mutation").DeleteApiByDatabaseIdAndNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteApiPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteApiByDatabaseIdAndName: import("./select-types").InferSelectResult<import("./input-types").DeleteApiPayload, S>;
        }>;
        deleteAppBySiteId: <const S extends import("./input-types").DeleteAppPayloadSelect>(args: import("./mutation").DeleteAppBySiteIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteAppPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteAppBySiteId: import("./select-types").InferSelectResult<import("./input-types").DeleteAppPayload, S>;
        }>;
        deleteDomainBySubdomainAndDomain: <const S extends import("./input-types").DeleteDomainPayloadSelect>(args: import("./mutation").DeleteDomainBySubdomainAndDomainVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteDomainPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteDomainBySubdomainAndDomain: import("./select-types").InferSelectResult<import("./input-types").DeleteDomainPayload, S>;
        }>;
        deleteHierarchyModuleByDatabaseId: <const S extends import("./input-types").DeleteHierarchyModulePayloadSelect>(args: import("./mutation").DeleteHierarchyModuleByDatabaseIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteHierarchyModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteHierarchyModuleByDatabaseId: import("./select-types").InferSelectResult<import("./input-types").DeleteHierarchyModulePayload, S>;
        }>;
        deleteProfilesModuleByDatabaseIdAndMembershipType: <const S extends import("./input-types").DeleteProfilesModulePayloadSelect>(args: import("./mutation").DeleteProfilesModuleByDatabaseIdAndMembershipTypeVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteProfilesModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteProfilesModuleByDatabaseIdAndMembershipType: import("./select-types").InferSelectResult<import("./input-types").DeleteProfilesModulePayload, S>;
        }>;
        deleteRlsModuleByApiId: <const S extends import("./input-types").DeleteRlsModulePayloadSelect>(args: import("./mutation").DeleteRlsModuleByApiIdVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteRlsModulePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteRlsModuleByApiId: import("./select-types").InferSelectResult<import("./input-types").DeleteRlsModulePayload, S>;
        }>;
        deleteRoleTypeByName: <const S extends import("./input-types").DeleteRoleTypePayloadSelect>(args: import("./mutation").DeleteRoleTypeByNameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteRoleTypePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteRoleTypeByName: import("./select-types").InferSelectResult<import("./input-types").DeleteRoleTypePayload, S>;
        }>;
        deleteUserByUsername: <const S extends import("./input-types").DeleteUserPayloadSelect>(args: import("./mutation").DeleteUserByUsernameVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteUserPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteUserByUsername: import("./select-types").InferSelectResult<import("./input-types").DeleteUserPayload, S>;
        }>;
        deleteConnectedAccountByServiceAndIdentifier: <const S extends import("./input-types").DeleteConnectedAccountPayloadSelect>(args: import("./mutation").DeleteConnectedAccountByServiceAndIdentifierVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteConnectedAccountPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteConnectedAccountByServiceAndIdentifier: import("./select-types").InferSelectResult<import("./input-types").DeleteConnectedAccountPayload, S>;
        }>;
        deleteCryptoAddressByAddress: <const S extends import("./input-types").DeleteCryptoAddressPayloadSelect>(args: import("./mutation").DeleteCryptoAddressByAddressVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteCryptoAddressPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteCryptoAddressByAddress: import("./select-types").InferSelectResult<import("./input-types").DeleteCryptoAddressPayload, S>;
        }>;
        deleteEmailByEmail: <const S extends import("./input-types").DeleteEmailPayloadSelect>(args: import("./mutation").DeleteEmailByEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeleteEmailPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deleteEmailByEmail: import("./select-types").InferSelectResult<import("./input-types").DeleteEmailPayload, S>;
        }>;
        deletePhoneNumberByNumber: <const S extends import("./input-types").DeletePhoneNumberPayloadSelect>(args: import("./mutation").DeletePhoneNumberByNumberVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DeletePhoneNumberPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            deletePhoneNumberByNumber: import("./select-types").InferSelectResult<import("./input-types").DeletePhoneNumberPayload, S>;
        }>;
        applyRls: <const S extends import("./input-types").ApplyRlsPayloadSelect>(args: import("./mutation").ApplyRlsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ApplyRlsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            applyRls: import("./select-types").InferSelectResult<import("./input-types").ApplyRlsPayload, S>;
        }>;
        bootstrapUser: <const S extends import("./input-types").BootstrapUserPayloadSelect>(args: import("./mutation").BootstrapUserVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").BootstrapUserPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            bootstrapUser: import("./select-types").InferSelectResult<import("./input-types").BootstrapUserPayload, S>;
        }>;
        createUserDatabase: <const S extends import("./input-types").CreateUserDatabasePayloadSelect>(args: import("./mutation").CreateUserDatabaseVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateUserDatabasePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createUserDatabase: import("./select-types").InferSelectResult<import("./input-types").CreateUserDatabasePayload, S>;
        }>;
        provisionDatabaseWithUser: <const S extends import("./input-types").ProvisionDatabaseWithUserPayloadSelect>(args: import("./mutation").ProvisionDatabaseWithUserVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ProvisionDatabaseWithUserPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            provisionDatabaseWithUser: import("./select-types").InferSelectResult<import("./input-types").ProvisionDatabaseWithUserPayload, S>;
        }>;
        setFieldOrder: <const S extends import("./input-types").SetFieldOrderPayloadSelect>(args: import("./mutation").SetFieldOrderVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetFieldOrderPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setFieldOrder: import("./select-types").InferSelectResult<import("./input-types").SetFieldOrderPayload, S>;
        }>;
        freezeObjects: <const S extends import("./input-types").FreezeObjectsPayloadSelect>(args: import("./mutation").FreezeObjectsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").FreezeObjectsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            freezeObjects: import("./select-types").InferSelectResult<import("./input-types").FreezeObjectsPayload, S>;
        }>;
        insertNodeAtPath: <const S extends import("./input-types").InsertNodeAtPathPayloadSelect>(args: import("./mutation").InsertNodeAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").InsertNodeAtPathPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            insertNodeAtPath: import("./select-types").InferSelectResult<import("./input-types").InsertNodeAtPathPayload, S>;
        }>;
        removeNodeAtPath: <const S extends import("./input-types").RemoveNodeAtPathPayloadSelect>(args: import("./mutation").RemoveNodeAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RemoveNodeAtPathPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            removeNodeAtPath: import("./select-types").InferSelectResult<import("./input-types").RemoveNodeAtPathPayload, S>;
        }>;
        setDataAtPath: <const S extends import("./input-types").SetDataAtPathPayloadSelect>(args: import("./mutation").SetDataAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetDataAtPathPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setDataAtPath: import("./select-types").InferSelectResult<import("./input-types").SetDataAtPathPayload, S>;
        }>;
        updateNodeAtPath: <const S extends import("./input-types").UpdateNodeAtPathPayloadSelect>(args: import("./mutation").UpdateNodeAtPathVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").UpdateNodeAtPathPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            updateNodeAtPath: import("./select-types").InferSelectResult<import("./input-types").UpdateNodeAtPathPayload, S>;
        }>;
        initEmptyRepo: <const S extends import("./input-types").InitEmptyRepoPayloadSelect>(args: import("./mutation").InitEmptyRepoVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").InitEmptyRepoPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            initEmptyRepo: import("./select-types").InferSelectResult<import("./input-types").InitEmptyRepoPayload, S>;
        }>;
        setAndCommit: <const S extends import("./input-types").SetAndCommitPayloadSelect>(args: import("./mutation").SetAndCommitVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetAndCommitPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setAndCommit: import("./select-types").InferSelectResult<import("./input-types").SetAndCommitPayload, S>;
        }>;
        setPropsAndCommit: <const S extends import("./input-types").SetPropsAndCommitPayloadSelect>(args: import("./mutation").SetPropsAndCommitVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetPropsAndCommitPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setPropsAndCommit: import("./select-types").InferSelectResult<import("./input-types").SetPropsAndCommitPayload, S>;
        }>;
        addConstraintNoopImport: <const S extends import("./input-types").AddConstraintNoopImportPayloadSelect>(args: import("./mutation").AddConstraintNoopImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddConstraintNoopImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addConstraintNoopImport: import("./select-types").InferSelectResult<import("./input-types").AddConstraintNoopImportPayload, S>;
        }>;
        addImport: <const S extends import("./input-types").AddImportPayloadSelect>(args: import("./mutation").AddImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addImport: import("./select-types").InferSelectResult<import("./input-types").AddImportPayload, S>;
        }>;
        addSchemaImport: <const S extends import("./input-types").AddSchemaImportPayloadSelect>(args: import("./mutation").AddSchemaImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddSchemaImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addSchemaImport: import("./select-types").InferSelectResult<import("./input-types").AddSchemaImportPayload, S>;
        }>;
        addSchemaNoopImport: <const S extends import("./input-types").AddSchemaNoopImportPayloadSelect>(args: import("./mutation").AddSchemaNoopImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddSchemaNoopImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addSchemaNoopImport: import("./select-types").InferSelectResult<import("./input-types").AddSchemaNoopImportPayload, S>;
        }>;
        addTableImport: <const S extends import("./input-types").AddTableImportPayloadSelect>(args: import("./mutation").AddTableImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddTableImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addTableImport: import("./select-types").InferSelectResult<import("./input-types").AddTableImportPayload, S>;
        }>;
        addTableNoopImport: <const S extends import("./input-types").AddTableNoopImportPayloadSelect>(args: import("./mutation").AddTableNoopImportVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AddTableNoopImportPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            addTableNoopImport: import("./select-types").InferSelectResult<import("./input-types").AddTableNoopImportPayload, S>;
        }>;
        alterDefaultPrivilegesGrantOnFunctions: <const S extends import("./input-types").AlterDefaultPrivilegesGrantOnFunctionsPayloadSelect>(args: import("./mutation").AlterDefaultPrivilegesGrantOnFunctionsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterDefaultPrivilegesGrantOnFunctionsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterDefaultPrivilegesGrantOnFunctions: import("./select-types").InferSelectResult<import("./input-types").AlterDefaultPrivilegesGrantOnFunctionsPayload, S>;
        }>;
        alterDefaultPrivilegesGrantOnSequences: <const S extends import("./input-types").AlterDefaultPrivilegesGrantOnSequencesPayloadSelect>(args: import("./mutation").AlterDefaultPrivilegesGrantOnSequencesVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterDefaultPrivilegesGrantOnSequencesPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterDefaultPrivilegesGrantOnSequences: import("./select-types").InferSelectResult<import("./input-types").AlterDefaultPrivilegesGrantOnSequencesPayload, S>;
        }>;
        alterDefaultPrivilegesGrantOnTables: <const S extends import("./input-types").AlterDefaultPrivilegesGrantOnTablesPayloadSelect>(args: import("./mutation").AlterDefaultPrivilegesGrantOnTablesVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterDefaultPrivilegesGrantOnTablesPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterDefaultPrivilegesGrantOnTables: import("./select-types").InferSelectResult<import("./input-types").AlterDefaultPrivilegesGrantOnTablesPayload, S>;
        }>;
        alterDefaultPrivilegesRevokeOnSequences: <const S extends import("./input-types").AlterDefaultPrivilegesRevokeOnSequencesPayloadSelect>(args: import("./mutation").AlterDefaultPrivilegesRevokeOnSequencesVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterDefaultPrivilegesRevokeOnSequencesPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterDefaultPrivilegesRevokeOnSequences: import("./select-types").InferSelectResult<import("./input-types").AlterDefaultPrivilegesRevokeOnSequencesPayload, S>;
        }>;
        alterPolicy: <const S extends import("./input-types").AlterPolicyPayloadSelect>(args: import("./mutation").AlterPolicyVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterPolicyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterPolicy: import("./select-types").InferSelectResult<import("./input-types").AlterPolicyPayload, S>;
        }>;
        alterTableAddCheckConstraint: <const S extends import("./input-types").AlterTableAddCheckConstraintPayloadSelect>(args: import("./mutation").AlterTableAddCheckConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddCheckConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddCheckConstraint: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddCheckConstraintPayload, S>;
        }>;
        alterTableAddColumn: <const S extends import("./input-types").AlterTableAddColumnPayloadSelect>(args: import("./mutation").AlterTableAddColumnVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddColumnPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddColumn: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddColumnPayload, S>;
        }>;
        alterTableAddForeignKey: <const S extends import("./input-types").AlterTableAddForeignKeyPayloadSelect>(args: import("./mutation").AlterTableAddForeignKeyVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddForeignKeyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddForeignKey: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddForeignKeyPayload, S>;
        }>;
        alterTableAddInherits: <const S extends import("./input-types").AlterTableAddInheritsPayloadSelect>(args: import("./mutation").AlterTableAddInheritsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddInheritsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddInherits: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddInheritsPayload, S>;
        }>;
        alterTableAddPrimaryKey: <const S extends import("./input-types").AlterTableAddPrimaryKeyPayloadSelect>(args: import("./mutation").AlterTableAddPrimaryKeyVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddPrimaryKeyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddPrimaryKey: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddPrimaryKeyPayload, S>;
        }>;
        alterTableAddUniqueConstraint: <const S extends import("./input-types").AlterTableAddUniqueConstraintPayloadSelect>(args: import("./mutation").AlterTableAddUniqueConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableAddUniqueConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableAddUniqueConstraint: import("./select-types").InferSelectResult<import("./input-types").AlterTableAddUniqueConstraintPayload, S>;
        }>;
        alterTableDropColumn: <const S extends import("./input-types").AlterTableDropColumnPayloadSelect>(args: import("./mutation").AlterTableDropColumnVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableDropColumnPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableDropColumn: import("./select-types").InferSelectResult<import("./input-types").AlterTableDropColumnPayload, S>;
        }>;
        alterTableDropColumnDefault: <const S extends import("./input-types").AlterTableDropColumnDefaultPayloadSelect>(args: import("./mutation").AlterTableDropColumnDefaultVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableDropColumnDefaultPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableDropColumnDefault: import("./select-types").InferSelectResult<import("./input-types").AlterTableDropColumnDefaultPayload, S>;
        }>;
        alterTableDropColumnNotNull: <const S extends import("./input-types").AlterTableDropColumnNotNullPayloadSelect>(args: import("./mutation").AlterTableDropColumnNotNullVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableDropColumnNotNullPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableDropColumnNotNull: import("./select-types").InferSelectResult<import("./input-types").AlterTableDropColumnNotNullPayload, S>;
        }>;
        alterTableDropConstraint: <const S extends import("./input-types").AlterTableDropConstraintPayloadSelect>(args: import("./mutation").AlterTableDropConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableDropConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableDropConstraint: import("./select-types").InferSelectResult<import("./input-types").AlterTableDropConstraintPayload, S>;
        }>;
        alterTableDropInherits: <const S extends import("./input-types").AlterTableDropInheritsPayloadSelect>(args: import("./mutation").AlterTableDropInheritsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableDropInheritsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableDropInherits: import("./select-types").InferSelectResult<import("./input-types").AlterTableDropInheritsPayload, S>;
        }>;
        alterTableModifyCheckConstraint: <const S extends import("./input-types").AlterTableModifyCheckConstraintPayloadSelect>(args: import("./mutation").AlterTableModifyCheckConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableModifyCheckConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableModifyCheckConstraint: import("./select-types").InferSelectResult<import("./input-types").AlterTableModifyCheckConstraintPayload, S>;
        }>;
        alterTablePermBitlen: <const S extends import("./input-types").AlterTablePermBitlenPayloadSelect>(args: import("./mutation").AlterTablePermBitlenVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTablePermBitlenPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTablePermBitlen: import("./select-types").InferSelectResult<import("./input-types").AlterTablePermBitlenPayload, S>;
        }>;
        alterTablePermBitlenDefault: <const S extends import("./input-types").AlterTablePermBitlenDefaultPayloadSelect>(args: import("./mutation").AlterTablePermBitlenDefaultVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTablePermBitlenDefaultPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTablePermBitlenDefault: import("./select-types").InferSelectResult<import("./input-types").AlterTablePermBitlenDefaultPayload, S>;
        }>;
        alterTableRenameColumn: <const S extends import("./input-types").AlterTableRenameColumnPayloadSelect>(args: import("./mutation").AlterTableRenameColumnVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableRenameColumnPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableRenameColumn: import("./select-types").InferSelectResult<import("./input-types").AlterTableRenameColumnPayload, S>;
        }>;
        alterTableSetColumnDataType: <const S extends import("./input-types").AlterTableSetColumnDataTypePayloadSelect>(args: import("./mutation").AlterTableSetColumnDataTypeVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableSetColumnDataTypePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableSetColumnDataType: import("./select-types").InferSelectResult<import("./input-types").AlterTableSetColumnDataTypePayload, S>;
        }>;
        alterTableSetColumnDefault: <const S extends import("./input-types").AlterTableSetColumnDefaultPayloadSelect>(args: import("./mutation").AlterTableSetColumnDefaultVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableSetColumnDefaultPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableSetColumnDefault: import("./select-types").InferSelectResult<import("./input-types").AlterTableSetColumnDefaultPayload, S>;
        }>;
        alterTableSetColumnNotNull: <const S extends import("./input-types").AlterTableSetColumnNotNullPayloadSelect>(args: import("./mutation").AlterTableSetColumnNotNullVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableSetColumnNotNullPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableSetColumnNotNull: import("./select-types").InferSelectResult<import("./input-types").AlterTableSetColumnNotNullPayload, S>;
        }>;
        alterTableSetSchema: <const S extends import("./input-types").AlterTableSetSchemaPayloadSelect>(args: import("./mutation").AlterTableSetSchemaVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").AlterTableSetSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            alterTableSetSchema: import("./select-types").InferSelectResult<import("./input-types").AlterTableSetSchemaPayload, S>;
        }>;
        createColumn: <const S extends import("./input-types").CreateColumnPayloadSelect>(args: import("./mutation").CreateColumnVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateColumnPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createColumn: import("./select-types").InferSelectResult<import("./input-types").CreateColumnPayload, S>;
        }>;
        createFixture: <const S extends import("./input-types").CreateFixturePayloadSelect>(args: import("./mutation").CreateFixtureVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateFixturePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createFixture: import("./select-types").InferSelectResult<import("./input-types").CreateFixturePayload, S>;
        }>;
        createFunction: <const S extends import("./input-types").CreateFunctionPayloadSelect>(args: import("./mutation").CreateFunctionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createFunction: import("./select-types").InferSelectResult<import("./input-types").CreateFunctionPayload, S>;
        }>;
        createIndexUnsafe: <const S extends import("./input-types").CreateIndexUnsafePayloadSelect>(args: import("./mutation").CreateIndexUnsafeVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateIndexUnsafePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createIndexUnsafe: import("./select-types").InferSelectResult<import("./input-types").CreateIndexUnsafePayload, S>;
        }>;
        createInsert: <const S extends import("./input-types").CreateInsertPayloadSelect>(args: import("./mutation").CreateInsertVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateInsertPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createInsert: import("./select-types").InferSelectResult<import("./input-types").CreateInsertPayload, S>;
        }>;
        createTriggerDistinctFields: <const S extends import("./input-types").CreateTriggerDistinctFieldsPayloadSelect>(args: import("./mutation").CreateTriggerDistinctFieldsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CreateTriggerDistinctFieldsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            createTriggerDistinctFields: import("./select-types").InferSelectResult<import("./input-types").CreateTriggerDistinctFieldsPayload, S>;
        }>;
        denormalizedFields: <const S extends import("./input-types").DenormalizedFieldsPayloadSelect>(args: import("./mutation").DenormalizedFieldsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DenormalizedFieldsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            denormalizedFields: import("./select-types").InferSelectResult<import("./input-types").DenormalizedFieldsPayload, S>;
        }>;
        disableRowLevelSecurity: <const S extends import("./input-types").DisableRowLevelSecurityPayloadSelect>(args: import("./mutation").DisableRowLevelSecurityVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DisableRowLevelSecurityPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            disableRowLevelSecurity: import("./select-types").InferSelectResult<import("./input-types").DisableRowLevelSecurityPayload, S>;
        }>;
        dropConstraint: <const S extends import("./input-types").DropConstraintPayloadSelect>(args: import("./mutation").DropConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropConstraint: import("./select-types").InferSelectResult<import("./input-types").DropConstraintPayload, S>;
        }>;
        dropFunction: <const S extends import("./input-types").DropFunctionPayloadSelect>(args: import("./mutation").DropFunctionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropFunction: import("./select-types").InferSelectResult<import("./input-types").DropFunctionPayload, S>;
        }>;
        dropIndex: <const S extends import("./input-types").DropIndexPayloadSelect>(args: import("./mutation").DropIndexVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropIndexPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropIndex: import("./select-types").InferSelectResult<import("./input-types").DropIndexPayload, S>;
        }>;
        dropPolicy: <const S extends import("./input-types").DropPolicyPayloadSelect>(args: import("./mutation").DropPolicyVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropPolicyPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropPolicy: import("./select-types").InferSelectResult<import("./input-types").DropPolicyPayload, S>;
        }>;
        dropSchema: <const S extends import("./input-types").DropSchemaPayloadSelect>(args: import("./mutation").DropSchemaVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropSchema: import("./select-types").InferSelectResult<import("./input-types").DropSchemaPayload, S>;
        }>;
        dropTable: <const S extends import("./input-types").DropTablePayloadSelect>(args: import("./mutation").DropTableVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropTablePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropTable: import("./select-types").InferSelectResult<import("./input-types").DropTablePayload, S>;
        }>;
        dropTrigger: <const S extends import("./input-types").DropTriggerPayloadSelect>(args: import("./mutation").DropTriggerVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropTrigger: import("./select-types").InferSelectResult<import("./input-types").DropTriggerPayload, S>;
        }>;
        dropTriggerFunction: <const S extends import("./input-types").DropTriggerFunctionPayloadSelect>(args: import("./mutation").DropTriggerFunctionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").DropTriggerFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            dropTriggerFunction: import("./select-types").InferSelectResult<import("./input-types").DropTriggerFunctionPayload, S>;
        }>;
        enableRowLevelSecurity: <const S extends import("./input-types").EnableRowLevelSecurityPayloadSelect>(args: import("./mutation").EnableRowLevelSecurityVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").EnableRowLevelSecurityPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            enableRowLevelSecurity: import("./select-types").InferSelectResult<import("./input-types").EnableRowLevelSecurityPayload, S>;
        }>;
        ensureDefaultValuesInsert: <const S extends import("./input-types").EnsureDefaultValuesInsertPayloadSelect>(args: import("./mutation").EnsureDefaultValuesInsertVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").EnsureDefaultValuesInsertPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            ensureDefaultValuesInsert: import("./select-types").InferSelectResult<import("./input-types").EnsureDefaultValuesInsertPayload, S>;
        }>;
        grantUsageOnSchema: <const S extends import("./input-types").GrantUsageOnSchemaPayloadSelect>(args: import("./mutation").GrantUsageOnSchemaVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").GrantUsageOnSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            grantUsageOnSchema: import("./select-types").InferSelectResult<import("./input-types").GrantUsageOnSchemaPayload, S>;
        }>;
        immutableFieldTrigger: <const S extends import("./input-types").ImmutableFieldTriggerPayloadSelect>(args: import("./mutation").ImmutableFieldTriggerVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ImmutableFieldTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            immutableFieldTrigger: import("./select-types").InferSelectResult<import("./input-types").ImmutableFieldTriggerPayload, S>;
        }>;
        inflectionFieldTrigger: <const S extends import("./input-types").InflectionFieldTriggerPayloadSelect>(args: import("./mutation").InflectionFieldTriggerVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").InflectionFieldTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            inflectionFieldTrigger: import("./select-types").InferSelectResult<import("./input-types").InflectionFieldTriggerPayload, S>;
        }>;
        insertAction: <const S extends import("./input-types").InsertActionPayloadSelect>(args: import("./mutation").InsertActionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").InsertActionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            insertAction: import("./select-types").InferSelectResult<import("./input-types").InsertActionPayload, S>;
        }>;
        modifyCheckConstraint: <const S extends import("./input-types").ModifyCheckConstraintPayloadSelect>(args: import("./mutation").ModifyCheckConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ModifyCheckConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            modifyCheckConstraint: import("./select-types").InferSelectResult<import("./input-types").ModifyCheckConstraintPayload, S>;
        }>;
        ownedFieldsTrigger: <const S extends import("./input-types").OwnedFieldsTriggerPayloadSelect>(args: import("./mutation").OwnedFieldsTriggerVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").OwnedFieldsTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            ownedFieldsTrigger: import("./select-types").InferSelectResult<import("./input-types").OwnedFieldsTriggerPayload, S>;
        }>;
        peoplestamps: <const S extends import("./input-types").PeoplestampsPayloadSelect>(args: import("./mutation").PeoplestampsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").PeoplestampsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            peoplestamps: import("./select-types").InferSelectResult<import("./input-types").PeoplestampsPayload, S>;
        }>;
        renameConstraint: <const S extends import("./input-types").RenameConstraintPayloadSelect>(args: import("./mutation").RenameConstraintVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RenameConstraintPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            renameConstraint: import("./select-types").InferSelectResult<import("./input-types").RenameConstraintPayload, S>;
        }>;
        renameIndex: <const S extends import("./input-types").RenameIndexPayloadSelect>(args: import("./mutation").RenameIndexVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RenameIndexPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            renameIndex: import("./select-types").InferSelectResult<import("./input-types").RenameIndexPayload, S>;
        }>;
        renameSchema: <const S extends import("./input-types").RenameSchemaPayloadSelect>(args: import("./mutation").RenameSchemaVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RenameSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            renameSchema: import("./select-types").InferSelectResult<import("./input-types").RenameSchemaPayload, S>;
        }>;
        renameTable: <const S extends import("./input-types").RenameTablePayloadSelect>(args: import("./mutation").RenameTableVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RenameTablePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            renameTable: import("./select-types").InferSelectResult<import("./input-types").RenameTablePayload, S>;
        }>;
        revokeUsageOnSchema: <const S extends import("./input-types").RevokeUsageOnSchemaPayloadSelect>(args: import("./mutation").RevokeUsageOnSchemaVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").RevokeUsageOnSchemaPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            revokeUsageOnSchema: import("./select-types").InferSelectResult<import("./input-types").RevokeUsageOnSchemaPayload, S>;
        }>;
        setCommentOnColumn: <const S extends import("./input-types").SetCommentOnColumnPayloadSelect>(args: import("./mutation").SetCommentOnColumnVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetCommentOnColumnPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setCommentOnColumn: import("./select-types").InferSelectResult<import("./input-types").SetCommentOnColumnPayload, S>;
        }>;
        setCommentOnFunction: <const S extends import("./input-types").SetCommentOnFunctionPayloadSelect>(args: import("./mutation").SetCommentOnFunctionVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetCommentOnFunctionPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setCommentOnFunction: import("./select-types").InferSelectResult<import("./input-types").SetCommentOnFunctionPayload, S>;
        }>;
        setCommentOnTable: <const S extends import("./input-types").SetCommentOnTablePayloadSelect>(args: import("./mutation").SetCommentOnTableVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetCommentOnTablePayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setCommentOnTable: import("./select-types").InferSelectResult<import("./input-types").SetCommentOnTablePayload, S>;
        }>;
        slugFieldTrigger: <const S extends import("./input-types").SlugFieldTriggerPayloadSelect>(args: import("./mutation").SlugFieldTriggerVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SlugFieldTriggerPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            slugFieldTrigger: import("./select-types").InferSelectResult<import("./input-types").SlugFieldTriggerPayload, S>;
        }>;
        timestamps: <const S extends import("./input-types").TimestampsPayloadSelect>(args: import("./mutation").TimestampsVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").TimestampsPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            timestamps: import("./select-types").InferSelectResult<import("./input-types").TimestampsPayload, S>;
        }>;
        checkPassword: <const S extends import("./input-types").CheckPasswordPayloadSelect>(args: import("./mutation").CheckPasswordVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").CheckPasswordPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            checkPassword: import("./select-types").InferSelectResult<import("./input-types").CheckPasswordPayload, S>;
        }>;
        confirmDeleteAccount: <const S extends import("./input-types").ConfirmDeleteAccountPayloadSelect>(args: import("./mutation").ConfirmDeleteAccountVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ConfirmDeleteAccountPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            confirmDeleteAccount: import("./select-types").InferSelectResult<import("./input-types").ConfirmDeleteAccountPayload, S>;
        }>;
        extendTokenExpires: <const S extends import("./input-types").ExtendTokenExpiresPayloadSelect>(args: import("./mutation").ExtendTokenExpiresVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ExtendTokenExpiresPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            extendTokenExpires: import("./select-types").InferSelectResult<import("./input-types").ExtendTokenExpiresPayload, S>;
        }>;
        forgotPassword: <const S extends import("./input-types").ForgotPasswordPayloadSelect>(args: import("./mutation").ForgotPasswordVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ForgotPasswordPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            forgotPassword: import("./select-types").InferSelectResult<import("./input-types").ForgotPasswordPayload, S>;
        }>;
        oneTimeToken: <const S extends import("./input-types").OneTimeTokenPayloadSelect>(args: import("./mutation").OneTimeTokenVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").OneTimeTokenPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            oneTimeToken: import("./select-types").InferSelectResult<import("./input-types").OneTimeTokenPayload, S>;
        }>;
        resetPassword: <const S extends import("./input-types").ResetPasswordPayloadSelect>(args: import("./mutation").ResetPasswordVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").ResetPasswordPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            resetPassword: import("./select-types").InferSelectResult<import("./input-types").ResetPasswordPayload, S>;
        }>;
        sendAccountDeletionEmail: <const S extends import("./input-types").SendAccountDeletionEmailPayloadSelect>(args: import("./mutation").SendAccountDeletionEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SendAccountDeletionEmailPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            sendAccountDeletionEmail: import("./select-types").InferSelectResult<import("./input-types").SendAccountDeletionEmailPayload, S>;
        }>;
        sendVerificationEmail: <const S extends import("./input-types").SendVerificationEmailPayloadSelect>(args: import("./mutation").SendVerificationEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SendVerificationEmailPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            sendVerificationEmail: import("./select-types").InferSelectResult<import("./input-types").SendVerificationEmailPayload, S>;
        }>;
        setPassword: <const S extends import("./input-types").SetPasswordPayloadSelect>(args: import("./mutation").SetPasswordVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SetPasswordPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            setPassword: import("./select-types").InferSelectResult<import("./input-types").SetPasswordPayload, S>;
        }>;
        signIn: <const S extends import("./input-types").SignInPayloadSelect>(args: import("./mutation").SignInVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SignInPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            signIn: import("./select-types").InferSelectResult<import("./input-types").SignInPayload, S>;
        }>;
        signInOneTimeToken: <const S extends import("./input-types").SignInOneTimeTokenPayloadSelect>(args: import("./mutation").SignInOneTimeTokenVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SignInOneTimeTokenPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            signInOneTimeToken: import("./select-types").InferSelectResult<import("./input-types").SignInOneTimeTokenPayload, S>;
        }>;
        signOut: <const S extends import("./input-types").SignOutPayloadSelect>(args: import("./mutation").SignOutVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SignOutPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            signOut: import("./select-types").InferSelectResult<import("./input-types").SignOutPayload, S>;
        }>;
        signUp: <const S extends import("./input-types").SignUpPayloadSelect>(args: import("./mutation").SignUpVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").SignUpPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            signUp: import("./select-types").InferSelectResult<import("./input-types").SignUpPayload, S>;
        }>;
        verifyEmail: <const S extends import("./input-types").VerifyEmailPayloadSelect>(args: import("./mutation").VerifyEmailVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").VerifyEmailPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            verifyEmail: import("./select-types").InferSelectResult<import("./input-types").VerifyEmailPayload, S>;
        }>;
        verifyPassword: <const S extends import("./input-types").VerifyPasswordPayloadSelect>(args: import("./mutation").VerifyPasswordVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").VerifyPasswordPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            verifyPassword: import("./select-types").InferSelectResult<import("./input-types").VerifyPasswordPayload, S>;
        }>;
        verifyTotp: <const S extends import("./input-types").VerifyTotpPayloadSelect>(args: import("./mutation").VerifyTotpVariables, options?: {
            select?: import("./select-types").DeepExact<S, import("./input-types").VerifyTotpPayloadSelect>;
        }) => import("./query-builder").QueryBuilder<{
            verifyTotp: import("./select-types").InferSelectResult<import("./input-types").VerifyTotpPayload, S>;
        }>;
    };
};
